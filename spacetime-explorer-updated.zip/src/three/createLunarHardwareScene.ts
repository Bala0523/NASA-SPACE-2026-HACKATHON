import * as THREE from 'three';

function createFoilBumpTexture(): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.fillStyle = '#808080';
    ctx.fillRect(0, 0, size, size);
    // Deterministic geometric foil crinkles
    for (let i = 0; i < 180; i++) {
      const x = ((i * 73) % size);
      const y = ((i * 137) % size);
      const w = 14 + (i % 24);
      const h = 10 + ((i * 7) % 18);
      const shade = 95 + ((i * 29) % 110);
      ctx.fillStyle = `rgb(${shade},${shade},${shade})`;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + w, y + ((i % 5) - 2) * 3);
      ctx.lineTo(x + w * 0.6, y + h);
      ctx.closePath();
      ctx.fill();
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(2, 2);
  return tex;
}

function createSolarPanelTexture(): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.fillStyle = '#0c1b3a';
    ctx.fillRect(0, 0, size, size);
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2;
    const cols = 4;
    const rows = 8;
    const cw = size / cols;
    const ch = size / rows;
    for (let c = 0; c <= cols; c++) {
      ctx.beginPath();
      ctx.moveTo(c * cw, 0);
      ctx.lineTo(c * cw, size);
      ctx.stroke();
    }
    for (let r = 0; r <= rows; r++) {
      ctx.beginPath();
      ctx.moveTo(0, r * ch);
      ctx.lineTo(size, r * ch);
      ctx.stroke();
    }
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.35)';
    ctx.lineWidth = 1;
    for (let c = 0; c < cols; c++) {
      ctx.beginPath();
      ctx.moveTo(c * cw + cw * 0.5, 0);
      ctx.lineTo(c * cw + cw * 0.5, size);
      ctx.stroke();
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

function createLunarRegolithTexture(): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.fillStyle = '#2d333d';
    ctx.fillRect(0, 0, size, size);

    // Subtle tonal maria & highlands bands
    for (let i = 0; i < 65; i++) {
      const x = (i * 97) % size;
      const y = (i * 173) % size;
      const r = 24 + (i % 50);
      const grad = ctx.createRadialGradient(x, y, 2, x, y, r);
      grad.addColorStop(0, 'rgba(65, 74, 88, 0.35)');
      grad.addColorStop(1, 'rgba(30, 35, 44, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }

    // Impact craters with raised bright rims
    for (let i = 0; i < 90; i++) {
      const x = (i * 151 + 19) % size;
      const y = (i * 227 + 41) % size;
      const r = 4 + (i % 18);
      ctx.fillStyle = 'rgba(18, 22, 29, 0.72)';
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = 'rgba(130, 142, 160, 0.42)';
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.arc(x, y, r + 0.8, 0, Math.PI * 2);
      ctx.stroke();
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(3, 2);
  return tex;
}

export interface ProceduralSpaceAssets {
  spacecraftGroup: THREE.Group;
  solarWings: THREE.Group[];
  dishAssembly: THREE.Group;
  lunarHorizon: THREE.Mesh;
  orbitalRing: THREE.Mesh;
  stars: THREE.InstancedMesh;
  dispose: () => void;
}

export function createLunarHardwareScene(
  scene: THREE.Scene,
  maxAnisotropy: number
): ProceduralSpaceAssets {
  const disposables: Array<{ dispose: () => void }> = [];

  const foilBump = createFoilBumpTexture();
  foilBump.anisotropy = maxAnisotropy;
  disposables.push(foilBump);

  const solarTex = createSolarPanelTexture();
  solarTex.anisotropy = maxAnisotropy;
  disposables.push(solarTex);

  const regolithTex = createLunarRegolithTexture();
  regolithTex.anisotropy = maxAnisotropy;
  disposables.push(regolithTex);

  // Materials with deliberate roughness/metalness separation
  const kaptonGoldMat = new THREE.MeshStandardMaterial({
    color: 0xd9a126,
    metalness: 0.92,
    roughness: 0.25,
    bumpMap: foilBump,
    bumpScale: 0.035,
  });

  const titaniumMat = new THREE.MeshStandardMaterial({
    color: 0x94a3b8,
    metalness: 0.85,
    roughness: 0.45,
  });

  const darkCarbonMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    metalness: 0.35,
    roughness: 0.72,
  });

  const ceramicWhiteMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    metalness: 0.2,
    roughness: 0.32,
  });

  const solarCellMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: solarTex,
    metalness: 0.65,
    roughness: 0.16,
  });

  const cobaltBeaconMat = new THREE.MeshStandardMaterial({
    color: 0x3b82f6,
    emissive: 0x2563eb,
    emissiveIntensity: 1.8,
    roughness: 0.2,
    metalness: 0.1,
  });

  const opticLensMat = new THREE.MeshStandardMaterial({
    color: 0x0ea5e9,
    metalness: 0.95,
    roughness: 0.08,
  });

  disposables.push(
    kaptonGoldMat,
    titaniumMat,
    darkCarbonMat,
    ceramicWhiteMat,
    solarCellMat,
    cobaltBeaconMat,
    opticLensMat
  );

  // Composite 10+ Part NASA Lunar Lander / Recon Spacecraft Group
  const spacecraftGroup = new THREE.Group();

  // 1. Primary Octagonal Thermal Bus
  const busGeo = new THREE.CylinderGeometry(0.68, 0.74, 0.54, 8);
  const busMesh = new THREE.Mesh(busGeo, kaptonGoldMat);
  busMesh.castShadow = true;
  busMesh.receiveShadow = true;
  spacecraftGroup.add(busMesh);
  disposables.push(busGeo);

  // 2. Upper Titanium Instrument Deck
  const deckGeo = new THREE.CylinderGeometry(0.7, 0.7, 0.07, 8);
  const deckMesh = new THREE.Mesh(deckGeo, titaniumMat);
  deckMesh.position.y = 0.3;
  deckMesh.castShadow = true;
  spacecraftGroup.add(deckMesh);
  disposables.push(deckGeo);

  // 3. Lower Structural Collar & Descent Engine Nozzle (LatheGeometry)
  const collarGeo = new THREE.CylinderGeometry(0.56, 0.44, 0.14, 16);
  const collarMesh = new THREE.Mesh(collarGeo, darkCarbonMat);
  collarMesh.position.y = -0.34;
  spacecraftGroup.add(collarMesh);

  const nozzlePts = [
    new THREE.Vector2(0.12, 0),
    new THREE.Vector2(0.16, -0.1),
    new THREE.Vector2(0.28, -0.34),
    new THREE.Vector2(0.32, -0.44),
  ];
  const nozzleGeo = new THREE.LatheGeometry(nozzlePts, 24);
  const nozzleMesh = new THREE.Mesh(nozzleGeo, darkCarbonMat);
  nozzleMesh.position.y = -0.36;
  spacecraftGroup.add(nozzleMesh);
  disposables.push(collarGeo, nozzleGeo);

  // 4. Four Articulated Landing Struts & Circular Footpads
  const strutGeo = new THREE.CylinderGeometry(0.032, 0.026, 0.96, 8);
  const padGeo = new THREE.CylinderGeometry(0.15, 0.19, 0.045, 16);
  disposables.push(strutGeo, padGeo);

  for (let i = 0; i < 4; i++) {
    const angle = (i * Math.PI) / 2 + Math.PI / 4;
    const legGroup = new THREE.Group();
    legGroup.rotation.y = angle;

    const strut = new THREE.Mesh(strutGeo, titaniumMat);
    strut.position.set(0.72, -0.46, 0);
    strut.rotation.z = -0.52;
    strut.castShadow = true;
    legGroup.add(strut);

    const footpad = new THREE.Mesh(padGeo, kaptonGoldMat);
    footpad.position.set(0.98, -0.86, 0);
    footpad.receiveShadow = true;
    legGroup.add(footpad);

    spacecraftGroup.add(legGroup);
  }

  // 5. Parabolic High-Gain Dish Antenna (LatheGeometry)
  const dishAssembly = new THREE.Group();
  dishAssembly.position.set(-0.22, 0.56, -0.14);
  dishAssembly.rotation.set(0.35, 0.3, 0.18);

  const dishPts = [
    new THREE.Vector2(0.01, 0),
    new THREE.Vector2(0.18, 0.03),
    new THREE.Vector2(0.34, 0.11),
    new THREE.Vector2(0.46, 0.24),
  ];
  const dishGeo = new THREE.LatheGeometry(dishPts, 28);
  const dishMat = ceramicWhiteMat.clone();
  dishMat.side = THREE.DoubleSide;
  const dishMesh = new THREE.Mesh(dishGeo, dishMat);
  dishAssembly.add(dishMesh);

  const feedStemGeo = new THREE.CylinderGeometry(0.018, 0.024, 0.32, 8);
  const feedStem = new THREE.Mesh(feedStemGeo, titaniumMat);
  feedStem.position.y = 0.18;
  dishAssembly.add(feedStem);

  const feedTipGeo = new THREE.SphereGeometry(0.045, 12, 12);
  const feedTip = new THREE.Mesh(feedTipGeo, kaptonGoldMat);
  feedTip.position.y = 0.34;
  dishAssembly.add(feedTip);

  spacecraftGroup.add(dishAssembly);
  disposables.push(dishGeo, dishMat, feedStemGeo, feedTipGeo);

  // 6. Optical Stereo Mast & Retroreflector Beacon
  const mastGeo = new THREE.CylinderGeometry(0.035, 0.042, 0.62, 10);
  const mastMesh = new THREE.Mesh(mastGeo, titaniumMat);
  mastMesh.position.set(0.28, 0.62, 0.24);
  spacecraftGroup.add(mastMesh);

  const camHeadGeo = new THREE.BoxGeometry(0.28, 0.12, 0.16);
  const camHead = new THREE.Mesh(camHeadGeo, ceramicWhiteMat);
  camHead.position.set(0.28, 0.94, 0.24);
  spacecraftGroup.add(camHead);

  const lensGeo = new THREE.CylinderGeometry(0.035, 0.035, 0.04, 16);
  const lensL = new THREE.Mesh(lensGeo, opticLensMat);
  lensL.rotation.x = Math.PI / 2;
  lensL.position.set(0.22, 0.94, 0.33);
  const lensR = lensL.clone();
  lensR.position.x = 0.34;
  spacecraftGroup.add(lensL, lensR);

  const beaconGeo = new THREE.TorusGeometry(0.09, 0.018, 8, 24);
  const beaconMesh = new THREE.Mesh(beaconGeo, cobaltBeaconMat);
  beaconMesh.position.set(0, 0.35, 0.56);
  spacecraftGroup.add(beaconMesh);

  disposables.push(mastGeo, camHeadGeo, lensGeo, beaconGeo);

  // 7. Twin Articulated Photovoltaic Solar Wings
  const solarWings: THREE.Group[] = [];
  const wingBoomGeo = new THREE.CylinderGeometry(0.024, 0.024, 0.36, 8);
  const wingPanelGeo = new THREE.BoxGeometry(1.18, 0.025, 0.52);
  const wingFrameGeo = new THREE.BoxGeometry(1.22, 0.018, 0.56);
  disposables.push(wingBoomGeo, wingPanelGeo, wingFrameGeo);

  [-1, 1].forEach((dir) => {
    const wing = new THREE.Group();
    wing.position.set(dir * 0.72, 0.16, 0);

    const boom = new THREE.Mesh(wingBoomGeo, titaniumMat);
    boom.rotation.z = Math.PI / 2;
    boom.position.x = dir * 0.16;
    wing.add(boom);

    const frame = new THREE.Mesh(wingFrameGeo, darkCarbonMat);
    frame.position.x = dir * 0.92;
    wing.add(frame);

    const panel = new THREE.Mesh(wingPanelGeo, solarCellMat);
    panel.position.set(dir * 0.92, 0.008, 0);
    panel.castShadow = true;
    wing.add(panel);

    wing.rotation.x = 0.28;
    spacecraftGroup.add(wing);
    solarWings.push(wing);
  });

  spacecraftGroup.position.set(1.45, 0.38, 0);
  spacecraftGroup.rotation.set(0.14, -0.45, -0.06);
  scene.add(spacecraftGroup);

  // 8. Lunar South Pole Horizon Sphere beneath spacecraft
  const lunarGeo = new THREE.SphereGeometry(5.6, 48, 36);
  const lunarMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: regolithTex,
    bumpMap: regolithTex,
    bumpScale: 0.09,
    roughness: 0.92,
    metalness: 0.04,
  });
  const lunarHorizon = new THREE.Mesh(lunarGeo, lunarMat);
  lunarHorizon.position.set(1.75, -6.4, -0.8);
  lunarHorizon.receiveShadow = true;
  scene.add(lunarHorizon);
  disposables.push(lunarGeo, lunarMat);

  // 9. Calibrated Orbital Reconnaissance Trajectory Ring
  const ringGeo = new THREE.TorusGeometry(2.72, 0.01, 8, 128);
  const ringMat = new THREE.MeshBasicMaterial({
    color: 0x3b82f6,
    transparent: true,
    opacity: 0.36,
  });
  const orbitalRing = new THREE.Mesh(ringGeo, ringMat);
  orbitalRing.position.set(1.45, 0.22, 0);
  orbitalRing.rotation.set(Math.PI / 2.4, 0.22, 0);
  scene.add(orbitalRing);
  disposables.push(ringGeo, ringMat);

  // 10. Instanced Pinpoint Starfield (360 stars)
  const starCount = 360;
  const starGeo = new THREE.OctahedronGeometry(0.032, 0);
  const starMat = new THREE.MeshBasicMaterial({ color: 0xe2e8f0 });
  const stars = new THREE.InstancedMesh(starGeo, starMat, starCount);
  stars.frustumCulled = false;

  const dummy = new THREE.Object3D();
  const tintColor = new THREE.Color();
  for (let i = 0; i < starCount; i++) {
    const theta = ((i * 137.5) % 360) * (Math.PI / 180);
    const phi = Math.acos(1 - (2 * ((i + 0.5) / starCount)));
    const radius = 16 + (i % 14);
    dummy.position.set(
      radius * Math.sin(phi) * Math.cos(theta),
      radius * Math.cos(phi) + 1.5,
      radius * Math.sin(phi) * Math.sin(theta) - 4
    );
    const scale = 0.45 + ((i * 17) % 10) * 0.08;
    dummy.scale.setScalar(scale);
    dummy.updateMatrix();
    stars.setMatrixAt(i, dummy.matrix);

    if (i % 7 === 0) tintColor.setHex(0x93c5fd);
    else if (i % 11 === 0) tintColor.setHex(0xfde68a);
    else tintColor.setHex(0xf8fafc);
    stars.setColorAt(i, tintColor);
  }
  stars.instanceMatrix.needsUpdate = true;
  if (stars.instanceColor) stars.instanceColor.needsUpdate = true;
  stars.computeBoundingSphere();
  scene.add(stars);
  disposables.push(starGeo, starMat);

  return {
    spacecraftGroup,
    solarWings,
    dishAssembly,
    lunarHorizon,
    orbitalRing,
    stars,
    dispose: () => {
      disposables.forEach((d) => d.dispose());
    },
  };
}
