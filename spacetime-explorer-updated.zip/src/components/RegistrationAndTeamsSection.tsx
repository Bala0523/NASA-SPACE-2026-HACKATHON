import { useMemo, useState } from 'react';
import { Check, Search, UserPlus } from 'lucide-react';
import {
  AVAILABLE_ROLES,
  CHALLENGES,
  NASA_DATASETS,
} from '../data/hackathonData';
import {
  HackathonTeam,
  RegistrationInput,
  TrackId,
  ValidationResult,
} from '../types/hackathon';
import { filterTeams, validateRegistration } from '../utils/hackathonLogic';

interface RegistrationAndTeamsSectionProps {
  selectedChallengeId: string;
  onChangeSelectedChallengeId: (id: string) => void;
  missionKitIds: string[];
  onToggleDataset: (datasetId: string) => void;
  teams: HackathonTeam[];
  onRegisterTeam: (team: HackathonTeam) => void;
  onJoinTeam: (teamId: string) => void;
}

const ROSTER_TRACK_FILTERS: Array<TrackId | 'All'> = [
  'All',
  'Planets & Moons',
  'Earth Observation',
  'Astrophysics',
  'Heliophysics',
];

export function RegistrationAndTeamsSection({
  selectedChallengeId,
  onChangeSelectedChallengeId,
  missionKitIds,
  onToggleDataset,
  teams,
  onRegisterTeam,
  onJoinTeam,
}: RegistrationAndTeamsSectionProps) {
  const [name, setName] = useState('');
  const [leadEmail, setLeadEmail] = useState('');
  const [mode, setMode] = useState<'In-Person · Houston' | 'Global Remote'>(
    'Global Remote'
  );
  const [maxMembers, setMaxMembers] = useState(4);
  const [rolesNeeded, setRolesNeeded] = useState<string[]>(['Full-Stack']);
  const [pitch, setPitch] = useState('');
  const [errors, setErrors] = useState<ValidationResult['errors']>({});
  const [submittedTeamName, setSubmittedTeamName] = useState<string | null>(null);

  // Roster filters
  const [rosterTrack, setRosterTrack] = useState<TrackId | 'All'>('All');
  const [seekingOnly, setSeekingOnly] = useState(false);
  const [rosterQuery, setRosterQuery] = useState('');

  const filteredTeams = useMemo(
    () =>
      filterTeams(teams, rosterTrack, seekingOnly, rosterQuery, CHALLENGES),
    [teams, rosterTrack, seekingOnly, rosterQuery]
  );

  const toggleRole = (role: string) => {
    setRolesNeeded((prev) =>
      prev.includes(role) ? prev.filter((r) => r !== role) : [...prev, role]
    );
  };

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    setSubmittedTeamName(null);

    const payload: RegistrationInput = {
      name,
      leadEmail,
      mode,
      challengeId: selectedChallengeId,
      datasetIds: missionKitIds,
      rolesNeeded,
      maxMembers,
      pitch,
    };

    const validation = validateRegistration(payload);
    if (!validation.valid) {
      setErrors(validation.errors);
      return;
    }

    setErrors({});
    const newTeam: HackathonTeam = {
      id: `team-${Date.now()}`,
      name: payload.name.trim(),
      leadEmail: payload.leadEmail.trim(),
      mode: payload.mode,
      challengeId: payload.challengeId,
      datasetIds: payload.datasetIds,
      rolesNeeded:
        payload.rolesNeeded.length > 0 ? payload.rolesNeeded : ['Open Roles'],
      currentMembers: 1,
      maxMembers: payload.maxMembers,
      pitch: payload.pitch.trim(),
    };

    onRegisterTeam(newTeam);
    setSubmittedTeamName(newTeam.name);
    setName('');
    setLeadEmail('');
    setPitch('');
  };

  const challengeTitleById = useMemo(
    () => new Map(CHALLENGES.map((c) => [c.id, `${c.index}. ${c.title}`])),
    []
  );

  return (
    <section id="register" className="py-16 lg:py-24 bg-[#0B0F17]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-12">
          <p className="text-xs font-mono text-slate-400 mb-2">
            Team Formation &amp; Mission Check-In
          </p>
          <h2
            style={{ textWrap: 'balance' }}
            className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-white mb-3"
          >
            Register Your Team or Join a Crew
          </h2>
          <p className="text-base text-slate-300">
            Lock in your challenge prompt, attach datasets from your Mission Kit, and
            publish open seats to the live 2026 recruiting roster.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: Registration Form */}
          <div className="lg:col-span-6 bg-[#07090E] border border-slate-800 rounded-xl p-6 sm:p-8">
            <h3 className="font-display text-xl font-semibold text-white mb-6 pb-4 border-b border-slate-800">
              New Team Registration
            </h3>

            {submittedTeamName && (
              <div
                role="status"
                className="mb-6 p-4 rounded-lg border border-emerald-500/40 bg-emerald-950/30 text-emerald-200 text-sm flex items-start gap-2.5"
              >
                <Check
                  className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0"
                  aria-hidden="true"
                />
                <span>
                  Team <strong>{submittedTeamName}</strong> registered and published
                  to the active 2026 roster.
                </span>
              </div>
            )}

            <form onSubmit={handleSubmit} noValidate className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="team-name"
                    className="block text-xs font-mono text-slate-300 mb-1.5"
                  >
                    Team Name
                  </label>
                  <input
                    id="team-name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Tranquility Archivers"
                    className="w-full px-3.5 py-2.5 text-sm bg-[#0B0F17] border border-slate-800 rounded-md text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
                  />
                  {errors.name && (
                    <p className="mt-1.5 text-xs text-rose-400">{errors.name}</p>
                  )}
                </div>

                <div>
                  <label
                    htmlFor="lead-email"
                    className="block text-xs font-mono text-slate-300 mb-1.5"
                  >
                    Team Lead Email
                  </label>
                  <input
                    id="lead-email"
                    type="email"
                    value={leadEmail}
                    onChange={(e) => setLeadEmail(e.target.value)}
                    placeholder="lead@university.edu"
                    className="w-full px-3.5 py-2.5 text-sm bg-[#0B0F17] border border-slate-800 rounded-md text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
                  />
                  {errors.leadEmail && (
                    <p className="mt-1.5 text-xs text-rose-400">
                      {errors.leadEmail}
                    </p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="participation-mode"
                    className="block text-xs font-mono text-slate-300 mb-1.5"
                  >
                    Participation Site
                  </label>
                  <select
                    id="participation-mode"
                    value={mode}
                    onChange={(e) =>
                      setMode(
                        e.target.value as 'In-Person · Houston' | 'Global Remote'
                      )
                    }
                    className="w-full px-3.5 py-2.5 text-sm bg-[#0B0F17] border border-slate-800 rounded-md text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value="Global Remote">Global Remote</option>
                    <option value="In-Person · Houston">
                      In-Person · Houston
                    </option>
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="team-capacity"
                    className="block text-xs font-mono text-slate-300 mb-1.5"
                  >
                    Target Team Size (1–6)
                  </label>
                  <input
                    id="team-capacity"
                    type="number"
                    min={1}
                    max={6}
                    value={maxMembers}
                    onChange={(e) => setMaxMembers(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 text-sm font-mono tabular-nums bg-[#0B0F17] border border-slate-800 rounded-md text-white focus:outline-none focus:border-blue-500"
                  />
                  {errors.maxMembers && (
                    <p className="mt-1.5 text-xs text-rose-400">
                      {errors.maxMembers}
                    </p>
                  )}
                </div>
              </div>

              <div>
                <label
                  htmlFor="challenge-select"
                  className="block text-xs font-mono text-slate-300 mb-1.5"
                >
                  Primary Challenge Prompt
                </label>
                <select
                  id="challenge-select"
                  value={selectedChallengeId}
                  onChange={(e) => onChangeSelectedChallengeId(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm bg-[#0B0F17] border border-slate-800 rounded-md text-white focus:outline-none focus:border-blue-500"
                >
                  {CHALLENGES.map((challenge) => (
                    <option key={challenge.id} value={challenge.id}>
                      {challenge.index}. {challenge.title}
                    </option>
                  ))}
                </select>
                {errors.challengeId && (
                  <p className="mt-1.5 text-xs text-rose-400">
                    {errors.challengeId}
                  </p>
                )}
              </div>

              <div>
                <span className="block text-xs font-mono text-slate-300 mb-2">
                  Roles Needed
                </span>
                <div className="flex flex-wrap gap-2">
                  {AVAILABLE_ROLES.map((role) => {
                    const active = rolesNeeded.includes(role);
                    return (
                      <button
                        key={role}
                        type="button"
                        onClick={() => toggleRole(role)}
                        aria-pressed={active}
                        className={`px-3 py-1.5 text-xs font-medium rounded-md border transition-colors whitespace-nowrap shrink-0 ${
                          active
                            ? 'bg-blue-600 border-blue-500 text-white'
                            : 'bg-[#0B0F17] border-slate-800 text-slate-300 hover:border-slate-700'
                        }`}
                      >
                        {role}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <span className="block text-xs font-mono text-slate-300 mb-2">
                  Attached Mission Kit Datasets ({missionKitIds.length})
                </span>
                {missionKitIds.length === 0 ? (
                  <p className="text-xs text-slate-500">
                    No datasets attached yet. Select datasets in the Open Science Data
                    Sandbox above or continue without pre-attaching.
                  </p>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {missionKitIds.map((id) => {
                      const ds = NASA_DATASETS.find((d) => d.id === id);
                      if (!ds) return null;
                      return (
                        <button
                          key={id}
                          type="button"
                          onClick={() => onToggleDataset(id)}
                          title="Click to remove dataset from kit"
                          className="px-2.5 py-1 text-xs font-mono bg-[#111827] border border-slate-700 hover:border-rose-500/60 text-slate-200 rounded-md"
                        >
                          {ds.name.split(' ').slice(0, 3).join(' ')} ×
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              <div>
                <label
                  htmlFor="team-pitch"
                  className="block text-xs font-mono text-slate-300 mb-1.5"
                >
                  Project Pitch
                </label>
                <textarea
                  id="team-pitch"
                  rows={3}
                  value={pitch}
                  onChange={(e) => setPitch(e.target.value)}
                  placeholder="Describe your proposed artifact story, data pipeline, or visualization..."
                  className="w-full px-3.5 py-2.5 text-sm bg-[#0B0F17] border border-slate-800 rounded-md text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
                />
                {errors.pitch && (
                  <p className="mt-1.5 text-xs text-rose-400">{errors.pitch}</p>
                )}
              </div>

              <button
                type="submit"
                className="w-full py-3 px-4 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-md transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
              >
                Register Team for 2026 Sprint
              </button>
            </form>
          </div>

          {/* Right: Live Teams & Recruiting Roster */}
          <div className="lg:col-span-6 space-y-5">
            <div className="bg-[#07090E] border border-slate-800 rounded-xl p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h3 className="font-display text-xl font-semibold text-white">
                  Active Teams Roster ({filteredTeams.length})
                </h3>

                <label className="inline-flex items-center gap-2 text-xs font-mono text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={seekingOnly}
                    onChange={(e) => setSeekingOnly(e.target.checked)}
                    className="rounded border-slate-700 bg-slate-900 text-blue-600 focus:ring-blue-500"
                  />
                  Open seats only
                </label>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <Search
                    className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                    aria-hidden="true"
                  />
                  <input
                    type="search"
                    aria-label="Search registered teams"
                    value={rosterQuery}
                    onChange={(e) => setRosterQuery(e.target.value)}
                    placeholder="Search team name, role, or pitch..."
                    className="w-full pl-9 pr-3 py-2 text-xs bg-[#0B0F17] border border-slate-800 rounded-md text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500"
                  />
                </div>

                <select
                  aria-label="Filter teams by track"
                  value={rosterTrack}
                  onChange={(e) =>
                    setRosterTrack(e.target.value as TrackId | 'All')
                  }
                  className="px-3 py-2 text-xs bg-[#0B0F17] border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  {ROSTER_TRACK_FILTERS.map((t) => (
                    <option key={t} value={t}>
                      {t === 'All' ? 'All Tracks' : t}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {filteredTeams.length === 0 ? (
              <div className="bg-[#07090E] border border-slate-800 rounded-xl p-8 text-center">
                <p className="text-sm font-medium text-white mb-1">
                  No registered teams match this filter
                </p>
                <p className="text-xs text-slate-400">
                  Register a new team on the left or broaden your search filter.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredTeams.map((team) => {
                  const isFull = team.currentMembers >= team.maxMembers;
                  const challengeName =
                    challengeTitleById.get(team.challengeId) ?? team.challengeId;

                  return (
                    <article
                      key={team.id}
                      className="bg-[#07090E] border border-slate-800 rounded-xl p-5"
                    >
                      <div className="flex flex-wrap items-start justify-between gap-3 mb-2">
                        <div>
                          <div className="text-xs font-mono text-slate-400">
                            {team.mode} <span aria-hidden="true">·</span>{' '}
                            <span className="tabular-nums">
                              {team.currentMembers}/{team.maxMembers} members
                            </span>
                          </div>
                          <h4 className="font-display text-lg font-semibold text-white mt-0.5">
                            {team.name}
                          </h4>
                        </div>

                        <button
                          type="button"
                          disabled={isFull || Boolean(team.joinedByUser)}
                          onClick={() => onJoinTeam(team.id)}
                          className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                            team.joinedByUser
                              ? 'bg-emerald-950/50 text-emerald-300 border border-emerald-500/40 cursor-default'
                              : isFull
                              ? 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed'
                              : 'bg-slate-900 hover:bg-slate-800 text-white border border-slate-700'
                          }`}
                        >
                          {team.joinedByUser ? (
                            <>
                              <Check className="w-3.5 h-3.5" aria-hidden="true" />
                              Joined Crew
                            </>
                          ) : isFull ? (
                            'Crew Full'
                          ) : (
                            <>
                              <UserPlus
                                className="w-3.5 h-3.5"
                                aria-hidden="true"
                              />
                              Join Team
                            </>
                          )}
                        </button>
                      </div>

                      <div className="text-xs font-mono text-blue-400 mb-2.5 truncate">
                        {challengeName}
                      </div>

                      <p className="text-sm text-slate-300 leading-relaxed mb-3">
                        {team.pitch}
                      </p>

                      <div className="text-xs font-mono text-slate-400">
                        Seeking: {team.rolesNeeded.join(' · ')}
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
