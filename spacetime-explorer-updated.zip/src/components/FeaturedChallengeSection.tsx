import { useState } from 'react';
import { ArrowRight, Compass } from 'lucide-react';
import { ARTIFACT_SPOTLIGHTS } from '../data/hackathonData';
import { SafeImage } from './SafeImage';

interface FeaturedChallengeSectionProps {
  onSelectForRegistration: (challengeId: string, datasetIds: string[]) => void;
}

export function FeaturedChallengeSection({
  onSelectForRegistration,
}: FeaturedChallengeSectionProps) {
  const [selectedArtifactId, setSelectedArtifactId] = useState(
    ARTIFACT_SPOTLIGHTS[0].id
  );

  const activeArtifact =
    ARTIFACT_SPOTLIGHTS.find((a) => a.id === selectedArtifactId) ??
    ARTIFACT_SPOTLIGHTS[0];

  return (
    <section
      id="featured-brief"
      className="py-16 lg:py-24 border-b border-slate-800/90 bg-[#07090E]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-12">
          <p className="text-xs font-mono text-blue-400 mb-2">
            Featured First Problem Statement · Planets &amp; Moons
          </p>
          <h2
            style={{ textWrap: 'balance' }}
            className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-white mb-4"
          >
            01. Abandoned but not Forgotten: Discarded Equipment on the Moon and Mars
          </h2>
          <p className="text-base text-slate-300 leading-relaxed">
            Since the 1960s, NASA has left rovers, descent stages, seismometers, and
            probes across the Moon and Mars. School-age learners mostly hear about
            active missions and mistake retired hardware for space junk. Your task:
            turn these silent monuments and their verified orbital coordinates into
            interactive stories that teach young explorers what they discovered.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left: Interactive Off-World Hardware Artifact Explorer */}
          <div className="lg:col-span-7 flex flex-col justify-between bg-[#0B0F17] border border-slate-800 rounded-xl p-6 sm:p-8">
            <div>
              <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-b border-slate-800">
                <h3 className="font-display text-lg font-semibold text-white">
                  Off-World Artifact Reference Explorer
                </h3>
                <span className="text-xs font-mono text-slate-400">
                  Target Audience: Grades 4–9 · Storytelling &amp; Maps
                </span>
              </div>

              {/* Artifact Selector Tabs */}
              <div
                role="tablist"
                aria-label="Select off-world NASA hardware artifact"
                className="flex flex-wrap gap-2 py-5 border-b border-slate-800/80"
              >
                {ARTIFACT_SPOTLIGHTS.map((artifact) => {
                  const selected = artifact.id === activeArtifact.id;
                  return (
                    <button
                      key={artifact.id}
                      type="button"
                      role="tab"
                      aria-selected={selected}
                      onClick={() => setSelectedArtifactId(artifact.id)}
                      className={`px-3.5 py-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                        selected
                          ? 'bg-blue-600 text-white'
                          : 'bg-[#111827] text-slate-300 hover:text-white border border-slate-800'
                      }`}
                    >
                      {artifact.name}
                    </button>
                  );
                })}
              </div>

              {/* Active Artifact Telemetry Readout */}
              <div className="py-6 space-y-5">
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <div>
                    <div className="text-xs font-mono text-slate-400">
                      {activeArtifact.body} <span aria-hidden="true">·</span>{' '}
                      {activeArtifact.landingSite}
                    </div>
                    <h4 className="font-display text-2xl font-semibold text-white mt-1">
                      {activeArtifact.name}
                    </h4>
                  </div>
                  <div className="text-xs font-mono tabular-nums text-blue-400">
                    {activeArtifact.coordinates}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-4 border-y border-slate-800/80">
                  <div>
                    <div className="text-xs font-mono text-slate-400">
                      Operational Window
                    </div>
                    <div className="text-sm font-mono tabular-nums text-slate-100 mt-1">
                      {activeArtifact.activeYears}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs font-mono text-slate-400">
                      Landed Dry Mass
                    </div>
                    <div className="text-sm font-mono tabular-nums text-slate-100 mt-1">
                      {activeArtifact.massKg.toLocaleString()} kg
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <div className="text-xs font-mono text-slate-400 mb-1">
                      Scientific Legacy
                    </div>
                    <p className="text-sm text-slate-200 leading-relaxed">
                      {activeArtifact.scientificLegacy}
                    </p>
                  </div>
                  <div>
                    <div className="text-xs font-mono text-amber-400 mb-1">
                      Hackathon Storytelling Prompt
                    </div>
                    <p className="text-sm text-slate-300 leading-relaxed">
                      {activeArtifact.storyAngle}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-4">
              <div className="text-xs font-mono text-slate-400">
                Difficulty: Beginner / Intermediate · Datasets: LRO DEM, MRO HiRISE, PDS
              </div>
              <button
                type="button"
                onClick={() =>
                  onSelectForRegistration('abandoned-not-forgotten', [
                    'lro-lunar-dem',
                    'mro-hirise-sites',
                    'pds-mission-catalog',
                  ])
                }
                className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-md transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400"
              >
                Select This Challenge for Team
                <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
              </button>
            </div>
          </div>

          {/* Right: Editorial Visual Anchor */}
          <div className="lg:col-span-5 relative rounded-xl overflow-hidden border border-slate-800 bg-[#0B0F17] flex flex-col">
            <div className="relative flex-1 min-h-[300px]">
              <SafeImage
                src="/src/assets/images/track_lunar_south_pole_1794655339076.jpg"
                alt="Autonomous lunar exploration rover operating near shadowed crater rim on the Lunar South Pole"
                className="w-full h-full object-cover"
                fallbackTitle="Lunar South Pole Rover Surface"
              />
              <div
                aria-hidden="true"
                className="absolute inset-0 bg-gradient-to-t from-[#07090E]/90 via-transparent to-transparent"
              />
              <div className="absolute bottom-0 inset-x-0 p-6">
                <div className="flex items-center gap-2 text-xs font-mono text-slate-300 mb-1.5">
                  <Compass className="w-3.5 h-3.5 text-blue-400" aria-hidden="true" />
                  <span>68+ Cataloged Off-World Hardware Sites</span>
                </div>
                <p className="text-sm text-slate-200 leading-relaxed">
                  Combine HiRISE orbital imagery with first-person rover logs to help
                  students locate real engineering relics across the Moon and Mars.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
