import { useMemo, useState } from 'react';
import { Search, ArrowUpRight } from 'lucide-react';
import { CHALLENGES } from '../data/hackathonData';
import { Challenge, DifficultyLevel, TrackId } from '../types/hackathon';
import { filterChallenges } from '../utils/hackathonLogic';
import { SafeImage } from './SafeImage';

interface ChallengesSectionProps {
  selectedChallengeId: string;
  onInspectChallenge: (challenge: Challenge) => void;
  onSelectForTeam: (challenge: Challenge) => void;
}

const TRACK_FILTERS: Array<TrackId | 'All'> = [
  'All',
  'Planets & Moons',
  'Earth Observation',
  'Astrophysics',
  'Heliophysics',
];

const DIFFICULTY_FILTERS: Array<DifficultyLevel | 'All'> = [
  'All',
  'Beginner',
  'Intermediate',
  'Advanced',
];

export function ChallengesSection({
  selectedChallengeId,
  onInspectChallenge,
  onSelectForTeam,
}: ChallengesSectionProps) {
  const [trackFilter, setTrackFilter] = useState<TrackId | 'All'>('All');
  const [difficultyFilter, setDifficultyFilter] = useState<DifficultyLevel | 'All'>(
    'All'
  );
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = useMemo(
    () =>
      filterChallenges(CHALLENGES, trackFilter, difficultyFilter, searchQuery),
    [trackFilter, difficultyFilter, searchQuery]
  );

  const resetFilters = () => {
    setTrackFilter('All');
    setDifficultyFilter('All');
    setSearchQuery('');
  };

  return (
    <section
      id="challenges"
      className="py-16 lg:py-24 border-b border-slate-800/90 bg-[#07090E]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10">
          <div className="max-w-2xl">
            <p className="text-xs font-mono text-slate-400 mb-2">
              Official 2026 Challenge Catalog
            </p>
            <h2
              style={{ textWrap: 'balance' }}
              className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-white"
            >
              Mission Tracks &amp; Problem Statements
            </h2>
          </div>

          <div className="text-xs font-mono tabular-nums text-slate-400">
            Showing {filtered.length} of {CHALLENGES.length} featured challenges
          </div>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-8 border-b border-slate-800/80 mb-8">
          <div
            role="group"
            aria-label="Filter challenges by track"
            className="flex flex-wrap items-center gap-1.5 p-1 bg-[#0B0F17] border border-slate-800 rounded-lg"
          >
            {TRACK_FILTERS.map((track) => {
              const active = trackFilter === track;
              return (
                <button
                  key={track}
                  type="button"
                  onClick={() => setTrackFilter(track)}
                  aria-pressed={active}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                    active
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                  }`}
                >
                  {track === 'All' ? 'All Tracks' : track}
                </button>
              );
            })}
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <label htmlFor="challenge-search" className="sr-only">
              Search challenges
            </label>
            <div className="relative">
              <Search
                className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                id="challenge-search"
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search prompts or NASA centers..."
                className="pl-9 pr-3 py-2 text-sm bg-[#0B0F17] border border-slate-800 rounded-md text-slate-100 placeholder:text-slate-500 w-64 focus:outline-none focus:border-blue-500"
              />
            </div>

            <label htmlFor="difficulty-select" className="sr-only">
              Filter by difficulty
            </label>
            <select
              id="difficulty-select"
              value={difficultyFilter}
              onChange={(e) =>
                setDifficultyFilter(e.target.value as DifficultyLevel | 'All')
              }
              className="px-3 py-2 text-sm bg-[#0B0F17] border border-slate-800 rounded-md text-slate-200 focus:outline-none focus:border-blue-500"
            >
              {DIFFICULTY_FILTERS.map((level) => (
                <option key={level} value={level}>
                  {level === 'All' ? 'All Levels' : level}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Challenge Grid or Empty State */}
        {filtered.length === 0 ? (
          <div className="border border-slate-800 bg-[#0B0F17] rounded-xl p-12 text-center">
            <p className="font-display text-lg font-semibold text-white mb-2">
              No challenges match your current filters
            </p>
            <p className="text-sm text-slate-400 mb-6">
              Try clearing the search term or switching back to all mission tracks.
            </p>
            <button
              type="button"
              onClick={resetFilters}
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-md transition-colors"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((challenge) => {
              const isSelectedForTeam = selectedChallengeId === challenge.id;
              return (
                <article
                  key={challenge.id}
                  className={`flex flex-col justify-between rounded-xl border transition-colors overflow-hidden ${
                    isSelectedForTeam
                      ? 'border-blue-500 bg-[#0D1422]'
                      : 'border-slate-800 bg-[#0B0F17] hover:border-slate-700'
                  }`}
                >
                  <div>
                    {challenge.imageUrl && (
                      <div className="aspect-[4/3] w-full overflow-hidden border-b border-slate-800">
                        <SafeImage
                          src={challenge.imageUrl}
                          alt={challenge.imageAlt || challenge.title}
                          className="w-full h-full object-cover"
                          fallbackTitle={challenge.title}
                        />
                      </div>
                    )}

                    <div className="p-6">
                      <div className="text-xs font-mono text-slate-400 mb-2">
                        {challenge.track} <span aria-hidden="true">·</span>{' '}
                        {challenge.difficulty} <span aria-hidden="true">·</span>{' '}
                        {challenge.center}
                      </div>

                      <h3 className="font-display text-lg font-semibold text-white leading-snug mb-3">
                        {challenge.index}. {challenge.title}
                      </h3>

                      <p className="text-sm text-slate-300 leading-relaxed">
                        {challenge.summary}
                      </p>
                    </div>
                  </div>

                  <div className="px-6 py-4 border-t border-slate-800/80 flex items-center justify-between gap-3">
                    <button
                      type="button"
                      onClick={() => onInspectChallenge(challenge)}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-400 hover:text-blue-300 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-sm"
                    >
                      Inspect Brief
                      <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
                    </button>

                    <button
                      type="button"
                      onClick={() => onSelectForTeam(challenge)}
                      className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                        isSelectedForTeam
                          ? 'bg-blue-600/20 text-blue-300 border border-blue-500/40'
                          : 'bg-slate-900 text-slate-200 hover:bg-slate-800 border border-slate-700'
                      }`}
                    >
                      {isSelectedForTeam ? 'Selected for Team' : 'Select Track'}
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
