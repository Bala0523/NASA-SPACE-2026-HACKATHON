import { useEffect, useRef, useState } from 'react';
import { ExternalLink, Loader2, Send, Sparkles, X } from 'lucide-react';
import type { AstraMessage, LearningMode } from '../types/museum';

interface AstraAssistantPanelProps {
  learningMode: LearningMode;
  drawerOpen: boolean;
  onOpenDrawer: () => void;
  onCloseDrawer: () => void;
}

const SAMPLE_PROMPTS = [
  'Why did NASA leave equipment on the Moon?',
  'What happened to the Apollo Lunar Module?',
  'What was the purpose of the Spirit Rover?',
  'Which equipment is still operational?',
  'What discoveries were made by Opportunity?',
  'What is the difference between a lander and a rover?',
];

const WAVE_HEIGHTS = [0.45, 0.85, 0.65, 1.0, 0.55];

export function AstraAssistantPanel({
  learningMode,
  drawerOpen,
  onOpenDrawer,
  onCloseDrawer,
}: AstraAssistantPanelProps) {
  const [messages, setMessages] = useState<AstraMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      text: 'Hello Explorer! I am ASTRA, your Space Exploration Guide. Ask me why Apollo equipment remained on the Moon, how Spirit and Opportunity explored Mars, or which NASA rovers are still active today.',
      sources: [
        {
          title: 'NASA Solar System Exploration',
          url: 'https://science.nasa.gov/solar-system/',
        },
      ],
      mode: 'verified-knowledge-base',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [scrolledPastHero, setScrolledPastHero] = useState(false);
  const inlineScrollRef = useRef<HTMLDivElement | null>(null);
  const drawerScrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const onScroll = () => setScrolledPastHero(window.scrollY > 460);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    for (const el of [inlineScrollRef.current, drawerScrollRef.current]) {
      if (el) {
        el.scrollTop = el.scrollHeight;
      }
    }
  }, [messages.length, loading, drawerOpen]);

  const askAstra = async (questionText: string) => {
    const trimmed = questionText.trim();
    if (!trimmed || loading) return;

    const userMsg: AstraMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      text: trimmed,
    };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/astra', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: trimmed, learningMode }),
      });

      const data = (await res.json()) as {
        answer?: string;
        sources?: Array<{ title: string; url: string }>;
        mode?: 'gemini-live' | 'verified-knowledge-base';
        error?: string;
      };

      const assistantMsg: AstraMessage = {
        id: `a-${Date.now()}`,
        role: 'assistant',
        text:
          data.answer ??
          data.error ??
          'Information for that query is currently unavailable.',
        sources: data.sources ?? [],
        mode: data.mode ?? 'verified-knowledge-base',
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: 'assistant',
          text: 'Unable to reach the ASTRA server endpoint right now. Please try again in a moment.',
          mode: 'verified-knowledge-base',
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const renderWaveform = (compact: boolean) => (
    <span
      className={`inline-flex items-center gap-0.5 ${compact ? 'h-4' : 'h-5'}`}
      aria-hidden="true"
    >
      {WAVE_HEIGHTS.map((h, i) => (
        <span
          key={i}
          className={`w-[2.5px] rounded-full bg-[#38DFFF] ${
            loading ? 'astra-wave-bar-active' : 'astra-wave-bar'
          }`}
          style={{
            height: `${Math.round(h * (compact ? 14 : 18))}px`,
            animationDelay: `${i * 0.14}s`,
          }}
        />
      ))}
    </span>
  );

  const renderChatInterface = (inDrawer: boolean) => (
    <div
      className={`holo-panel holo-grid-bg rounded-xl flex flex-col overflow-hidden ${
        inDrawer ? 'h-full' : 'min-h-[460px]'
      }`}
    >
      <div className="px-5 py-4 border-b border-white/[0.08] bg-[#0B1220] flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full border border-[#38DFFF]/45 bg-[#38DFFF]/10 flex items-center justify-center shrink-0">
            {renderWaveform(false)}
          </div>
          <div>
            <div className="inline-flex items-center gap-2 text-sm font-editorial font-semibold text-[#F5F7FA]">
              <span>ASTRA — Holographic AI Guide</span>
            </div>
            <p className="text-xs font-mono text-[#E7C9A1] mt-0.5">
              Verified NASA Records ·{' '}
              {learningMode === 'student' ? 'Student Mode' : 'Scientific Detail'}
            </p>
          </div>
        </div>

        {inDrawer && (
          <button
            type="button"
            onClick={onCloseDrawer}
            aria-label="Close ASTRA panel"
            className="p-2 rounded-lg text-[#A6B0C0] hover:text-[#F5F7FA] hover:bg-[#38DFFF]/15 border border-transparent hover:border-[#38DFFF]/35 cursor-pointer"
          >
            <X className="w-4 h-4" aria-hidden="true" />
          </button>
        )}
      </div>

      <div className="px-5 py-3 border-b border-white/[0.08] bg-[#080B12]/70 flex flex-wrap gap-2">
        {SAMPLE_PROMPTS.map((prompt) => (
          <button
            key={prompt}
            type="button"
            onClick={() => askAstra(prompt)}
            className="px-2.5 py-1 text-xs text-[#A6B0C0] hover:text-[#8BEAFF] bg-white/[0.04] hover:bg-[#38DFFF]/12 border border-white/12 hover:border-[#38DFFF]/40 rounded-md transition-colors cursor-pointer text-left"
          >
            {prompt}
          </button>
        ))}
      </div>

      <div
        ref={inDrawer ? drawerScrollRef : inlineScrollRef}
        className={`flex-1 overflow-y-auto p-5 space-y-4 ${
          inDrawer ? 'min-h-0' : 'max-h-[380px]'
        }`}
      >
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${
              msg.role === 'user' ? 'items-end' : 'items-start'
            }`}
          >
            <div
              className={`max-w-[88%] rounded-xl px-4 py-3 text-sm leading-relaxed ${
                msg.role === 'user'
                  ? 'bg-[#101B2D] border border-[#38DFFF]/45 text-[#F5F7FA]'
                  : 'bg-[#080B12]/90 border border-white/[0.08] text-[#A6B0C0]'
              }`}
            >
              <p className="whitespace-pre-line text-[#F5F7FA]/95">{msg.text}</p>

              {msg.role === 'assistant' && msg.sources && msg.sources.length > 0 && (
                <div className="mt-3 pt-2.5 border-t border-white/[0.08] flex flex-wrap items-center gap-3 text-xs">
                  {msg.sources.map((src) => (
                    <a
                      key={src.url}
                      href={src.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[#38DFFF] hover:text-[#8BEAFF] underline underline-offset-4"
                    >
                      <span>{src.title}</span>
                      <ExternalLink className="w-3 h-3" aria-hidden="true" />
                    </a>
                  ))}
                </div>
              )}

              {msg.role === 'assistant' && msg.mode && (
                <div className="mt-2 text-[11px] font-mono text-[#737F91]">
                  {msg.mode === 'gemini-live'
                    ? 'Source: Gemini AI + Verified NASA Catalog'
                    : 'Mode: Verified NASA Knowledge Base (Demo Fallback)'}
                </div>
              )}
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex items-center gap-2 text-xs font-mono text-[#38DFFF]">
            <Loader2 className="w-4 h-4 animate-spin" aria-hidden="true" />
            <span>ASTRA is consulting NASA mission records...</span>
          </div>
        )}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          askAstra(input);
        }}
        className="p-4 border-t border-white/[0.08] bg-[#0B1220] flex items-center gap-2"
      >
        <label
          htmlFor={inDrawer ? 'astra-drawer-input' : 'astra-inline-input'}
          className="sr-only"
        >
          Ask ASTRA a question about NASA Moon or Mars equipment
        </label>
        <input
          id={inDrawer ? 'astra-drawer-input' : 'astra-inline-input'}
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask ASTRA about Apollo, Spirit, Opportunity, Curiosity..."
          className="flex-1 px-3.5 py-2.5 text-sm bg-[#080B12] border border-white/15 rounded-lg text-[#F5F7FA] placeholder:text-[#737F91] focus:outline-2 focus:outline-[#38DFFF]"
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          aria-label="Send message to ASTRA"
          className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs sm:text-sm font-semibold text-[#080B12] bg-[#38DFFF] hover:bg-[#8BEAFF] disabled:opacity-50 rounded-lg cursor-pointer whitespace-nowrap"
        >
          <Send className="w-4 h-4" aria-hidden="true" />
          <span>Ask</span>
        </button>
      </form>
    </div>
  );

  return (
    <>
      <section
        id="astra-guide"
        className="py-20 lg:py-24 border-b border-white/[0.08] bg-[#0B1220]/45"
      >
        <div className="max-w-[1040px] mx-auto px-4 sm:px-6">
          <div className="mb-8">
            <p className="text-xs font-mono tracking-[0.16em] uppercase text-[#38DFFF] mb-2.5">
              09 · Holographic AI Space Guide
            </p>
            <h2 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#F5F7FA] tracking-[-0.02em]">
              Ask ASTRA About Forgotten &amp; Active Hardware
            </h2>
          </div>

          {renderChatInterface(false)}
        </div>
      </section>

      {/* Floating Bottom-Right Holographic ASTRA Launcher (appears below Hero) */}
      {!drawerOpen && scrolledPastHero && (
        <button
          type="button"
          onClick={onOpenDrawer}
          data-testid="floating-astra-launcher"
          aria-label="Open Floating ASTRA Holographic AI Assistant"
          className="fixed bottom-5 right-5 z-40 inline-flex items-center gap-2.5 px-4 py-3 rounded-full bg-[#0B1220]/95 border border-[#38DFFF]/50 text-[#8BEAFF] hover:text-[#F5F7FA] hover:border-[#38DFFF] shadow-[0_8px_28px_rgba(8,11,18,0.65)] transition-all cursor-pointer"
        >
          {renderWaveform(true)}
          <span className="font-mono text-xs font-semibold tracking-wider">
            ASTRA AI
          </span>
          <Sparkles className="w-3.5 h-3.5 text-[#38DFFF]" aria-hidden="true" />
        </button>
      )}

      {drawerOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="ASTRA Space Exploration Guide"
          className="fixed inset-0 z-50 bg-black/75 flex justify-end"
        >
          <div className="w-full max-w-lg h-full p-3 sm:p-4 bg-[#080B12]">
            {renderChatInterface(true)}
          </div>
        </div>
      )}
    </>
  );
}
