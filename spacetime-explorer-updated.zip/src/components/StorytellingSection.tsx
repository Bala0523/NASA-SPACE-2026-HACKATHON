import { useState } from 'react';
import { motion } from 'motion/react';
import { Check, Share2, Sparkles } from 'lucide-react';
import type { LearningMode, SpaceArtifact } from '../types/museum';
import { getObjectOfTheDay } from '../utils/museumLogic';
import { SafeImage } from './SafeImage';

interface StorytellingSectionProps {
  artifacts: SpaceArtifact[];
  selectedStoryId: string;
  onSelectStoryId: (id: string) => void;
  learningMode: LearningMode;
  onChangeLearningMode: (mode: LearningMode) => void;
}

export function StorytellingSection({
  artifacts,
  selectedStoryId,
  onSelectStoryId,
  learningMode,
  onChangeLearningMode,
}: StorytellingSectionProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const selected =
    artifacts.find((a) => a.id === selectedStoryId) ?? artifacts[0];
  const dailyFeatured = getObjectOfTheDay(artifacts);

  const handleShare = async () => {
    const shareText = `${selected.name} (${selected.missionName}, ${selected.missionYear}) — ${selected.scientificContribution} | Explore via SpaceTime Explorer`;
    try {
      await navigator.clipboard.writeText(shareText);
      setCopiedId(selected.id);
      setTimeout(() => setCopiedId(null), 2200);
    } catch {
      setCopiedId(selected.id);
      setTimeout(() => setCopiedId(null), 2200);
    }
  };

  return (
    <section
      id="mission-storytelling"
      className="py-20 lg:py-24 border-b border-white/[0.08] bg-gradient-to-b from-[#0B1220]/55 to-[#080B12]"
    >
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
        {dailyFeatured && (
          <div className="mb-14 holo-panel holo-grid-bg holo-scan-overlay rounded-xl p-6 sm:p-7 flex flex-col md:flex-row md:items-center justify-between gap-5">
            <div>
              <div className="inline-flex items-center gap-1.5 text-[11px] font-mono tracking-[0.16em] uppercase text-[#E7C9A1]">
                <Sparkles className="w-3.5 h-3.5 text-[#38DFFF]" aria-hidden="true" />
                <span>Space Object of the Day</span>
              </div>
              <h3 className="mt-1.5 font-editorial text-xl sm:text-2xl font-semibold text-[#F5F7FA]">
                {dailyFeatured.name}
              </h3>
              <p className="mt-1.5 text-sm text-[#A6B0C0] max-w-2xl leading-relaxed">
                {learningMode === 'student'
                  ? dailyFeatured.purposeStudent
                  : dailyFeatured.purposeScientific}
              </p>
            </div>
            <button
              type="button"
              onClick={() => onSelectStoryId(dailyFeatured.id)}
              className="px-5 py-2.5 text-xs font-mono font-semibold text-[#080B12] bg-[#38DFFF] hover:bg-[#8BEAFF] rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Read Today&apos;s Story
            </button>
          </div>
        )}

        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-12">
          <div>
            <p className="text-xs font-mono tracking-[0.16em] uppercase text-[#38DFFF] mb-2.5">
              04 · Five-Stage Mission Storytelling
            </p>
            <h2 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#F5F7FA] tracking-[-0.02em]">
              From Blueprint to Eternal Legacy
            </h2>
            <p className="mt-3 text-[#A6B0C0] max-w-2xl text-sm sm:text-base leading-relaxed">
              Follow any spacecraft across five chapters—why NASA built it, how
              it traveled across space, what it discovered, and why its story
              matters today.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <label htmlFor="story-artifact-select" className="sr-only">
              Select equipment story
            </label>
            <select
              id="story-artifact-select"
              value={selected.id}
              onChange={(e) => onSelectStoryId(e.target.value)}
              className="px-3.5 py-2 text-sm bg-[#0B1220] border border-white/15 rounded-lg text-[#F5F7FA] focus:outline-2 focus:outline-[#38DFFF]"
            >
              {artifacts.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.missionYear} · {a.name}
                </option>
              ))}
            </select>

            <div className="inline-flex items-center p-1 bg-[#0B1220] border border-white/12 rounded-lg">
              <button
                type="button"
                onClick={() => onChangeLearningMode('student')}
                className={`px-3 py-1.5 text-xs font-mono rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                  learningMode === 'student'
                    ? 'bg-[#38DFFF] text-[#080B12] font-semibold'
                    : 'text-[#A6B0C0] hover:text-[#F5F7FA]'
                }`}
              >
                Student Mode
              </button>
              <button
                type="button"
                onClick={() => onChangeLearningMode('scientific')}
                className={`px-3 py-1.5 text-xs font-mono rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                  learningMode === 'scientific'
                    ? 'bg-[#38DFFF] text-[#080B12] font-semibold'
                    : 'text-[#A6B0C0] hover:text-[#F5F7FA]'
                }`}
              >
                Scientific Detail
              </button>
            </div>

            <button
              type="button"
              onClick={handleShare}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-[#F5F7FA] bg-white/[0.04] hover:bg-white/[0.08] border border-white/15 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              {copiedId === selected.id ? (
                <>
                  <Check className="w-3.5 h-3.5 text-[#38DFFF]" aria-hidden="true" />
                  <span className="text-[#38DFFF]">Story Copied</span>
                </>
              ) : (
                <>
                  <Share2 className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Share Discovery</span>
                </>
              )}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          <div className="lg:col-span-4 lg:sticky lg:top-24 holo-panel rounded-xl overflow-hidden group">
            <div className="h-56 relative overflow-hidden">
              <SafeImage
                src={selected.imageUrl}
                alt={selected.name}
                className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.03]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#080B12] via-transparent to-transparent" />
            </div>
            <div className="p-6 space-y-3">
              <div className="text-xs font-mono text-[#E7C9A1]">
                {selected.body} · {selected.siteName}
              </div>
              <h3 className="font-editorial text-xl font-semibold text-[#F5F7FA]">
                {selected.name}
              </h3>
              <p className="text-xs text-[#737F91] leading-relaxed">
                {selected.thenVsNow.orbitalVerification}
              </p>
            </div>
          </div>

          <div className="lg:col-span-8 border-t border-b border-white/[0.08] divide-y divide-white/[0.08]">
            {selected.storyStages.map((stage, idx) => (
              <motion.div
                key={`${selected.id}-stage-${stage.stageNumber}`}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.25, delay: idx * 0.04 }}
                className="py-7 sm:py-8 grid grid-cols-1 sm:grid-cols-12 gap-4 sm:gap-6 items-start"
              >
                <div className="sm:col-span-2 flex sm:flex-col items-baseline sm:items-start gap-2">
                  <span className="font-display text-3xl sm:text-4xl font-bold tabular-nums text-[#38DFFF]/80 leading-none">
                    0{stage.stageNumber}
                  </span>
                  <span className="text-[11px] font-mono text-[#E7C9A1] uppercase tracking-[0.14em]">
                    {stage.title}
                  </span>
                </div>

                <div className="sm:col-span-10">
                  <div className="text-[11px] font-mono text-[#737F91] tabular-nums mb-1.5">
                    {selected.missionName} · {selected.missionYear}
                  </div>
                  <h4 className="font-editorial text-lg sm:text-xl font-semibold text-[#F5F7FA]">
                    {stage.subtitle}
                  </h4>
                  <p className="mt-2.5 text-sm sm:text-base text-[#A6B0C0] leading-relaxed max-w-prose">
                    {learningMode === 'student'
                      ? stage.studentText
                      : stage.scientificText}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
