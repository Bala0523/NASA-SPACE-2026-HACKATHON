import { useState } from 'react';
import { Check, Copy, Plus } from 'lucide-react';
import { NASA_DATASETS } from '../data/hackathonData';

interface DatasetsSectionProps {
  missionKitIds: string[];
  onToggleDataset: (datasetId: string) => void;
}

export function DatasetsSection({
  missionKitIds,
  onToggleDataset,
}: DatasetsSectionProps) {
  const [activeDatasetId, setActiveDatasetId] = useState(NASA_DATASETS[0].id);
  const [copiedEndpoint, setCopiedEndpoint] = useState<string | null>(null);

  const activeDataset =
    NASA_DATASETS.find((d) => d.id === activeDatasetId) ?? NASA_DATASETS[0];

  const isInKit = missionKitIds.includes(activeDataset.id);

  const handleCopyEndpoint = async (endpoint: string) => {
    try {
      await navigator.clipboard.writeText(endpoint);
      setCopiedEndpoint(endpoint);
      window.setTimeout(() => setCopiedEndpoint(null), 1800);
    } catch {
      setCopiedEndpoint(endpoint);
      window.setTimeout(() => setCopiedEndpoint(null), 1800);
    }
  };

  return (
    <section
      id="datasets"
      className="py-16 lg:py-24 border-b border-slate-800/90 bg-[#0B0F17]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
          <div className="max-w-2xl">
            <p className="text-xs font-mono text-slate-400 mb-2">
              Open Science Data Sandbox
            </p>
            <h2
              style={{ textWrap: 'balance' }}
              className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-white"
            >
              NASA Open Datasets &amp; Telemetry Feeds
            </h2>
          </div>

          <div className="text-xs font-mono tabular-nums text-blue-400">
            Mission Kit Selected: {missionKitIds.length} dataset
            {missionKitIds.length === 1 ? '' : 's'}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: Dataset Catalog List */}
          <div className="lg:col-span-5 space-y-2.5">
            {NASA_DATASETS.map((dataset) => {
              const selected = dataset.id === activeDataset.id;
              const added = missionKitIds.includes(dataset.id);

              return (
                <div
                  key={dataset.id}
                  className={`rounded-lg border transition-colors p-4 flex items-center justify-between gap-3 ${
                    selected
                      ? 'border-blue-500 bg-[#111827]'
                      : 'border-slate-800 bg-[#07090E] hover:border-slate-700'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => setActiveDatasetId(dataset.id)}
                    className="text-left min-w-0 flex-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-sm"
                  >
                    <div className="text-xs font-mono text-slate-400 truncate">
                      {dataset.category} <span aria-hidden="true">·</span>{' '}
                      {dataset.format}
                    </div>
                    <div className="text-sm font-semibold text-white truncate mt-0.5">
                      {dataset.name}
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => onToggleDataset(dataset.id)}
                    aria-label={
                      added
                        ? `Remove ${dataset.name} from Mission Kit`
                        : `Add ${dataset.name} to Mission Kit`
                    }
                    className={`inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                      added
                        ? 'bg-blue-600 text-white'
                        : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-700'
                    }`}
                  >
                    {added ? (
                      <>
                        <Check className="w-3.5 h-3.5" aria-hidden="true" />
                        In Kit
                      </>
                    ) : (
                      <>
                        <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                        Add
                      </>
                    )}
                  </button>
                </div>
              );
            })}
          </div>

          {/* Right: Telemetry Schema & Sample Payload Inspector */}
          <div className="lg:col-span-7 bg-[#07090E] border border-slate-800 rounded-xl p-6 sm:p-8">
            <div className="flex flex-wrap items-start justify-between gap-4 pb-5 border-b border-slate-800">
              <div>
                <div className="text-xs font-mono text-slate-400">
                  {activeDataset.sourceCenter}
                </div>
                <h3 className="font-display text-xl sm:text-2xl font-bold text-white mt-1">
                  {activeDataset.name}
                </h3>
              </div>

              <button
                type="button"
                onClick={() => onToggleDataset(activeDataset.id)}
                className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                  isInKit
                    ? 'bg-blue-600/20 text-blue-300 border border-blue-500/40'
                    : 'bg-blue-600 hover:bg-blue-500 text-white'
                }`}
              >
                {isInKit ? (
                  <>
                    <Check className="w-3.5 h-3.5" aria-hidden="true" />
                    Added to Mission Kit
                  </>
                ) : (
                  <>
                    <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                    Add to Mission Kit
                  </>
                )}
              </button>
            </div>

            <p className="text-sm text-slate-300 leading-relaxed py-5 border-b border-slate-800/80">
              {activeDataset.description}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 py-5 border-b border-slate-800/80">
              <div>
                <div className="text-xs font-mono text-slate-400">
                  Spatial / Spectral Resolution
                </div>
                <div className="text-sm font-mono tabular-nums text-white mt-1">
                  {activeDataset.resolution}
                </div>
              </div>
              <div>
                <div className="text-xs font-mono text-slate-400">
                  Update Cadence
                </div>
                <div className="text-sm font-mono text-white mt-1">
                  {activeDataset.cadence}
                </div>
              </div>
              <div>
                <div className="text-xs font-mono text-slate-400">
                  Delivery Format
                </div>
                <div className="text-sm font-mono text-white mt-1">
                  {activeDataset.format}
                </div>
              </div>
            </div>

            {/* Endpoint Bar */}
            <div className="py-5">
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-xs font-mono text-slate-400">
                  Query Endpoint
                </span>
                <button
                  type="button"
                  onClick={() => handleCopyEndpoint(activeDataset.endpoint)}
                  className="inline-flex items-center gap-1.5 text-xs font-mono text-blue-400 hover:text-blue-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-sm"
                >
                  {copiedEndpoint === activeDataset.endpoint ? (
                    <>
                      <Check className="w-3.5 h-3.5" aria-hidden="true" />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" aria-hidden="true" />
                      Copy URL
                    </>
                  )}
                </button>
              </div>
              <div className="px-3.5 py-2.5 rounded-md bg-[#0B0F17] border border-slate-800 text-xs font-mono text-slate-200 overflow-x-auto">
                {activeDataset.endpoint}
              </div>
            </div>

            {/* Sample Telemetry Payload */}
            <div>
              <div className="text-xs font-mono text-slate-400 mb-2">
                Sample Telemetry Record
              </div>
              <pre className="p-4 rounded-lg bg-[#0B0F17] border border-slate-800 text-xs font-mono text-slate-200 overflow-x-auto leading-relaxed tabular-nums">
                {JSON.stringify(activeDataset.samplePayload, null, 2)}
              </pre>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
