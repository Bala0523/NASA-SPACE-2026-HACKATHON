import { useEffect, useState } from 'react';
import { Menu, Sparkles, X } from 'lucide-react';

interface NavbarProps {
  onOpenAstra: () => void;
  activeChapter?: string;
}

const NAV_ITEMS = [
  { label: 'HOME', href: '#top', chapterId: 'top' },
  { label: 'MOON', href: '#moon-explorer', chapterId: 'moon-explorer' },
  { label: 'MARS', href: '#mars-explorer', chapterId: 'mars-explorer' },
  { label: '3D MUSEUM', href: '#equipment-museum', chapterId: 'equipment-museum' },
  { label: 'STORIES', href: '#mission-storytelling', chapterId: 'mission-storytelling' },
];

export function Navbar({ onOpenAstra, activeChapter = 'top' }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 36);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const solidHeader = scrolled || mobileOpen;

  return (
    <header
      className={`fixed top-0 inset-x-0 z-40 transition-[background-color,border-color,box-shadow,backdrop-filter] duration-500 ${
        solidHeader
          ? 'bg-[#080B12]/85 backdrop-blur-xl border-b border-white/[0.08] shadow-[0_10px_30px_-12px_rgba(0,0,0,0.6)]'
          : 'bg-gradient-to-b from-[#080B12]/80 to-transparent border-b border-transparent'
      }`}
    >
      <div className={`max-w-[1320px] mx-auto px-4 sm:px-6 ${scrolled ? 'h-14' : 'h-16'} transition-[height] duration-300 flex items-center justify-between gap-3 sm:gap-6`}>
        <a
          href="#top"
          className="font-display text-xs sm:text-base font-bold tracking-[0.06em] sm:tracking-[0.1em] text-[#F5F7FA] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#38DFFF] rounded"
        >
          SPACETIME <span className="text-[#38DFFF]">EXPLORER</span>
        </a>

        <nav
          aria-label="Primary navigation"
          className="hidden lg:flex items-center gap-7 text-[11px] font-mono tracking-[0.14em]"
        >
          {NAV_ITEMS.map((item) => {
            const isActive = activeChapter === item.chapterId;
            return (
              <a
                key={item.href}
                href={item.href}
                aria-current={isActive ? 'true' : undefined}
                className={`relative transition-colors duration-200 whitespace-nowrap shrink-0 py-1.5 focus-visible:outline-2 focus-visible:outline-[#38DFFF] after:absolute after:left-0 after:-bottom-px after:h-px after:w-full after:origin-left after:bg-[#38DFFF] after:transition-transform after:duration-300 ${
                  isActive
                    ? 'text-[#F5F7FA] after:scale-x-100'
                    : 'text-[#A6B0C0] hover:text-[#F5F7FA] after:scale-x-0 hover:after:scale-x-100'
                }`}
              >
                {item.label}
              </a>
            );
          })}
        </nav>

        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <button
            type="button"
            onClick={onOpenAstra}
            className="inline-flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-1.5 sm:py-2 text-[11px] sm:text-xs font-mono tracking-[0.08em] sm:tracking-[0.12em] font-semibold text-[#8BEAFF] bg-[#0B1220]/85 hover:bg-[#38DFFF]/15 border border-[#38DFFF]/40 rounded-lg transition-all duration-200 active:scale-[0.97] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#38DFFF]"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#38DFFF]" aria-hidden="true" />
            <span>ASTRA AI</span>
          </button>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={mobileOpen}
            className="lg:hidden inline-flex items-center justify-center w-9 h-9 sm:w-10 sm:h-10 rounded-lg border border-white/15 bg-[#0B1220]/80 text-[#F5F7FA] hover:border-[#38DFFF]/50 cursor-pointer"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <nav
          aria-label="Mobile navigation"
          className="nav-drop lg:hidden border-t border-white/[0.08] bg-[#080B12]/95 backdrop-blur-xl px-4 py-3 flex flex-wrap gap-2"
        >
          {NAV_ITEMS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={() => setMobileOpen(false)}
              className={`px-3.5 py-2.5 min-h-11 inline-flex items-center text-xs font-mono tracking-wider rounded-md whitespace-nowrap border active:scale-[0.97] transition-transform ${
                activeChapter === item.chapterId
                  ? 'text-[#F5F7FA] border-[#38DFFF]/60 bg-[#38DFFF]/10'
                  : 'text-[#A6B0C0] hover:text-[#F5F7FA] bg-[#0B1220] border-white/10'
              }`}
            >
              {item.label}
            </a>
          ))}
        </nav>
      )}
    </header>
  );
}
