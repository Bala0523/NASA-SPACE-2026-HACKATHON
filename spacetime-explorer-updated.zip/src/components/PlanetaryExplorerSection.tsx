import { useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  MapPin,
  Orbit,
  Sparkles,
} from 'lucide-react';
import type { BodyTarget, LearningMode, SpaceArtifact } from '../types/museum';
import { SafeImage } from './SafeImage';
import { PlanetaryGlobe3D } from './three/PlanetaryGlobe3D';

interface PlanetaryExplorerSectionProps {
  sectionId: string;
  sectionIndex: string;
  body: BodyTarget;
  title: string;
  subtitle: string;
  artifacts: SpaceArtifact[];
  selectedId: string;
  onSelectId: (id: string) => void;
  learningMode: LearningMode;
  onJumpToStory: (id: string) => void;
  onJumpToMuseum: (id: string) => void;
}

export function PlanetaryExplorerSection({
  sectionId,
  sectionIndex,
  body,
  title,
  subtitle,
  artifacts,
  selectedId,
  onSelectId,
  learningMode,
  onJumpToStory,
  onJumpToMuseum,
}: PlanetaryExplorerSectionProps) {
  const [viewMode, setViewMode] = useState<'then' | 'now'>('then');

  const currentIdx = Math.max(
    0,
    artifacts.findIndex((a) => a.id === selectedId),
  );
  const selected = artifacts[currentIdx] ?? artifacts[0];

  const handleTourStep = (dir: -1 | 1) => {
    const nextIdx = (currentIdx + dir + artifacts.length) % artifacts.length;
    onSelectId(artifacts[nextIdx].id);
  };

  const isMars = body === 'Mars';
  const fallbackImg = isMars
    ? '/src/assets/images/mars_rover_jezero_1794656366254.jpg'
    : '/src/assets/images/apollo_lunar_module_museum_1794656365730.jpg';

  const statusTone =
    selected.status === 'Active Operational'
      ? 'text-emerald-300'
      : selected.status === 'Intentionally Discarded'
        ? 'text-amber-300'
        : 'text-cyan-200';

  return (
    <section
      id={sectionId}
      className={`py-20 lg:py-24 border-b border-white/[0.08] ${
        isMars
          ? 'bg-gradient-to-b from-[#110908] via-[#080B12] to-[#080B12]'
          : 'bg-gradient-to-b from-[#0B1220]/70 to-[#080B12]'
      }`}
    >
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10">
          <div>
            <p
              className={`text-xs font-mono tracking-[0.16em] uppercase mb-2.5 ${
                isMars ? 'text-[#F07843]' : 'text-[#38DFFF]'
              }`}
            >
              {sectionIndex} · Interactive {body} Exploration
            </p>
            <h2 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#F5F7FA] tracking-[-0.02em]">
              {title}
            </h2>
            <p className="mt-3 text-[#A6B0C0] max-w-2xl text-sm sm:text-base leading-relaxed">
              {subtitle}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <span className="text-xs font-mono text-[#737F91] mr-1">
              Virtual Tour
            </span>
            <button
              type="button"
              onClick={() => handleTourStep(-1)}
              aria-label={`Previous ${body} site`}
              className="p-2 rounded-lg bg-[#0B1220] border border-white/[0.12] text-[#A6B0C0] hover:text-[#38DFFF] hover:border-[#38DFFF]/50 transition-colors cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" aria-hidden="true" />
            </button>
            <span className="text-xs font-mono tabular-nums text-[#F5F7FA] px-2">
              {currentIdx + 1} / {artifacts.length}
            </span>
            <button
              type="button"
              onClick={() => handleTourStep(1)}
              aria-label={`Next ${body} site`}
              className="p-2 rounded-lg bg-[#0B1220] border border-white/[0.12] text-[#A6B0C0] hover:text-[#38DFFF] hover:border-[#38DFFF]/50 transition-colors cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" aria-hidden="true" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Globe & Landing Site Index (Alternates Left on Moon, Right on Mars) */}
          <div
            className={`lg:col-span-5 space-y-5 min-w-0 ${
              isMars ? 'lg:order-2' : 'lg:order-1'
            }`}
          >
            <PlanetaryGlobe3D
              body={body}
              artifacts={artifacts}
              selectedId={selected.id}
              onSelectArtifact={onSelectId}
              fallbackImage={fallbackImg}
            />

            <div className="border-t border-b border-white/[0.08] divide-y divide-white/[0.08]">
              {artifacts.map((item) => {
                const isSel = item.id === selected.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => onSelectId(item.id)}
                    className={`w-full text-left px-4 py-3.5 transition-colors flex items-start justify-between gap-3 cursor-pointer ${
                      isSel
                        ? isMars
                          ? 'bg-[#F07843]/12 border-l-2 border-l-[#F07843]'
                          : 'bg-[#38DFFF]/10 border-l-2 border-l-[#38DFFF]'
                        : 'hover:bg-white/[0.03]'
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="text-sm font-semibold text-[#F5F7FA] truncate">
                        {item.name}
                      </div>
                      <div className="mt-1 flex flex-wrap items-center gap-x-2 text-xs text-[#737F91]">
                        <span className="font-mono tabular-nums text-[#E7C9A1]">
                          {item.missionYear}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{item.siteName}</span>
                        <span aria-hidden="true">·</span>
                        <span
                          className={
                            item.status === 'Active Operational'
                              ? 'text-[#38DFFF] font-medium'
                              : item.status === 'Intentionally Discarded'
                                ? 'text-[#F07843]'
                                : 'text-[#A6B0C0]'
                          }
                        >
                          {item.status}
                        </span>
                      </div>
                    </div>
                    <MapPin
                      className={`w-4 h-4 shrink-0 mt-0.5 ${
                        isSel
                          ? isMars
                            ? 'text-[#F07843]'
                            : 'text-[#38DFFF]'
                          : 'text-[#737F91]'
                      }`}
                      aria-hidden="true"
                    />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Open Editorial Specimen Dossier (Alternates Right on Moon, Left on Mars) */}
          <article
            className={`lg:col-span-7 min-w-0 rounded-xl overflow-hidden ${
              isMars ? 'holo-panel-warm lg:order-1' : 'holo-panel lg:order-2'
            }`}
          >
            <div className="group relative h-64 sm:h-80 overflow-hidden border-b border-white/[0.08]">
              <SafeImage
                src={selected.imageUrl}
                alt={selected.name}
                className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.03]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#080B12] via-[#080B12]/30 to-transparent" />

              <div className="absolute top-3 right-3 flex items-center p-1 bg-[#080B12]/90 border border-white/15 rounded-lg">
                <button
                  type="button"
                  onClick={() => setViewMode('then')}
                  className={`px-2.5 py-1 text-xs font-mono rounded-md transition-colors cursor-pointer ${
                    viewMode === 'then'
                      ? 'bg-[#38DFFF] text-[#080B12] font-semibold'
                      : 'text-[#A6B0C0] hover:text-[#F5F7FA]'
                  }`}
                >
                  Mission Era
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode('now')}
                  className={`px-2.5 py-1 text-xs font-mono rounded-md transition-colors cursor-pointer ${
                    viewMode === 'now'
                      ? 'bg-[#38DFFF] text-[#080B12] font-semibold'
                      : 'text-[#A6B0C0] hover:text-[#F5F7FA]'
                  }`}
                >
                  Orbital Verification
                </button>
              </div>

              <div className="absolute bottom-4 left-6 right-6">
                <div className="text-xs font-mono text-[#E7C9A1] tabular-nums">
                  {selected.missionName} · {selected.missionYear} ·{' '}
                  {selected.coordinates.label}
                </div>
                <h3 className="mt-1 font-editorial text-2xl sm:text-3xl font-semibold text-[#F5F7FA]">
                  {selected.name}
                </h3>
              </div>
            </div>

            <div className="p-6 sm:p-7 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-5 border-b border-white/[0.08]">
                <div>
                  <span className="text-[11px] font-mono uppercase tracking-[0.14em] text-[#737F91] block">
                    Operational Status
                  </span>
                  <span className={`text-sm font-semibold ${statusTone}`}>
                    {selected.status}
                  </span>
                </div>
                <p className="text-xs text-[#A6B0C0] sm:text-right max-w-md leading-relaxed">
                  {selected.statusNote}
                </p>
              </div>

              <div className="text-xs sm:text-sm text-[#A6B0C0] leading-relaxed border-l-2 border-[#38DFFF]/50 pl-4">
                <span className="font-mono text-[#E7C9A1] mr-2">
                  {viewMode === 'then' ? 'THEN ·' : 'NOW ·'}
                </span>
                {viewMode === 'then'
                  ? selected.thenVsNow.thenCaption
                  : `${selected.thenVsNow.nowCaption} (${selected.thenVsNow.orbitalVerification})`}
              </div>

              <dl className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm border-y border-white/[0.08] py-5">
                <div>
                  <dt className="text-[11px] font-mono uppercase tracking-[0.12em] text-[#737F91]">
                    Launch Date
                  </dt>
                  <dd className="mt-1 text-[#F5F7FA] font-mono tabular-nums">
                    {selected.launchDate}
                  </dd>
                </div>
                <div>
                  <dt className="text-[11px] font-mono uppercase tracking-[0.12em] text-[#737F91]">
                    Landing Date
                  </dt>
                  <dd className="mt-1 text-[#F5F7FA] font-mono tabular-nums">
                    {selected.landingDate}
                  </dd>
                </div>
                <div>
                  <dt className="text-[11px] font-mono uppercase tracking-[0.12em] text-[#737F91]">
                    Power &amp; Mass
                  </dt>
                  <dd className="mt-1 text-[#F5F7FA] tabular-nums">
                    {selected.massKg.toLocaleString()} kg ·{' '}
                    {selected.powerSource}
                  </dd>
                </div>
                <div>
                  <dt className="text-[11px] font-mono uppercase tracking-[0.12em] text-[#737F91]">
                    Mission End / Span
                  </dt>
                  <dd className="mt-1 text-[#F5F7FA] font-mono tabular-nums">
                    {selected.endDate}
                  </dd>
                </div>
              </dl>

              <div className="space-y-4 text-sm leading-relaxed">
                <div>
                  <h4
                    className={`text-[11px] font-mono uppercase tracking-[0.14em] ${
                      isMars ? 'text-[#F07843]' : 'text-[#38DFFF]'
                    }`}
                  >
                    Purpose of Equipment
                  </h4>
                  <p className="mt-1.5 text-[#F5F7FA]/90">
                    {learningMode === 'student'
                      ? selected.purposeStudent
                      : selected.purposeScientific}
                  </p>
                </div>
                <div>
                  <h4
                    className={`text-[11px] font-mono uppercase tracking-[0.14em] ${
                      isMars ? 'text-[#F07843]' : 'text-[#38DFFF]'
                    }`}
                  >
                    Scientific Contribution
                  </h4>
                  <p className="mt-1.5 text-[#A6B0C0]">
                    {selected.scientificContribution}
                  </p>
                </div>
                <div>
                  <h4
                    className={`text-[11px] font-mono uppercase tracking-[0.14em] ${
                      isMars ? 'text-[#F07843]' : 'text-[#38DFFF]'
                    }`}
                  >
                    {selected.status === 'Active Operational'
                      ? 'Why It Remains Operating on Surface'
                      : 'Why It Was Left Behind / Concluded'}
                  </h4>
                  <p className="mt-1.5 text-[#A6B0C0]">
                    {selected.whyLeftBehind}
                  </p>
                </div>
              </div>

              <div className="pt-5 border-t border-white/[0.08] flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap gap-2.5">
                  <button
                    type="button"
                    onClick={() => onJumpToStory(selected.id)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-mono font-semibold text-[#080B12] bg-[#38DFFF] hover:bg-[#8BEAFF] rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Open 5-Stage Story</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onJumpToMuseum(selected.id)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-[#F5F7FA] bg-white/[0.04] hover:bg-white/[0.09] border border-white/15 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <Orbit className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Inspect in 3D Museum</span>
                  </button>
                </div>

                <div className="flex flex-wrap gap-4">
                  {selected.references.map((ref) => (
                    <a
                      key={ref.url}
                      href={ref.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs text-[#38DFFF] hover:text-[#8BEAFF] underline underline-offset-4"
                    >
                      <span>{ref.label}</span>
                      <ExternalLink className="w-3 h-3" aria-hidden="true" />
                    </a>
                  ))}
                </div>
              </div>
            </div>
          </article>
        </div>
      </div>
    </section>
  );
}
