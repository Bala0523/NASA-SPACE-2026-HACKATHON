import { useEffect, useRef, useState } from 'react';
import { ChevronRight, Loader2, SkipForward } from 'lucide-react';
import { getIntroSceneState } from '../utils/museumLogic';
import { CinematicSurface3D } from './three/CinematicSurface3D';

interface CinematicIntro3DProps {
  onComplete: () => void;
}

const SCENE_TIMESTAMPS = [0.6, 4.4, 6.8, 9.4, 12.0] as const;

export function CinematicIntro3D({ onComplete }: CinematicIntro3DProps) {
  const [sceneReady, setSceneReady] = useState(false);
  const [elapsedSec, setElapsedSec] = useState(0);
  const [paused, setPaused] = useState(false);
  const startTimeRef = useRef<number | null>(null);

  useEffect(() => {
    if (!sceneReady || paused) return;

    startTimeRef.current = performance.now() - elapsedSec * 1000;
    const interval = window.setInterval(() => {
      if (startTimeRef.current === null) return;
      const next = (performance.now() - startTimeRef.current) / 1000;
      setElapsedSec(Math.min(12.6, next));
      if (next >= 12.6) {
        window.clearInterval(interval);
      }
    }, 90);

    return () => window.clearInterval(interval);
  }, [sceneReady, paused]);

  // Safety fallback: never lock visitors on loading overlay if WebGL takes > 2s
  useEffect(() => {
    const t = window.setTimeout(() => setSceneReady(true), 1600);
    return () => window.clearTimeout(t);
  }, []);

  const state = getIntroSceneState(elapsedSec);

  const jumpToScene = (idx: number) => {
    const targetSec = SCENE_TIMESTAMPS[idx] ?? 0;
    setPaused(true);
    setElapsedSec(targetSec);
    startTimeRef.current = performance.now() - targetSec * 1000;
  };

  return (
    <div
      data-testid="cinematic-intro-overlay"
      className="fixed inset-0 z-50 bg-[#080B12] text-[#F5F7FA] overflow-hidden select-none"
      role="region"
      aria-label="SpaceTime Explorer Cinematic 3D Mars Introduction"
    >
      {/* Live 3D Mars Cinematic Surface */}
      <div className="absolute inset-0">
        <CinematicSurface3D
          mode="intro"
          body="Mars"
          modelType="mer-rover"
          cameraProgress={state.cameraProgress}
          onSceneReady={() => setSceneReady(true)}
        />
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              'radial-gradient(circle at 50% 45%, transparent 32%, rgba(8, 11, 18, 0.78) 100%)',
          }}
        />
        <div
          className="absolute inset-x-0 bottom-0 h-44 pointer-events-none"
          style={{
            background:
              'linear-gradient(to top, rgba(8,11,18,0.96), transparent)',
          }}
        />
      </div>

      {/* Initial 3D Loading Curtain */}
      {!sceneReady && (
        <div className="absolute inset-0 z-30 bg-[#080B12] flex flex-col items-center justify-center gap-3 px-6 text-center">
          <Loader2
            className="w-7 h-7 text-[#38DFFF] animate-spin"
            aria-hidden="true"
          />
          <p className="font-mono text-xs tracking-[0.22em] text-[#38DFFF] uppercase">
            Initializing Martian Horizon Telemetry
          </p>
          <p className="text-xs text-[#A6B0C0]">
            Preparing 3D terrain, atmospheric scatter, and NASA rover geometry...
          </p>
        </div>
      )}

      {/* Top Cinematic Header & Skip Button */}
      <div className="relative z-20 flex items-center justify-between gap-4 px-5 sm:px-8 pt-5">
        <div className="inline-flex items-center gap-2.5 px-3 py-1.5 rounded border border-[#38DFFF]/25 bg-[#0B1220]/85">
          <span className="text-[11px] font-mono tracking-[0.16em] text-[#8BEAFF]">
            {state.phaseLabel}
          </span>
        </div>

        <button
          type="button"
          onClick={onComplete}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-[#38DFFF]/40 bg-[#0B1220]/90 hover:bg-[#38DFFF]/15 text-xs font-mono tracking-wider text-[#8BEAFF] hover:text-[#F5F7FA] transition-colors cursor-pointer whitespace-nowrap"
        >
          <span>SKIP INTRO</span>
          <SkipForward className="w-3.5 h-3.5" aria-hidden="true" />
        </button>
      </div>

      {/* Scene 2: Centered Cinematic Storytelling Typography */}
      {state.showStoryText && (
        <div className="relative z-20 h-[calc(100%-150px)] flex flex-col items-center justify-center px-6 text-center pointer-events-none">
          <p
            className="font-display font-bold text-[#F5F7FA] tracking-[0.12em] leading-tight transition-all duration-700"
            style={{
              fontSize: 'clamp(1.45rem, 3.8vw, 3.25rem)',
              textShadow: '0 2px 28px rgba(0, 0, 0, 0.85)',
            }}
          >
            {state.headlineLine1}
          </p>
          {state.headlineLine2 && (
            <p
              className="mt-4 font-display font-semibold text-[#F07843] tracking-[0.14em] transition-all duration-700"
              style={{
                fontSize: 'clamp(1.1rem, 2.5vw, 2.1rem)',
                textShadow: '0 2px 22px rgba(240, 120, 67, 0.35)',
              }}
            >
              {state.headlineLine2}
            </p>
          )}
        </div>
      )}

      {/* Scene 4 & 5: Holographic Cyan Telemetry Panels Around Rover */}
      {state.showRoverTelemetry && !state.showEnterCta && (
        <div className="relative z-20 h-[calc(100%-150px)] max-w-[1200px] mx-auto px-5 sm:px-8 flex flex-col justify-center pointer-events-none">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6 items-center">
            <div className="holo-panel holo-grid-bg holo-scan-overlay rounded-xl p-5 max-w-md">
              <div className="text-[11px] font-mono tracking-[0.18em] text-[#38DFFF] mb-3">
                NASA TELEMETRY · SOL 5111
              </div>
              <dl className="space-y-2.5 text-xs sm:text-sm font-mono">
                <div className="flex justify-between gap-4 border-b border-white/[0.08] pb-1.5">
                  <dt className="text-[#737F91]">MISSION</dt>
                  <dd className="text-[#F5F7FA] font-semibold">MARS EXPLORATION</dd>
                </div>
                <div className="flex justify-between gap-4 border-b border-white/[0.08] pb-1.5">
                  <dt className="text-[#737F91]">OBJECT</dt>
                  <dd className="text-[#8BEAFF] font-semibold">MARS ROVER (MER-B)</dd>
                </div>
                <div className="flex justify-between gap-4 border-b border-white/[0.08] pb-1.5">
                  <dt className="text-[#737F91]">STATUS</dt>
                  <dd className="text-[#F07843] font-semibold">MISSION COMPLETED</dd>
                </div>
                <div className="pt-1">
                  <dt className="text-[#737F91]">DISCOVERIES</dt>
                  <dd className="text-[#A6B0C0] mt-0.5">
                    SCIENTIFIC DATA AND EXPLORATION HISTORY
                  </dd>
                </div>
              </dl>
            </div>

            <div className="holo-panel holo-grid-bg rounded-xl p-5 max-w-md md:ml-auto">
              <div className="text-[11px] font-mono tracking-[0.18em] text-[#E7C9A1] mb-2">
                HARDWARE SUBSYSTEM SIGNATURE
              </div>
              <ul className="space-y-2 text-xs font-mono text-[#F5F7FA]">
                <li className="flex items-center justify-between gap-3">
                  <span className="text-[#A6B0C0]">PANCAM OPTICAL MAST</span>
                  <span className="text-[#38DFFF]">CALIBRATED</span>
                </li>
                <li className="flex items-center justify-between gap-3">
                  <span className="text-[#A6B0C0]">ROCK ABRASION ARM</span>
                  <span className="text-[#38DFFF]">STOWED</span>
                </li>
                <li className="flex items-center justify-between gap-3">
                  <span className="text-[#A6B0C0]">TRAVERSE ODOMETER</span>
                  <span className="text-[#F5F7FA] tabular-nums">45.16 KM</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Scene 5: Enter the Experience CTA */}
      {state.showEnterCta && (
        <div className="relative z-20 h-[calc(100%-150px)] flex flex-col items-center justify-end pb-10 sm:pb-14 px-6 text-center">
          <div className="holo-panel holo-grid-bg holo-scan-overlay rounded-2xl px-6 py-7 sm:px-10 sm:py-8 max-w-2xl">
            <p className="text-xs font-mono tracking-[0.22em] text-[#E7C9A1] uppercase">
              NASA Space Apps Challenge 2026
            </p>
            <h1
              className="mt-2 font-display font-bold text-[#F5F7FA] tracking-[-0.02em]"
              style={{ fontSize: 'clamp(1.9rem, 4vw, 3.4rem)' }}
            >
              SPACETIME EXPLORER
            </h1>
            <p className="mt-3 text-sm sm:text-base text-[#A6B0C0] max-w-xl mx-auto leading-relaxed">
              Every abandoned object has a story. Every story reveals a
              discovery.
            </p>

            <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={onComplete}
                className="inline-flex items-center gap-2 px-7 py-3.5 rounded-lg bg-[#38DFFF] hover:bg-[#8BEAFF] text-[#080B12] font-display font-bold text-xs sm:text-sm tracking-[0.12em] transition-colors cursor-pointer whitespace-nowrap"
              >
                <span>EXPLORE THE FORGOTTEN</span>
                <ChevronRight className="w-4 h-4" aria-hidden="true" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Scene Timeline Stepper */}
      <div className="absolute inset-x-0 bottom-5 z-20 flex items-center justify-center gap-2 px-4 overflow-x-auto">
        {['01 Horizon', '02 Story', '03 Rover', '04 Hologram', '05 Launch'].map(
          (label, idx) => {
            const active = state.sceneIndex === idx + 1;
            return (
              <button
                key={label}
                type="button"
                onClick={() => jumpToScene(idx)}
                className={`px-3 py-1 rounded text-[11px] font-mono transition-colors cursor-pointer whitespace-nowrap shrink-0 border ${
                  active
                    ? 'border-[#38DFFF]/70 bg-[#38DFFF]/15 text-[#F5F7FA]'
                    : 'border-white/15 bg-[#0B1220]/85 text-[#737F91] hover:text-[#F5F7FA]'
                }`}
              >
                {label}
              </button>
            );
          },
        )}
      </div>
    </div>
  );
}
