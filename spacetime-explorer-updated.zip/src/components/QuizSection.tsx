import { useState } from 'react';
import { CheckCircle2, ExternalLink, RotateCcw, XCircle } from 'lucide-react';
import type { QuizQuestion } from '../types/museum';
import { calculateQuizScore } from '../utils/museumLogic';

interface QuizSectionProps {
  questions: QuizQuestion[];
}

export function QuizSection({ questions }: QuizSectionProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [showResults, setShowResults] = useState(false);

  const currentQuestion = questions[currentIndex];
  const selectedOption = answers[currentQuestion.id];
  const hasAnsweredCurrent = selectedOption !== undefined;
  const isCorrect = selectedOption === currentQuestion.correctIndex;

  const score = calculateQuizScore(questions, answers);

  const handleSelectOption = (optIdx: number) => {
    if (hasAnsweredCurrent) return;
    setAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: optIdx,
    }));
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex((i) => i + 1);
    } else {
      setShowResults(true);
    }
  };

  const handleRetake = () => {
    setAnswers({});
    setCurrentIndex(0);
    setShowResults(false);
  };

  return (
    <section
      id="space-quiz"
      className="py-20 lg:py-24 border-b border-white/[0.08] bg-[#080B12]"
    >
      <div className="max-w-[960px] mx-auto px-4 sm:px-6">
        <div className="mb-10">
          <p className="text-xs font-mono tracking-[0.16em] uppercase text-[#38DFFF] mb-2.5">
            08 · Educational Space Quiz
          </p>
          <h2 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#F5F7FA] tracking-[-0.02em]">
            Test Your Moon &amp; Mars Mission Knowledge
          </h2>
          <p className="mt-3 text-[#A6B0C0] text-sm sm:text-base leading-relaxed">
            Answer six verified NASA science questions with instant
            explanations and primary reference links.
          </p>
        </div>

        {showResults ? (
          <div className="holo-panel holo-grid-bg rounded-xl p-8 text-center">
            <div className="text-xs font-mono tracking-[0.16em] uppercase text-[#E7C9A1]">
              Mission Assessment Complete
            </div>
            <div className="mt-3 text-5xl font-mono font-bold tabular-nums text-[#F5F7FA]">
              {score.correct} / {score.total}
            </div>
            <p className="mt-2 text-sm font-mono text-[#38DFFF]">
              Accuracy: {score.percentage}%
            </p>
            <p className="mt-4 text-sm sm:text-base text-[#A6B0C0] max-w-lg mx-auto leading-relaxed">
              {score.percentage >= 80
                ? 'Outstanding mission telemetry! You accurately distinguished Apollo surface hardware, Mars pioneer rovers, and active nuclear laboratories.'
                : 'Great effort! Explore the Moon, Mars, and 5-Stage Storytelling galleries above to uncover more engineering clues and try again.'}
            </p>
            <button
              type="button"
              onClick={handleRetake}
              className="mt-6 inline-flex items-center gap-2 px-5 py-2.5 text-sm font-mono font-semibold text-[#080B12] bg-[#38DFFF] hover:bg-[#8BEAFF] rounded-lg cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" aria-hidden="true" />
              <span>Retake Quiz</span>
            </button>
          </div>
        ) : (
          <div className="holo-panel rounded-xl p-6 sm:p-8">
            <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-white/[0.08]">
              <span className="text-xs font-mono text-[#38DFFF] tabular-nums">
                Question {currentIndex + 1} of {questions.length}
              </span>
              <span className="text-xs font-mono text-[#E7C9A1] tabular-nums">
                Current Score: {score.correct} / {Object.keys(answers).length}
              </span>
            </div>

            <div className="w-full h-1.5 bg-white/[0.08] rounded-full overflow-hidden mt-4">
              <div
                className="h-full bg-[#38DFFF] transition-all duration-200"
                style={{
                  width: `${((currentIndex + 1) / questions.length) * 100}%`,
                }}
              />
            </div>

            <h3 className="mt-6 font-editorial text-xl sm:text-2xl font-semibold text-[#F5F7FA] leading-snug">
              {currentQuestion.question}
            </h3>

            <div className="mt-6 space-y-3">
              {currentQuestion.options.map((opt, idx) => {
                const isChosen = selectedOption === idx;
                const isRightOption = idx === currentQuestion.correctIndex;

                let btnStyle =
                  'border-white/12 bg-[#080B12]/80 text-[#A6B0C0] hover:border-[#38DFFF]/50 hover:text-[#F5F7FA]';
                if (hasAnsweredCurrent) {
                  if (isRightOption) {
                    btnStyle =
                      'border-emerald-400/60 bg-emerald-500/15 text-emerald-100';
                  } else if (isChosen) {
                    btnStyle =
                      'border-rose-400/60 bg-rose-500/15 text-rose-100';
                  } else {
                    btnStyle = 'border-white/10 bg-[#080B12]/50 text-[#737F91]';
                  }
                }

                return (
                  <button
                    key={opt}
                    type="button"
                    disabled={hasAnsweredCurrent}
                    onClick={() => handleSelectOption(idx)}
                    className={`w-full text-left px-4 py-3.5 rounded-lg border text-sm sm:text-base transition-colors flex items-center justify-between gap-3 cursor-pointer disabled:cursor-default ${btnStyle}`}
                  >
                    <span>{opt}</span>
                    {hasAnsweredCurrent && isRightOption && (
                      <CheckCircle2
                        className="w-4 h-4 text-emerald-300 shrink-0"
                        aria-hidden="true"
                      />
                    )}
                    {hasAnsweredCurrent && isChosen && !isRightOption && (
                      <XCircle
                        className="w-4 h-4 text-rose-300 shrink-0"
                        aria-hidden="true"
                      />
                    )}
                  </button>
                );
              })}
            </div>

            {hasAnsweredCurrent && (
              <div className="mt-6 rounded-lg border border-white/12 bg-[#080B12]/90 p-5 space-y-2.5">
                <div
                  className={`text-xs font-mono font-semibold ${
                    isCorrect ? 'text-emerald-300' : 'text-[#F07843]'
                  }`}
                >
                  {isCorrect
                    ? 'Correct Answer'
                    : `Incorrect — Correct answer: ${currentQuestion.options[currentQuestion.correctIndex]}`}
                </div>
                <p className="text-sm text-[#A6B0C0] leading-relaxed">
                  {currentQuestion.explanation}
                </p>
                <div className="pt-1 flex flex-wrap items-center justify-between gap-4">
                  <a
                    href={currentQuestion.sourceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs text-[#38DFFF] hover:text-[#8BEAFF] underline underline-offset-4"
                  >
                    <span>Source: {currentQuestion.sourceLabel}</span>
                    <ExternalLink className="w-3 h-3" aria-hidden="true" />
                  </a>

                  <button
                    type="button"
                    onClick={handleNext}
                    className="px-4 py-2 text-xs sm:text-sm font-mono font-semibold text-[#080B12] bg-[#38DFFF] hover:bg-[#8BEAFF] rounded-lg cursor-pointer whitespace-nowrap"
                  >
                    {currentIndex < questions.length - 1
                      ? 'Next Question'
                      : 'View Final Results'}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
}
