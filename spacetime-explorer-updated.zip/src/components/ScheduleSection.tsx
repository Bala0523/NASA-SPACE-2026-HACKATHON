import { useState } from 'react';
import { SCHEDULE_SESSIONS } from '../data/hackathonData';
import { formatSessionTime } from '../utils/hackathonLogic';

const DAYS: Array<{ day: 1 | 2 | 3; label: string; dateLabel: string }> = [
  { day: 1, label: 'Day 01', dateLabel: 'Nov 14 · Kickoff' },
  { day: 2, label: 'Day 02', dateLabel: 'Nov 15 · Build & Mentors' },
  { day: 3, label: 'Day 03', dateLabel: 'Nov 16 · Judging' },
];

export function ScheduleSection() {
  const [activeDay, setActiveDay] = useState<1 | 2 | 3>(1);
  const [timezoneMode, setTimezoneMode] = useState<'UTC' | 'LOCAL'>('UTC');

  const daySessions = SCHEDULE_SESSIONS.filter((s) => s.day === activeDay);

  return (
    <section
      id="schedule"
      className="py-16 lg:py-24 border-b border-slate-800/90 bg-[#07090E]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div className="max-w-2xl">
            <p className="text-xs font-mono text-slate-400 mb-2">
              48-Hour Global Run of Show
            </p>
            <h2
              style={{ textWrap: 'balance' }}
              className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-white"
            >
              Mission Schedule &amp; Mentor Hours
            </h2>
          </div>

          <div
            role="group"
            aria-label="Timezone display mode"
            className="inline-flex items-center gap-1 p-1 bg-[#0B0F17] border border-slate-800 rounded-lg self-start"
          >
            <button
              type="button"
              onClick={() => setTimezoneMode('UTC')}
              aria-pressed={timezoneMode === 'UTC'}
              className={`px-3 py-1.5 text-xs font-mono rounded-md transition-colors whitespace-nowrap shrink-0 ${
                timezoneMode === 'UTC'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              UTC Time
            </button>
            <button
              type="button"
              onClick={() => setTimezoneMode('LOCAL')}
              aria-pressed={timezoneMode === 'LOCAL'}
              className={`px-3 py-1.5 text-xs font-mono rounded-md transition-colors whitespace-nowrap shrink-0 ${
                timezoneMode === 'LOCAL'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Local Time
            </button>
          </div>
        </div>

        {/* Day Tabs */}
        <div
          role="tablist"
          aria-label="Hackathon schedule days"
          className="flex flex-wrap gap-2 mb-8"
        >
          {DAYS.map((item) => {
            const active = activeDay === item.day;
            return (
              <button
                key={item.day}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setActiveDay(item.day)}
                className={`px-4 py-2.5 rounded-lg border text-left transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 ${
                  active
                    ? 'bg-[#111827] border-blue-500 text-white'
                    : 'bg-[#0B0F17] border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
                }`}
              >
                <span className="font-mono text-xs text-blue-400 mr-2">
                  {item.label}
                </span>
                <span className="text-sm font-medium">{item.dateLabel}</span>
              </button>
            );
          })}
        </div>

        {/* Timeline Rows */}
        <div className="border border-slate-800 rounded-xl bg-[#0B0F17] divide-y divide-slate-800/80">
          {daySessions.map((session) => (
            <div
              key={session.id}
              className="p-6 grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-6 items-start"
            >
              <div className="md:col-span-3">
                <div className="text-base font-mono font-semibold tabular-nums text-white">
                  {formatSessionTime(session.utcIso, timezoneMode)}
                </div>
                <div className="text-xs font-mono tabular-nums text-slate-400 mt-1">
                  {session.durationMins} mins · {session.sessionType}
                </div>
              </div>

              <div className="md:col-span-9">
                <h3 className="font-display text-lg font-semibold text-white mb-1">
                  {session.title}
                </h3>
                <div className="text-xs font-mono text-blue-400 mb-2">
                  {session.speaker}
                </div>
                <p className="text-sm text-slate-300 leading-relaxed">
                  {session.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
