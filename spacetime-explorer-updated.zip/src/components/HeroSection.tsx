import { useMemo, useRef, useState } from 'react';
import {
  ArrowRight,
  ExternalLink,
  Film,
  GraduationCap,
  Microscope,
  Minus,
  Plus,
  RotateCcw,
} from 'lucide-react';
import { SPACE_ARTIFACTS, VERIFIED_HERO_METRICS } from '../data/spaceEquipment';
import type { BodyTarget, LearningMode } from '../types/museum';
import { CinematicSurface3D } from './three/CinematicSurface3D';

interface HeroSectionProps {
  learningMode: LearningMode;
  onChangeLearningMode: (mode: LearningMode) => void;
  onNavigateSection: (sectionId: string) => void;
  onReplayIntro: () => void;
}

const SURFACE_PRESETS: Record<BodyTarget, string[]> = {
  Mars: ['opportunity-mer-b', 'perseverance-mars2020'],
  Moon: ['apollo-11-eagle-descent', 'apollo-15-lrv'],
};

export function HeroSection({
  learningMode,
  onChangeLearningMode,
  onNavigateSection,
  onReplayIntro,
}: HeroSectionProps) {
  const [activeWorld, setActiveWorld] = useState<BodyTarget>('Mars');
  const [selectedSurfaceId, setSelectedSurfaceId] = useState<string>(
    'opportunity-mer-b',
  );
  const [switchingWorld, setSwitchingWorld] = useState(false);

  const surfaceArtifact = useMemo(
    () =>
      SPACE_ARTIFACTS.find((a) => a.id === selectedSurfaceId) ??
      SPACE_ARTIFACTS[0],
    [selectedSurfaceId],
  );

  const [selectedPartId, setSelectedPartId] = useState<string>(
    surfaceArtifact.components[0]?.id ?? '',
  );

  const camCtrlRef = useRef<{
    zoomDelta: (delta: number) => void;
    resetView: () => void;
  } | null>(null);

  const handleWorldSwitch = (targetWorld: BodyTarget) => {
    if (targetWorld === activeWorld) return;
    setSwitchingWorld(true);
    const defaultId = SURFACE_PRESETS[targetWorld][0];
    const nextArt =
      SPACE_ARTIFACTS.find((a) => a.id === defaultId) ?? SPACE_ARTIFACTS[0];
    setActiveWorld(targetWorld);
    setSelectedSurfaceId(nextArt.id);
    setSelectedPartId(nextArt.components[0]?.id ?? '');
    window.setTimeout(() => setSwitchingWorld(false), 380);
  };

  const handleSelectSurfacePreset = (artifactId: string) => {
    const nextArt = SPACE_ARTIFACTS.find((a) => a.id === artifactId);
    if (!nextArt) return;
    setSelectedSurfaceId(nextArt.id);
    setSelectedPartId(nextArt.components[0]?.id ?? '');
  };

  const activePart =
    surfaceArtifact.components.find((c) => c.id === selectedPartId) ??
    surfaceArtifact.components[0];

  const validCompIds = useMemo(
    () => surfaceArtifact.components.map((c) => c.id),
    [surfaceArtifact],
  );

  return (
    <section
      id="top"
      className="relative bg-[#080B12] border-b border-white/[0.08]"
    >
      {/* Full-Screen 3D Planetary Environment Stage */}
      <div className="relative min-h-[780px] lg:min-h-[92vh] w-full flex flex-col justify-between pt-20 pb-16 lg:pt-24 lg:pb-20 overflow-hidden">
        {/* Background Interactive 3D Canvas */}
        <div className="absolute inset-0">
          <CinematicSurface3D
            mode="interactive"
            heroFraming={true}
            body={activeWorld}
            modelType={surfaceArtifact.model3DType}
            selectedComponentId={selectedPartId}
            validComponentIds={validCompIds}
            onSelectComponent={setSelectedPartId}
            fallbackImage={surfaceArtifact.imageUrl}
            cameraControlRef={camCtrlRef}
          />

          {/* Directional editorial scrims keeping right rover silhouette luminous */}
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background:
                'linear-gradient(90deg, rgba(8,11,18,0.92) 0%, rgba(8,11,18,0.72) 38%, rgba(8,11,18,0.12) 72%, rgba(8,11,18,0.28) 100%)',
            }}
          />
          <div
            className="absolute inset-0 pointer-events-none lg:hidden"
            style={{
              background:
                'linear-gradient(180deg, rgba(8,11,18,0.86) 0%, rgba(8,11,18,0.52) 50%, rgba(8,11,18,0.88) 100%)',
            }}
          />
          <div
            className="absolute inset-x-0 bottom-0 h-56 pointer-events-none"
            style={{
              background:
                'linear-gradient(to top, #080B12 0%, rgba(8,11,18,0.68) 48%, transparent 100%)',
            }}
          />

          {switchingWorld && (
            <div className="absolute inset-0 z-20 bg-[#080B12]/90 flex flex-col items-center justify-center gap-2 pointer-events-none">
              <div className="font-mono text-xs tracking-[0.2em] text-[#38DFFF] uppercase">
                Engaging Planetary Telemetry Switch
              </div>
              <div className="text-sm font-display text-[#F5F7FA]">
                DESTINATION: {activeWorld.toUpperCase()} SURFACE
              </div>
            </div>
          )}
        </div>

        {/* Left-Aligned Cinematic Typography Composition */}
        <div className="relative z-10 max-w-[1320px] mx-auto w-full px-4 sm:px-6 pt-4 lg:pt-10 pointer-events-none">
          <div className="max-w-2xl pointer-events-auto">
            <div className="flex flex-wrap items-center gap-4 mb-5">
              <p className="text-[11px] sm:text-xs font-mono text-[#E7C9A1] tracking-[0.18em] uppercase">
                NASA Space Apps 2026 · Abandoned but not Forgotten
              </p>
              <button
                type="button"
                onClick={onReplayIntro}
                className="inline-flex items-center gap-1.5 text-[11px] font-mono text-[#A6B0C0] hover:text-[#38DFFF] transition-colors cursor-pointer whitespace-nowrap"
              >
                <Film className="w-3.5 h-3.5 text-[#F07843]" aria-hidden="true" />
                <span>Replay Intro</span>
              </button>
            </div>

            <h1
              className="font-display font-bold text-[#F5F7FA] tracking-[-0.03em] leading-[1.03]"
              style={{
                fontSize: 'clamp(2.4rem, 4.9vw, 4.4rem)',
                textWrap: 'balance',
              }}
            >
              THE UNIVERSE REMEMBERS EVERYTHING.
            </h1>

            <p className="mt-5 text-base sm:text-lg text-[#A6B0C0] leading-relaxed max-w-xl">
              Every abandoned object carries a story of discovery, exploration
              and human ambition.
            </p>

            {/* Primary CTA + Subtle Secondary Link */}
            <div className="mt-8 flex flex-wrap items-center gap-6">
              <button
                type="button"
                onClick={() => onNavigateSection('moon-explorer')}
                className="group inline-flex items-center gap-2.5 px-7 py-3.5 text-xs sm:text-sm font-display font-bold tracking-[0.1em] text-[#080B12] bg-[#38DFFF] hover:bg-[#8BEAFF] border border-[#8BEAFF]/70 rounded-lg shadow-[0_0_0_rgba(56,223,255,0)] hover:shadow-[0_10px_30px_-8px_rgba(56,223,255,0.6)] hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.98] transition-all duration-200 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#38DFFF]"
              >
                <span>EXPLORE THE UNKNOWN</span>
                <ArrowRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-1" aria-hidden="true" />
              </button>

              <button
                type="button"
                onClick={() => onNavigateSection('mission-storytelling')}
                className="inline-flex items-center gap-2 pb-1 border-b border-white/25 hover:border-[#38DFFF] text-xs font-mono tracking-[0.14em] text-[#F5F7FA] hover:text-[#38DFFF] active:opacity-70 transition-all duration-200 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#38DFFF]"
              >
                <span>DISCOVER OUR MISSION</span>
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Interactive Dock: Surface Switcher (Left) + Subsystem HUD (Right) */}
        <div className="relative z-10 max-w-[1320px] mx-auto w-full px-4 sm:px-6 mt-10 grid grid-cols-1 lg:grid-cols-12 gap-5 items-end pointer-events-none">
          {/* Left Minimal Controls: Planetary Switcher, Presets, Explanation Depth */}
          <div className="lg:col-span-6 min-w-0 pointer-events-auto space-y-3">
            <div className="flex flex-wrap items-center gap-2.5">
              <div
                role="group"
                aria-label="Select 3D planetary surface environment"
                className="inline-flex items-center p-1 rounded-lg bg-[#0B1220]/90 border border-white/[0.12] max-w-full"
              >
                {(['Mars', 'Moon'] as const).map((w) => (
                  <button
                    key={w}
                    type="button"
                    onClick={() => handleWorldSwitch(w)}
                    className={`px-3 py-1.5 text-[11px] sm:text-xs font-mono tracking-wider rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                      activeWorld === w
                        ? w === 'Mars'
                          ? 'bg-[#F07843] text-[#080B12] font-semibold'
                          : 'bg-[#38DFFF] text-[#080B12] font-semibold'
                        : 'text-[#A6B0C0] hover:text-[#F5F7FA]'
                    }`}
                  >
                    {w === 'Mars' ? 'MARS SURFACE 3D' : 'MOON SURFACE 3D'}
                  </button>
                ))}
              </div>

              <div className="flex flex-wrap items-center gap-1.5">
                {SURFACE_PRESETS[activeWorld].map((presetId) => {
                  const art = SPACE_ARTIFACTS.find((a) => a.id === presetId);
                  if (!art) return null;
                  return (
                    <button
                      key={presetId}
                      type="button"
                      onClick={() => handleSelectSurfacePreset(presetId)}
                      className={`px-2.5 py-1.5 text-[11px] font-mono rounded-md border transition-colors cursor-pointer whitespace-nowrap ${
                        surfaceArtifact.id === presetId
                          ? 'border-[#38DFFF]/70 bg-[#0B1220]/95 text-[#8BEAFF]'
                          : 'border-white/12 bg-[#0B1220]/70 text-[#A6B0C0] hover:text-[#F5F7FA]'
                      }`}
                    >
                      {art.missionName}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <span className="text-[11px] font-mono tracking-[0.12em] uppercase text-[#737F91]">
                Depth:
              </span>
              <div
                role="group"
                aria-label="Explanation depth mode"
                className="inline-flex items-center p-1 bg-[#0B1220]/90 border border-white/[0.12] rounded-lg"
              >
                <button
                  type="button"
                  onClick={() => onChangeLearningMode('student')}
                  className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    learningMode === 'student'
                      ? 'bg-[#38DFFF]/18 text-[#8BEAFF] border border-[#38DFFF]/50'
                      : 'text-[#A6B0C0] hover:text-[#F5F7FA] border border-transparent'
                  }`}
                >
                  <GraduationCap className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Student Mode</span>
                </button>
                <button
                  type="button"
                  onClick={() => onChangeLearningMode('scientific')}
                  className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    learningMode === 'scientific'
                      ? 'bg-[#38DFFF]/18 text-[#8BEAFF] border border-[#38DFFF]/50'
                      : 'text-[#A6B0C0] hover:text-[#F5F7FA] border border-transparent'
                  }`}
                >
                  <Microscope className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Scientific Detail Mode</span>
                </button>
              </div>
            </div>
          </div>

          {/* Right Compact Holographic Subsystem HUD (No backdrop-blur over WebGL) */}
          <div className="lg:col-span-6 min-w-0 pointer-events-auto">
            <div className="holo-panel holo-grid-bg bg-[#080B12]/96 rounded-xl overflow-hidden shadow-[0_16px_42px_rgba(0,0,0,0.65)]">
              <div className="px-4 py-2.5 border-b border-white/[0.1] flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="text-[11px] font-mono tracking-[0.14em] text-[#38DFFF] truncate">
                    {activeWorld === 'Mars'
                      ? 'MARS HORIZON · CLICK HARDWARE TO INSPECT'
                      : 'LUNAR REGOLITH · EARTH VISIBLE IN SKY'}
                  </div>
                  <div className="text-xs font-semibold text-[#F5F7FA] truncate">
                    {surfaceArtifact.name}
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={() => camCtrlRef.current?.zoomDelta(-0.7)}
                    aria-label="Zoom in 3D surface"
                    className="p-1.5 rounded text-[#A6B0C0] hover:text-[#38DFFF] hover:bg-white/5 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                  </button>
                  <button
                    type="button"
                    onClick={() => camCtrlRef.current?.zoomDelta(0.7)}
                    aria-label="Zoom out 3D surface"
                    className="p-1.5 rounded text-[#A6B0C0] hover:text-[#38DFFF] hover:bg-white/5 cursor-pointer"
                  >
                    <Minus className="w-3.5 h-3.5" aria-hidden="true" />
                  </button>
                  <button
                    type="button"
                    onClick={() => camCtrlRef.current?.resetView()}
                    aria-label="Reset 3D surface camera"
                    className="p-1.5 rounded text-[#A6B0C0] hover:text-[#38DFFF] hover:bg-white/5 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                  </button>
                </div>
              </div>

              <div className="px-4 pt-3 flex flex-wrap items-center gap-1.5">
                {surfaceArtifact.components.map((comp) => (
                  <button
                    key={comp.id}
                    type="button"
                    onClick={() => setSelectedPartId(comp.id)}
                    className={`px-2.5 py-1 text-[11px] font-mono rounded border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      comp.id === activePart?.id
                        ? 'bg-[#38DFFF]/15 border-[#38DFFF]/70 text-[#8BEAFF]'
                        : 'bg-[#080B12] border-white/15 text-[#A6B0C0] hover:text-[#F5F7FA] hover:border-[#38DFFF]/40'
                    }`}
                  >
                    {comp.name}
                  </button>
                ))}
              </div>

              {activePart && (
                <div
                  data-testid="surface-component-hud"
                  className="p-4 space-y-2"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono">
                    <span className="text-[#38DFFF] tracking-[0.12em]">
                      SUBSYSTEM LOCK · {surfaceArtifact.missionName} (
                      {surfaceArtifact.missionYear})
                    </span>
                    <span
                      className={
                        activeWorld === 'Mars'
                          ? 'text-[#F07843]'
                          : 'text-[#E7C9A1]'
                      }
                    >
                      {surfaceArtifact.status}
                    </span>
                  </div>
                  <h2 className="font-editorial text-sm sm:text-base font-semibold text-[#F5F7FA]">
                    {activePart.name}{' '}
                    <span className="text-[#8BEAFF] font-normal text-xs sm:text-sm">
                      — {activePart.role}
                    </span>
                  </h2>
                  <p className="text-xs sm:text-sm text-[#D0D7E2] leading-relaxed">
                    {learningMode === 'student'
                      ? activePart.studentExplanation
                      : activePart.scientificExplanation}
                  </p>
                  <div className="pt-1 flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono text-[#A6B0C0]">
                    <span>SITE: {surfaceArtifact.siteName}</span>
                    {surfaceArtifact.references[0] && (
                      <a
                        href={surfaceArtifact.references[0].url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-[#38DFFF] hover:text-[#8BEAFF] underline underline-offset-4"
                      >
                        <span>NASA Archive Source</span>
                        <ExternalLink className="w-3 h-3" aria-hidden="true" />
                      </a>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Verified Statistics Ribbon */}
      <div className="border-t border-white/[0.08] bg-[#0B1220]/65">
        <div className="max-w-[1320px] mx-auto px-4 sm:px-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-white/[0.08]">
          {VERIFIED_HERO_METRICS.map((metric) => (
            <div key={metric.label} className="py-6 sm:px-6 first:sm:pl-0 last:sm:pr-0">
              <div className="text-3xl font-mono font-bold tabular-nums text-[#F5F7FA]">
                {metric.value}
              </div>
              <div className="mt-1 text-sm font-medium text-[#E7C9A1]">
                {metric.label}
              </div>
              <div className="mt-1 text-xs text-[#737F91] leading-relaxed">
                {metric.detail}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
