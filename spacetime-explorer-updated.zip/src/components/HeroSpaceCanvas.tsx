import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { CameraPreset } from '../types/hackathon';
import { createLunarHardwareScene } from '../three/createLunarHardwareScene';
import { SafeImage } from './SafeImage';

interface HeroSpaceCanvasProps {
  preset: CameraPreset;
  isPaused: boolean;
}

const PRESET_VIEWS: Record<
  CameraPreset,
  { position: [number, number, number]; target: [number, number, number] }
> = {
  overview: { position: [-0.9, 1.35, 5.4], target: [0.35, 0.05, 0] },
  hardware: { position: [0.35, 0.78, 3.1], target: [1.38, 0.36, 0] },
  surface: { position: [3.2, -0.35, 3.7], target: [1.35, -0.45, 0] },
};

const _targetCamPos = new THREE.Vector3();
const _targetLook = new THREE.Vector3();

function detectSoftwareWebGL(): boolean {
  try {
    const probeCanvas = document.createElement('canvas');
    const gl = probeCanvas.getContext('webgl2') || probeCanvas.getContext('webgl');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export function HeroSpaceCanvas({ preset, isPaused }: HeroSpaceCanvasProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const presetRef = useRef<CameraPreset>(preset);
  const pausedRef = useRef<boolean>(isPaused);
  const transitioningRef = useRef<boolean>(false);
  const [webglUnavailable, setWebglUnavailable] = useState(false);

  useEffect(() => {
    presetRef.current = preset;
    transitioningRef.current = true;
  }, [preset]);

  useEffect(() => {
    pausedRef.current = isPaused;
  }, [isPaused]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareWebGL();

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: 'high-performance',
        alpha: false,
      });
    } catch {
      setWebglUnavailable(true);
      return;
    }

    const width = container.clientWidth || 1280;
    const height = container.clientHeight || 720;

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.setPixelRatio(
      isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2)
    );
    renderer.setSize(width, height);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setClearColor(0x07090e, 1);

    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x07090e);
    scene.fog = new THREE.FogExp2(0x07090e, 0.028);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envTarget = pmremGenerator.fromScene(roomEnv, 0.04);
    scene.environment = envTarget.texture;
    roomEnv.dispose();
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    const initView = PRESET_VIEWS[presetRef.current];
    camera.position.set(...initView.position);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.set(...initView.target);
    controls.enableZoom = false; // Never hijack vertical page scrolling
    controls.enablePan = false;
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.06;
    controls.minPolarAngle = 0.45;
    controls.maxPolarAngle = Math.PI * 0.62;
    controls.update();

    const stopPresetTransition = () => {
      transitioningRef.current = false;
    };
    controls.addEventListener('start', stopPresetTransition);

    // 3-Point Aerospace Lighting
    const hemiLight = new THREE.HemisphereLight(0x60a5fa, 0x0b1120, 0.72);
    scene.add(hemiLight);

    const sunKeyLight = new THREE.DirectionalLight(0xfff1d6, 2.5);
    sunKeyLight.position.set(-6, 5.5, 4.5);
    if (!isSoftwareGl) {
      sunKeyLight.castShadow = true;
      sunKeyLight.shadow.mapSize.set(1024, 1024);
      sunKeyLight.shadow.camera.near = 1;
      sunKeyLight.shadow.camera.far = 20;
      const d = 4.5;
      sunKeyLight.shadow.camera.left = -d;
      sunKeyLight.shadow.camera.right = d;
      sunKeyLight.shadow.camera.top = d;
      sunKeyLight.shadow.camera.bottom = -d;
      sunKeyLight.shadow.bias = -0.0005;
      sunKeyLight.shadow.normalBias = 0.02;
    }
    scene.add(sunKeyLight);

    const rimLight = new THREE.DirectionalLight(0x3b82f6, 1.35);
    rimLight.position.set(5, 2.2, -5.5);
    scene.add(rimLight);

    const maxAnisotropy = Math.min(renderer.capabilities.getMaxAnisotropy(), 8);
    const assets = createLunarHardwareScene(scene, maxAnisotropy);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    let frameId = 0;
    let disposed = false;
    let elapsed = 0;
    let lastTime = performance.now();

    function afterDraw(cb: () => void) {
      if (disposed) return;
      const gl = renderer.getContext() as WebGL2RenderingContext | null;
      if (!gl || typeof gl.fenceSync !== 'function') {
        frameId = window.setTimeout(cb, 85);
        return;
      }
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) {
          if (sync) gl.deleteSync(sync);
          return;
        }
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function tick() {
      if (disposed) return;
      const now = performance.now();
      const delta = Math.min((now - lastTime) / 1000, 0.1);
      lastTime = now;

      if (!pausedRef.current) {
        elapsed += delta;
        assets.spacecraftGroup.position.y = 0.38 + Math.sin(elapsed * 0.9) * 0.07;
        assets.spacecraftGroup.rotation.y = -0.45 + Math.sin(elapsed * 0.35) * 0.16;
        assets.orbitalRing.rotation.z = elapsed * 0.12;
        assets.lunarHorizon.rotation.y = elapsed * 0.025;
        assets.dishAssembly.rotation.y = 0.3 + Math.sin(elapsed * 0.65) * 0.12;
      }

      if (transitioningRef.current) {
        const view = PRESET_VIEWS[presetRef.current];
        _targetCamPos.set(...view.position);
        _targetLook.set(...view.target);
        const dampRate = isSoftwareGl ? 10 : 5.5;
        camera.position.x = THREE.MathUtils.damp(
          camera.position.x,
          _targetCamPos.x,
          dampRate,
          delta
        );
        camera.position.y = THREE.MathUtils.damp(
          camera.position.y,
          _targetCamPos.y,
          dampRate,
          delta
        );
        camera.position.z = THREE.MathUtils.damp(
          camera.position.z,
          _targetCamPos.z,
          dampRate,
          delta
        );
        controls.target.x = THREE.MathUtils.damp(
          controls.target.x,
          _targetLook.x,
          dampRate,
          delta
        );
        controls.target.y = THREE.MathUtils.damp(
          controls.target.y,
          _targetLook.y,
          dampRate,
          delta
        );
        controls.target.z = THREE.MathUtils.damp(
          controls.target.z,
          _targetLook.z,
          dampRate,
          delta
        );
        if (
          camera.position.distanceTo(_targetCamPos) < 0.03 &&
          controls.target.distanceTo(_targetLook) < 0.03
        ) {
          camera.position.copy(_targetCamPos);
          controls.target.copy(_targetLook);
          transitioningRef.current = false;
        }
      }

      controls.update();
      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = window.requestAnimationFrame(tick);
      }
    }

    // Initial synchronous draw, then start paced loop
    renderer.render(scene, camera);
    if (isSoftwareGl) {
      afterDraw(tick);
    } else {
      frameId = window.requestAnimationFrame(tick);
    }

    const handleResize = () => {
      if (!container || disposed) return;
      const w = container.clientWidth || 1280;
      const h = container.clientHeight || 720;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(container);

    const handleContextLost = (event: Event) => {
      event.preventDefault();
      setWebglUnavailable(true);
    };
    const handleContextRestored = () => {
      setWebglUnavailable(false);
    };
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);
    renderer.domElement.addEventListener(
      'webglcontextrestored',
      handleContextRestored
    );

    return () => {
      disposed = true;
      window.cancelAnimationFrame(frameId);
      window.clearTimeout(frameId);
      resizeObserver.disconnect();
      controls.removeEventListener('start', stopPresetTransition);
      controls.dispose();
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      renderer.domElement.removeEventListener(
        'webglcontextrestored',
        handleContextRestored
      );
      assets.dispose();
      envTarget.dispose();
      renderer.dispose();
    };
  }, []);

  if (webglUnavailable) {
    return (
      <div className="w-full h-full relative" data-testid="hero-3d-fallback">
        <SafeImage
          src="/src/assets/images/hero_orbital_horizon_1794655338444.jpg"
          alt="Earth orbital horizon at sunrise viewed from low Earth orbit"
          className="w-full h-full object-cover"
          fallbackTitle="NASA Orbital Horizon"
        />
      </div>
    );
  }

  return (
    <div
      ref={mountRef}
      data-testid="hero-3d-canvas"
      className="w-full h-full cursor-grab active:cursor-grabbing"
      aria-label="Interactive 3D Lunar Explorer Hardware Scene"
    />
  );
}
