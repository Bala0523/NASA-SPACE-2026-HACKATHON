import { useState } from 'react';
import { ArrowLeftRight, Orbit, RotateCcw, Search, Sparkles } from 'lucide-react';
import type {
  BodyTarget,
  EquipmentCategory,
  LearningMode,
  OperationalStatus,
  SpaceArtifact,
} from '../types/museum';
import { filterArtifacts } from '../utils/museumLogic';
import { SafeImage } from './SafeImage';

interface DiscoveryAndComparisonSectionProps {
  artifacts: SpaceArtifact[];
  learningMode: LearningMode;
  onInspectArtifact: (artifact: SpaceArtifact) => void;
  onJumpToStory: (id: string) => void;
  onJumpToMuseum: (id: string) => void;
}

export function DiscoveryAndComparisonSection({
  artifacts,
  learningMode,
  onInspectArtifact,
  onJumpToStory,
  onJumpToMuseum,
}: DiscoveryAndComparisonSectionProps) {
  const [query, setQuery] = useState('');
  const [bodyFilter, setBodyFilter] = useState<'All' | BodyTarget>('All');
  const [categoryFilter, setCategoryFilter] = useState<'All' | EquipmentCategory>('All');
  const [statusFilter, setStatusFilter] = useState<'All' | OperationalStatus>('All');
  const [compareIds, setCompareIds] = useState<[string, string]>([
    artifacts[0]?.id ?? 'apollo-11-eagle-descent',
    artifacts[8]?.id ?? artifacts[1]?.id ?? 'curiosity-msl',
  ]);

  const filtered = filterArtifacts(artifacts, {
    query,
    body: bodyFilter,
    category: categoryFilter,
    status: statusFilter,
  });

  const resetFilters = () => {
    setQuery('');
    setBodyFilter('All');
    setCategoryFilter('All');
    setStatusFilter('All');
  };

  const toggleCompareSlot = (id: string) => {
    setCompareIds((prev) => {
      if (prev[0] === id || prev[1] === id) return prev;
      return [prev[1], id];
    });
  };

  const leftCompare =
    artifacts.find((a) => a.id === compareIds[0]) ?? artifacts[0];
  const rightCompare =
    artifacts.find((a) => a.id === compareIds[1]) ?? artifacts[1];

  return (
    <section
      id="discovery-archive"
      className="py-20 lg:py-24 border-b border-white/[0.08] bg-[#080B12]"
    >
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
        <div className="mb-10">
          <p className="text-xs font-mono tracking-[0.16em] uppercase text-[#38DFFF] mb-2.5">
            05 · Discovery Archive &amp; Side-by-Side Comparison
          </p>
          <h2 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#F5F7FA] tracking-[-0.02em]">
            Search &amp; Compare NASA Surface Hardware
          </h2>
          <p className="mt-3 text-[#A6B0C0] max-w-2xl text-sm sm:text-base leading-relaxed">
            Search by equipment name, mission, year, or planet—then select any
            two machines to compare Moon and Mars engineering side by side.
          </p>
        </div>

        <div className="holo-panel rounded-xl p-4 sm:p-5 mb-10 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
            <div className="md:col-span-5 relative">
              <label htmlFor="archive-search-input" className="sr-only">
                Search equipment, mission, year, or planet
              </label>
              <Search
                className="w-4 h-4 text-[#737F91] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                id="archive-search-input"
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search equipment, mission, year (e.g. 1969, Spirit, Rover)..."
                className="w-full pl-10 pr-4 py-2.5 text-sm bg-[#080B12] border border-white/12 rounded-lg text-[#F5F7FA] placeholder:text-[#737F91] focus:outline-2 focus:outline-[#38DFFF]"
              />
            </div>

            <div className="md:col-span-3">
              <label htmlFor="archive-category-filter" className="sr-only">
                Filter by category
              </label>
              <select
                id="archive-category-filter"
                value={categoryFilter}
                onChange={(e) =>
                  setCategoryFilter(e.target.value as 'All' | EquipmentCategory)
                }
                className="w-full px-3.5 py-2.5 text-sm bg-[#080B12] border border-white/12 rounded-lg text-[#F5F7FA] focus:outline-2 focus:outline-[#38DFFF]"
              >
                <option value="All">All Categories</option>
                <option value="Rover">Rovers</option>
                <option value="Lander">Landers</option>
                <option value="Scientific Instrument">Scientific Instruments</option>
                <option value="Ascent & Descent Stage">Ascent &amp; Descent Stages</option>
              </select>
            </div>

            <div className="md:col-span-4">
              <label htmlFor="archive-status-filter" className="sr-only">
                Filter by mission status
              </label>
              <select
                id="archive-status-filter"
                value={statusFilter}
                onChange={(e) =>
                  setStatusFilter(e.target.value as 'All' | OperationalStatus)
                }
                className="w-full px-3.5 py-2.5 text-sm bg-[#080B12] border border-white/12 rounded-lg text-[#F5F7FA] focus:outline-2 focus:outline-[#38DFFF]"
              >
                <option value="All">All Mission Statuses</option>
                <option value="Active Operational">Active Operational</option>
                <option value="Mission Completed">Mission Completed</option>
                <option value="Intentionally Left Behind">Intentionally Left Behind</option>
                <option value="Intentionally Discarded">Intentionally Discarded</option>
              </select>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-white/[0.08]">
            <div
              role="group"
              aria-label="Destination filter"
              className="inline-flex items-center p-1 bg-[#080B12] border border-white/10 rounded-lg"
            >
              {(['All', 'Moon', 'Mars'] as const).map((b) => (
                <button
                  key={b}
                  type="button"
                  onClick={() => setBodyFilter(b)}
                  className={`px-3.5 py-1.5 text-xs font-mono rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                    bodyFilter === b
                      ? 'bg-[#38DFFF] text-[#080B12] font-semibold'
                      : 'text-[#A6B0C0] hover:text-[#F5F7FA]'
                  }`}
                >
                  {b === 'All' ? 'All Worlds' : `${b} Missions`}
                </button>
              ))}
            </div>

            <div className="text-xs font-mono text-[#737F91] tabular-nums">
              Showing {filtered.length} of {artifacts.length} verified artifacts
            </div>
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="rounded-xl border border-white/[0.08] bg-[#0B1220] p-12 text-center">
            <p className="text-base font-medium text-[#F5F7FA]">
              No documented NASA hardware matches your search or filter selection.
            </p>
            <p className="mt-1.5 text-sm text-[#737F91]">
              Try clearing your search term or resetting destination and status filters.
            </p>
            <button
              type="button"
              onClick={resetFilters}
              className="mt-5 inline-flex items-center gap-2 px-4 py-2 text-xs font-mono font-semibold text-[#080B12] bg-[#38DFFF] hover:bg-[#8BEAFF] rounded-lg cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Reset Filters</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((item, idx) => {
              const inCompare =
                compareIds[0] === item.id || compareIds[1] === item.id;
              const isSpotlight = filtered.length > 2 && idx === 0;
              return (
                <article
                  key={item.id}
                  className={`group relative rounded-xl border border-white/[0.08] hover:border-[#38DFFF]/40 bg-[#0B1220] overflow-hidden flex flex-col justify-between transition-[transform,border-color,box-shadow] duration-300 hover:-translate-y-1 hover:shadow-[0_18px_40px_-20px_rgba(56,223,255,0.3)] ${
                    isSpotlight ? 'md:col-span-2 lg:col-span-2' : ''
                  }`}
                >
                  <span
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-x-0 top-0 z-10 h-px origin-left scale-x-0 bg-[#38DFFF] transition-transform duration-500 group-hover:scale-x-100"
                  />
                  <div
                    className={`flex-1 ${
                      isSpotlight
                        ? 'grid grid-cols-1 md:grid-cols-12 h-full'
                        : 'flex flex-col'
                    }`}
                  >
                    <div
                      className={`relative overflow-hidden border-white/[0.08] ${
                        isSpotlight
                          ? 'md:col-span-6 h-56 md:h-auto border-b md:border-b-0 md:border-r'
                          : 'h-48 border-b'
                      }`}
                    >
                      <SafeImage
                        src={item.imageUrl}
                        alt={item.name}
                        className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.06]"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-[#0B1220]/85 via-transparent to-transparent" />
                    </div>

                    <div
                      className={`p-6 flex flex-col justify-between ${
                        isSpotlight ? 'md:col-span-6' : ''
                      }`}
                    >
                      <div>
                        <div className="text-xs font-mono text-[#737F91] flex flex-wrap items-center gap-x-2">
                          <span
                            className={
                              item.body === 'Mars'
                                ? 'text-[#F07843]'
                                : 'text-[#38DFFF]'
                            }
                          >
                            {item.body}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span className="tabular-nums text-[#E7C9A1]">
                            {item.missionYear}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>{item.category}</span>
                        </div>

                        <h3
                          className={`mt-2.5 font-editorial font-semibold text-[#F5F7FA] leading-snug ${
                            isSpotlight ? 'text-2xl' : 'text-lg'
                          }`}
                        >
                          {item.name}
                        </h3>

                        <div className="mt-1.5 text-xs font-mono">
                          <span
                            className={
                              item.status === 'Active Operational'
                                ? 'text-[#38DFFF]'
                                : item.status === 'Intentionally Discarded'
                                  ? 'text-[#F07843]'
                                  : 'text-[#8BEAFF]'
                            }
                          >
                            {item.status}
                          </span>
                        </div>

                        <p
                          className={`mt-3 text-sm text-[#A6B0C0] leading-relaxed ${
                            isSpotlight ? 'line-clamp-4' : 'line-clamp-3'
                          }`}
                        >
                          {learningMode === 'student'
                            ? item.purposeStudent
                            : item.purposeScientific}
                        </p>
                      </div>

                      {isSpotlight && (
                        <div className="mt-4 pt-3 border-t border-white/[0.08] text-xs font-mono text-[#737F91] tabular-nums">
                          {item.siteName} · {item.massKg.toLocaleString()} kg
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="px-6 py-3.5 border-t border-white/[0.08] flex flex-wrap items-center justify-between gap-2 bg-[#080B12]/70">
                    <div className="flex items-center gap-2.5">
                      <button
                        type="button"
                        onClick={() => onInspectArtifact(item)}
                        className="text-xs font-semibold text-[#38DFFF] hover:text-[#8BEAFF] cursor-pointer whitespace-nowrap"
                      >
                        Inspect Site
                      </button>
                      <span className="text-[#737F91]" aria-hidden="true">
                        ·
                      </span>
                      <button
                        type="button"
                        onClick={() => onJumpToStory(item.id)}
                        aria-label={`Read story for ${item.name}`}
                        className="inline-flex items-center gap-1 text-xs font-medium text-[#A6B0C0] hover:text-[#F5F7FA] cursor-pointer whitespace-nowrap"
                      >
                        <Sparkles className="w-3 h-3" aria-hidden="true" />
                        <span>Story</span>
                      </button>
                      <span className="text-[#737F91]" aria-hidden="true">
                        ·
                      </span>
                      <button
                        type="button"
                        onClick={() => onJumpToMuseum(item.id)}
                        aria-label={`Open 3D model for ${item.name}`}
                        className="inline-flex items-center gap-1 text-xs font-medium text-[#A6B0C0] hover:text-[#F5F7FA] cursor-pointer whitespace-nowrap"
                      >
                        <Orbit className="w-3 h-3" aria-hidden="true" />
                        <span>3D</span>
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={() => toggleCompareSlot(item.id)}
                      className={`px-2.5 py-1 text-xs font-mono rounded border transition-colors cursor-pointer whitespace-nowrap ${
                        inCompare
                          ? 'bg-[#38DFFF] border-[#38DFFF] text-[#080B12] font-semibold'
                          : 'border-white/15 text-[#A6B0C0] hover:text-[#F5F7FA] hover:border-[#38DFFF]/50'
                      }`}
                    >
                      {inCompare ? 'Comparing' : 'Compare'}
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        )}

        {leftCompare && rightCompare && (
          <div className="mt-14 holo-panel rounded-xl p-6 sm:p-7">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-white/[0.08]">
              <div className="flex items-center gap-2.5">
                <ArrowLeftRight
                  className="w-5 h-5 text-[#38DFFF]"
                  aria-hidden="true"
                />
                <h3 className="font-editorial text-xl font-semibold text-[#F5F7FA]">
                  Mission Comparison: Moon vs. Mars Hardware
                </h3>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <label htmlFor="compare-slot-a" className="sr-only">
                  Comparison Artifact A
                </label>
                <select
                  id="compare-slot-a"
                  value={leftCompare.id}
                  onChange={(e) =>
                    setCompareIds([e.target.value, rightCompare.id])
                  }
                  className="px-3 py-1.5 text-xs bg-[#080B12] border border-white/15 rounded-lg text-[#F5F7FA]"
                >
                  {artifacts.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.missionName} · {a.body}
                    </option>
                  ))}
                </select>
                <span className="text-xs font-mono text-[#737F91]">vs.</span>
                <label htmlFor="compare-slot-b" className="sr-only">
                  Comparison Artifact B
                </label>
                <select
                  id="compare-slot-b"
                  value={rightCompare.id}
                  onChange={(e) =>
                    setCompareIds([leftCompare.id, e.target.value])
                  }
                  className="px-3 py-1.5 text-xs bg-[#080B12] border border-white/15 rounded-lg text-[#F5F7FA]"
                >
                  {artifacts.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.missionName} · {a.body}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="mt-5 overflow-x-auto">
              <table className="w-full text-left text-sm border-collapse">
                <thead>
                  <tr className="border-b border-white/[0.08] text-xs font-mono text-[#E7C9A1]">
                    <th className="py-3 pr-4 w-44">Specification</th>
                    <th className="py-3 px-4 text-[#F5F7FA] font-semibold">
                      {leftCompare.name}
                    </th>
                    <th className="py-3 pl-4 text-[#F5F7FA] font-semibold">
                      {rightCompare.name}
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.08] text-[#A6B0C0]">
                  <tr>
                    <td className="py-3.5 pr-4 text-xs font-mono text-[#737F91]">
                      Destination &amp; Site
                    </td>
                    <td className="py-3.5 px-4 text-[#F5F7FA]">
                      {leftCompare.body} · {leftCompare.siteName}
                    </td>
                    <td className="py-3.5 pl-4 text-[#F5F7FA]">
                      {rightCompare.body} · {rightCompare.siteName}
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3.5 pr-4 text-xs font-mono text-[#737F91]">
                      Launch / Landing
                    </td>
                    <td className="py-3.5 px-4 font-mono text-xs tabular-nums">
                      {leftCompare.launchDate} → {leftCompare.landingDate}
                    </td>
                    <td className="py-3.5 pl-4 font-mono text-xs tabular-nums">
                      {rightCompare.launchDate} → {rightCompare.landingDate}
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3.5 pr-4 text-xs font-mono text-[#737F91]">
                      Dry Mass &amp; Power
                    </td>
                    <td className="py-3.5 px-4 tabular-nums">
                      {leftCompare.massKg.toLocaleString()} kg ·{' '}
                      {leftCompare.powerSource}
                    </td>
                    <td className="py-3.5 pl-4 tabular-nums">
                      {rightCompare.massKg.toLocaleString()} kg ·{' '}
                      {rightCompare.powerSource}
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3.5 pr-4 text-xs font-mono text-[#737F91]">
                      Operational Status
                    </td>
                    <td className="py-3.5 px-4 font-mono text-xs text-[#8BEAFF]">
                      {leftCompare.status}
                    </td>
                    <td className="py-3.5 pl-4 font-mono text-xs text-[#8BEAFF]">
                      {rightCompare.status}
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3.5 pr-4 text-xs font-mono text-[#737F91]">
                      Key Discovery
                    </td>
                    <td className="py-3.5 px-4 text-xs leading-relaxed text-[#A6B0C0]">
                      {leftCompare.scientificContribution}
                    </td>
                    <td className="py-3.5 pl-4 text-xs leading-relaxed text-[#A6B0C0]">
                      {rightCompare.scientificContribution}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
