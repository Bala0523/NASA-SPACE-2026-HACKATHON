import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import type { BodyTarget, Model3DType } from '../../types/museum';
import { getPlanetaryGroundHeight } from '../../utils/museumLogic';
import { SafeImage } from '../SafeImage';
import {
  buildSpacecraftModel,
  createEarthSkyTexture,
  createRadialShadowTexture,
  createStudioRenderer,
  createSurfaceTerrainTextures,
  detectSoftwareGl,
  setupStudioEnvironment,
} from './threeUtils';

interface CinematicSurface3DProps {
  mode: 'intro' | 'interactive';
  body: BodyTarget;
  modelType: Model3DType;
  cameraProgress?: number;
  selectedComponentId?: string;
  validComponentIds?: string[];
  onSelectComponent?: (compId: string) => void;
  onSceneReady?: () => void;
  fallbackImage?: string;
  className?: string;
  heroFraming?: boolean;
  cameraControlRef?: React.MutableRefObject<{
    zoomDelta: (delta: number) => void;
    resetView: () => void;
  } | null>;
}

export function CinematicSurface3D({
  mode,
  body,
  modelType,
  cameraProgress = 0,
  selectedComponentId = '',
  validComponentIds = [],
  onSelectComponent,
  onSceneReady,
  fallbackImage = '/src/assets/images/mars_rover_jezero_1794656366254.jpg',
  className = '',
  heroFraming = false,
  cameraControlRef,
}: CinematicSurface3DProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const [webglError, setWebglError] = useState(false);

  const cameraProgressRef = useRef(cameraProgress);
  const selectedCompRef = useRef(selectedComponentId);
  const validCompIdsRef = useRef(validComponentIds);
  const onSelectCompRef = useRef(onSelectComponent);
  const onSceneReadyRef = useRef(onSceneReady);
  const highlightTriggerRef = useRef<((compId: string) => void) | null>(null);
  const progressRenderTriggerRef = useRef<(() => void) | null>(null);

  cameraProgressRef.current = cameraProgress;
  selectedCompRef.current = selectedComponentId;
  validCompIdsRef.current = validComponentIds;
  onSelectCompRef.current = onSelectComponent;
  onSceneReadyRef.current = onSceneReady;

  useEffect(() => {
    if (highlightTriggerRef.current) {
      highlightTriggerRef.current(selectedComponentId);
    }
  }, [selectedComponentId]);

  useEffect(() => {
    if (mode === 'intro' && progressRenderTriggerRef.current) {
      progressRenderTriggerRef.current();
    }
  }, [cameraProgress, mode]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    let disposed = false;
    let rafId = 0;
    let timerId = 0;
    let renderer: THREE.WebGLRenderer | null = null;
    let envTex: THREE.Texture | null = null;
    let earthTex: THREE.CanvasTexture | null = null;
    let shadowTex: THREE.CanvasTexture | null = null;
    let terrainTextures: {
      map: THREE.CanvasTexture;
      bumpMap: THREE.CanvasTexture;
    } | null = null;

    try {
      const width = container.clientWidth || 960;
      const height = container.clientHeight || 540;
      const isSoftwareGl = detectSoftwareGl();

      const scene = new THREE.Scene();
      const isMars = body === 'Mars';

      // Horizon sky and atmospheric fog harmonized with Obsidian #080B12
      const fogColor = isMars ? 0x261109 : 0x080b12;
      scene.background = new THREE.Color(isMars ? 0x160a06 : 0x060910);
      scene.fog = new THREE.FogExp2(fogColor, isMars ? 0.024 : 0.015);

      const getHeroDefaultFraming = (w: number, h: number) => {
        const aspect = w / Math.max(h, 1);
        if (heroFraming && aspect > 1.25) {
          return {
            pos: new THREE.Vector3(4.35, 1.52, 5.95),
            target: new THREE.Vector3(-1.15, 0.82, 0),
          };
        }
        return {
          pos: new THREE.Vector3(4.45, 1.48, 5.35),
          target: new THREE.Vector3(0, 0.88, 0),
        };
      };

      const camera = new THREE.PerspectiveCamera(44, width / height, 0.1, 140);
      const initialFraming = getHeroDefaultFraming(width, height);
      if (mode === 'intro') {
        camera.position.set(8.6, 2.1, 11.8);
      } else {
        camera.position.copy(initialFraming.pos);
      }

      renderer = createStudioRenderer(width, height, isSoftwareGl);
      renderer.toneMappingExposure = isMars ? 1.18 : 1.1;
      renderer.domElement.style.display = 'block';
      renderer.domElement.style.width = '100%';
      renderer.domElement.style.height = '100%';
      container.innerHTML = '';
      container.appendChild(renderer.domElement);

      envTex = setupStudioEnvironment(renderer, scene);

      let controls: OrbitControls | null = null;
      if (mode === 'interactive') {
        controls = new OrbitControls(camera, renderer.domElement);
        controls.target.copy(initialFraming.target);
        controls.minDistance = 2.6;
        controls.maxDistance = 11.5;
        controls.maxPolarAngle = Math.PI * 0.485;
        controls.enableDamping = !isSoftwareGl;
        controls.dampingFactor = 0.06;
      }

      // 1. Sky Dome + Sunset / Lunar Backdrop
      const skyCanvas = document.createElement('canvas');
      skyCanvas.width = 64;
      skyCanvas.height = 256;
      const sCtx = skyCanvas.getContext('2d')!;
      const skyGrad = sCtx.createLinearGradient(0, 0, 0, 256);
      if (isMars) {
        skyGrad.addColorStop(0.0, '#080b12');
        skyGrad.addColorStop(0.38, '#23100a');
        skyGrad.addColorStop(0.56, '#7c2d12');
        skyGrad.addColorStop(0.7, '#f07843');
        skyGrad.addColorStop(0.84, '#431a0d');
        skyGrad.addColorStop(1.0, '#160a06');
      } else {
        skyGrad.addColorStop(0.0, '#050811');
        skyGrad.addColorStop(0.6, '#080b12');
        skyGrad.addColorStop(1.0, '#0b1220');
      }
      sCtx.fillStyle = skyGrad;
      sCtx.fillRect(0, 0, 64, 256);
      const skyTex = new THREE.CanvasTexture(skyCanvas);
      skyTex.colorSpace = THREE.SRGBColorSpace;
      const skyDomeGeo = new THREE.SphereGeometry(68, 28, 18);
      const skyDomeMat = new THREE.MeshBasicMaterial({
        map: skyTex,
        side: THREE.BackSide,
        fog: false,
      });
      const skyDome = new THREE.Mesh(skyDomeGeo, skyDomeMat);
      scene.add(skyDome);

      // 2. Celestial body in sky (Mars: warm sunset sun disc + Phobos/moon silhouette; Moon: blue Earth)
      const skyObjects: THREE.Object3D[] = [];
      let sunDiscGeo: THREE.SphereGeometry | null = null;
      let sunDiscMat: THREE.MeshBasicMaterial | null = null;
      let skyPlanetGeo: THREE.SphereGeometry | null = null;
      let skyPlanetMat: THREE.MeshStandardMaterial | null = null;

      if (isMars) {
        sunDiscGeo = new THREE.SphereGeometry(2.4, 20, 16);
        sunDiscMat = new THREE.MeshBasicMaterial({
          color: 0xffd29c,
          fog: false,
        });
        const sunDisc = new THREE.Mesh(sunDiscGeo, sunDiscMat);
        sunDisc.position.set(-10.5, 7.2, -38);
        scene.add(sunDisc);
        skyObjects.push(sunDisc);

        skyPlanetGeo = new THREE.SphereGeometry(1.45, 22, 16);
        skyPlanetMat = new THREE.MeshStandardMaterial({
          color: 0xb09a89,
          roughness: 0.85,
          metalness: 0.05,
          emissive: 0x3b1f14,
          emissiveIntensity: 0.25,
          fog: false,
        });
        const phobos = new THREE.Mesh(skyPlanetGeo, skyPlanetMat);
        phobos.position.set(10.0, 9.5, -36);
        scene.add(phobos);
        skyObjects.push(phobos);
      } else {
        earthTex = createEarthSkyTexture();
        skyPlanetGeo = new THREE.SphereGeometry(2.3, 28, 20);
        skyPlanetMat = new THREE.MeshStandardMaterial({
          map: earthTex,
          color: 0xffffff,
          roughness: 0.5,
          metalness: 0.05,
          emissive: 0x165a96,
          emissiveIntensity: 0.48,
          fog: false,
        });
        const earthMesh = new THREE.Mesh(skyPlanetGeo, skyPlanetMat);
        earthMesh.position.set(-6.5, 7.6, -34);
        scene.add(earthMesh);
        skyObjects.push(earthMesh);
      }

      // 3. Starfield (brighter on Moon, high-zenith subtle on Mars)
      const starCount = isMars ? 180 : 420;
      const starPositions = new Float32Array(starCount * 3);
      let seed = isMars ? 777 : 1969;
      const rand = () => {
        seed = (seed * 1664525 + 1013904223) % 4294967296;
        return seed / 4294967296;
      };
      for (let i = 0; i < starCount; i++) {
        const theta = rand() * Math.PI * 2;
        const phi = rand() * Math.PI * 0.44;
        const r = 56;
        starPositions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
        starPositions[i * 3 + 1] = r * Math.cos(phi) + 1.5;
        starPositions[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta);
      }
      const starGeo = new THREE.BufferGeometry();
      starGeo.setAttribute(
        'position',
        new THREE.BufferAttribute(starPositions, 3),
      );
      const starMat = new THREE.PointsMaterial({
        color: isMars ? 0xfde68a : 0xe2e8f0,
        size: isMars ? 0.16 : 0.22,
        transparent: true,
        opacity: isMars ? 0.5 : 0.9,
        fog: false,
      });
      const stars = new THREE.Points(starGeo, starMat);
      scene.add(stars);

      // 4. Sculpted Planetary Terrain Mesh
      const terrainSize = 68;
      const terrainSegs = isSoftwareGl ? 54 : 84;
      const terrainGeo = new THREE.PlaneGeometry(
        terrainSize,
        terrainSize,
        terrainSegs,
        terrainSegs,
      );
      terrainGeo.rotateX(-Math.PI / 2);
      const posAttr = terrainGeo.attributes.position;
      for (let i = 0; i < posAttr.count; i++) {
        const vx = posAttr.getX(i);
        const vz = posAttr.getZ(i);
        posAttr.setY(i, getPlanetaryGroundHeight(vx, vz, body));
      }
      terrainGeo.computeVertexNormals();

      const maxAniso = renderer.capabilities.getMaxAnisotropy();
      terrainTextures = createSurfaceTerrainTextures(body, maxAniso);
      const terrainMat = new THREE.MeshStandardMaterial({
        color: 0xffffff,
        map: terrainTextures.map,
        bumpMap: terrainTextures.bumpMap,
        bumpScale: isMars ? 0.14 : 0.16,
        roughness: isMars ? 0.88 : 0.92,
        metalness: 0.04,
      });
      const terrainMesh = new THREE.Mesh(terrainGeo, terrainMat);
      terrainMesh.receiveShadow = true;
      scene.add(terrainMesh);

      // 5. Instanced Surface Rocks & Boulders (watertight position-based noise, grounded flush)
      const rockCount = isSoftwareGl ? 38 : 68;
      const rockGeo = new THREE.DodecahedronGeometry(0.45, 1);
      const rPos = rockGeo.attributes.position;
      for (let i = 0; i < rPos.count; i++) {
        const vx = rPos.getX(i);
        const vy = rPos.getY(i);
        const vz = rPos.getZ(i);
        const noise = 0.84 + 0.24 * Math.sin(vx * 5.2 + vy * 3.7 + vz * 4.1);
        rPos.setXYZ(i, vx * noise, vy * (0.72 + 0.16 * noise), vz * noise);
      }
      rockGeo.computeVertexNormals();
      rockGeo.computeBoundingSphere();

      const rockMat = new THREE.MeshStandardMaterial({
        color: isMars ? 0x6b321b : 0x646b75,
        roughness: 0.9,
        metalness: 0.06,
      });
      const rockInstanced = new THREE.InstancedMesh(rockGeo, rockMat, rockCount);
      rockInstanced.castShadow = !isSoftwareGl;
      rockInstanced.receiveShadow = true;

      const dummy = new THREE.Object3D();
      const tintColor = new THREE.Color();
      for (let i = 0; i < rockCount; i++) {
        const angle = rand() * Math.PI * 2;
        const dist = 3.2 + rand() * 24;
        const rx = Math.cos(angle) * dist;
        const rz = Math.sin(angle) * dist;
        const ry = getPlanetaryGroundHeight(rx, rz, body);
        const s = 0.35 + rand() * 1.45;
        dummy.position.set(rx, ry + s * 0.14, rz);
        dummy.rotation.set(rand() * 0.4, rand() * Math.PI * 2, rand() * 0.4);
        dummy.scale.set(s * (0.9 + rand() * 0.4), s * 0.65, s * (0.85 + rand() * 0.4));
        dummy.updateMatrix();
        rockInstanced.setMatrixAt(i, dummy.matrix);

        if (isMars) {
          tintColor.setHSL(0.045 + rand() * 0.03, 0.55, 0.22 + rand() * 0.14);
        } else {
          tintColor.setHSL(0.6, 0.06, 0.3 + rand() * 0.18);
        }
        rockInstanced.setColorAt(i, tintColor);
      }
      rockInstanced.instanceMatrix.needsUpdate = true;
      if (rockInstanced.instanceColor) rockInstanced.instanceColor.needsUpdate = true;
      scene.add(rockInstanced);

      // 6. Floating Atmospheric Dust Particles (Mars haze / Lunar subtle micro-glint)
      const dustCount = isMars ? (isSoftwareGl ? 90 : 220) : 60;
      const dustPos = new Float32Array(dustCount * 3);
      for (let i = 0; i < dustCount; i++) {
        dustPos[i * 3] = (rand() - 0.5) * 26;
        dustPos[i * 3 + 1] = 0.25 + rand() * 5.5;
        dustPos[i * 3 + 2] = (rand() - 0.5) * 26;
      }
      const dustGeo = new THREE.BufferGeometry();
      dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPos, 3));
      const dustMat = new THREE.PointsMaterial({
        color: isMars ? 0xfdba74 : 0x94a3b8,
        size: isMars ? 0.065 : 0.035,
        transparent: true,
        opacity: isMars ? 0.52 : 0.25,
      });
      const dustPoints = new THREE.Points(dustGeo, dustMat);
      scene.add(dustPoints);

      // 7. Lighting Setup (Warm Sunset / Stark Solar Contrast + Cool Fill)
      const keyLight = new THREE.DirectionalLight(
        isMars ? 0xff9f5a : 0xfff7e8,
        isMars ? 2.75 : 2.9,
      );
      keyLight.position.set(-14, isMars ? 7.5 : 12, -16);
      if (!isSoftwareGl) {
        keyLight.castShadow = true;
        keyLight.shadow.mapSize.set(1024, 1024);
        keyLight.shadow.camera.near = 2;
        keyLight.shadow.camera.far = 45;
        keyLight.shadow.camera.left = -9;
        keyLight.shadow.camera.right = 9;
        keyLight.shadow.camera.top = 9;
        keyLight.shadow.camera.bottom = -9;
        keyLight.shadow.bias = -0.0005;
      }
      scene.add(keyLight);

      const hemiLight = new THREE.HemisphereLight(
        isMars ? 0xfb923c : 0x93c5fd,
        isMars ? 0x2a1008 : 0x111827,
        isMars ? 0.72 : 0.55,
      );
      scene.add(hemiLight);

      const cyanHoloRim = new THREE.DirectionalLight(0x38dfff, 0.9);
      cyanHoloRim.position.set(8, 5, 9);
      scene.add(cyanHoloRim);

      // 8. Centerpiece Hardware Model + Contact Shadow Disc
      const { group: craftGroup, partMeshes } = buildSpacecraftModel(modelType);
      craftGroup.position.set(0, 0, 0);
      craftGroup.rotation.y = isMars ? 0.55 : -0.45;
      scene.add(craftGroup);

      shadowTex = createRadialShadowTexture();
      const contactGeo = new THREE.CircleGeometry(2.15, 28);
      const contactMat = new THREE.MeshBasicMaterial({
        map: shadowTex,
        transparent: true,
        opacity: 0.46,
        depthWrite: false,
      });
      const contactShadow = new THREE.Mesh(contactGeo, contactMat);
      contactShadow.rotation.x = -Math.PI / 2;
      contactShadow.position.y = 0.015;
      scene.add(contactShadow);

      // Subtle holographic ring pad around rover in interactive mode
      let ringGeo: THREE.RingGeometry | null = null;
      let ringMat: THREE.MeshBasicMaterial | null = null;
      if (mode === 'interactive') {
        ringGeo = new THREE.RingGeometry(2.35, 2.4, 64);
        ringMat = new THREE.MeshBasicMaterial({
          color: 0x38dfff,
          transparent: true,
          opacity: 0.22,
          side: THREE.DoubleSide,
        });
        const holoRing = new THREE.Mesh(ringGeo, ringMat);
        holoRing.rotation.x = -Math.PI / 2;
        holoRing.position.y = 0.02;
        scene.add(holoRing);
      }

      const allInteractiveSet = new Set<THREE.Mesh>();
      partMeshes.forEach((list) => {
        for (const m of list) allInteractiveSet.add(m);
      });
      const allInteractive = Array.from(allInteractiveSet);

      const applyHighlight = (compId: string) => {
        for (const m of allInteractive) {
          const ids = (m.userData.componentIds as string[] | undefined) ?? [];
          const isMatch = compId !== '' && ids.includes(compId);
          const mat = m.material as THREE.MeshStandardMaterial;
          mat.emissive.setHex(isMatch ? 0x38dfff : 0x000000);
          mat.emissiveIntensity = isMatch ? 0.34 : 0;
        }
      };

      // Scratch objects outside render loop
      const _v = new THREE.Vector3();
      const _desiredCamPos = new THREE.Vector3();
      const _desiredTarget = new THREE.Vector3();
      const _currentLook = new THREE.Vector3(0, 0.9, 0);

      // Camera spline path for Intro scenes 1 -> 5
      const computeIntroCamera = (p: number) => {
        const clamped = THREE.MathUtils.clamp(p, 0, 1);
        if (clamped < 0.35) {
          const t = clamped / 0.35;
          _desiredCamPos.set(
            THREE.MathUtils.lerp(8.6, 5.4, t),
            THREE.MathUtils.lerp(2.1, 1.55, t),
            THREE.MathUtils.lerp(11.8, 7.2, t),
          );
          _desiredTarget.set(0, THREE.MathUtils.lerp(1.45, 1.15, t), 0);
        } else if (clamped < 0.72) {
          const t = (clamped - 0.35) / 0.37;
          _desiredCamPos.set(
            THREE.MathUtils.lerp(5.4, 2.75, t),
            THREE.MathUtils.lerp(1.55, 1.32, t),
            THREE.MathUtils.lerp(7.2, 3.65, t),
          );
          _desiredTarget.set(
            THREE.MathUtils.lerp(0, 0.1, t),
            THREE.MathUtils.lerp(1.15, 1.05, t),
            THREE.MathUtils.lerp(0, 0.18, t),
          );
        } else {
          const t = (clamped - 0.72) / 0.28;
          _desiredCamPos.set(
            THREE.MathUtils.lerp(2.75, 4.2, t),
            THREE.MathUtils.lerp(1.32, 1.52, t),
            THREE.MathUtils.lerp(3.65, 5.1, t),
          );
          _desiredTarget.set(
            THREE.MathUtils.lerp(0.1, 0, t),
            THREE.MathUtils.lerp(1.05, 1.05, t),
            THREE.MathUtils.lerp(0.18, 0, t),
          );
        }
      };

      let renderBusy = false;
      let renderDirty = false;
      let notifiedReady = false;

      const afterDraw = (cb: () => void, delayMs: number) => {
        if (!renderer || disposed) return;
        const gl = renderer.getContext() as WebGL2RenderingContext;
        if (!gl || typeof gl.fenceSync !== 'function') {
          timerId = window.setTimeout(cb, delayMs);
          return;
        }
        const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
        gl.flush();
        const poll = () => {
          if (disposed) return;
          const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
          if (state === gl.UNSIGNALED) {
            timerId = window.setTimeout(poll, 6);
          } else {
            if (sync) gl.deleteSync(sync);
            timerId = window.setTimeout(cb, delayMs);
          }
        };
        timerId = window.setTimeout(poll, 6);
      };

      const renderOneFrame = () => {
        if (disposed || !renderer) return;
        if (renderBusy) {
          renderDirty = true;
          return;
        }
        renderBusy = true;
        rafId = requestAnimationFrame(() => {
          if (disposed || !renderer) return;
          renderDirty = false;

          if (mode === 'intro') {
            computeIntroCamera(cameraProgressRef.current);
            const damp = isSoftwareGl ? 1 : 0.14;
            camera.position.lerp(_desiredCamPos, damp);
            _currentLook.lerp(_desiredTarget, damp);
            camera.lookAt(_currentLook);
          } else if (controls) {
            controls.update();
          }

          // Gentle dust drift
          const dArr = dustGeo.attributes.position.array as Float32Array;
          const step = isSoftwareGl ? 0.035 : 0.012;
          for (let i = 0; i < dustCount; i++) {
            dArr[i * 3] += step;
            if (dArr[i * 3] > 13) dArr[i * 3] = -13;
          }
          dustGeo.attributes.position.needsUpdate = true;

          renderer.render(scene, camera);

          if (!notifiedReady) {
            notifiedReady = true;
            onSceneReadyRef.current?.();
          }

          const finishFrame = () => {
            renderBusy = false;
            if (disposed) return;
            if (mode === 'intro' || !isSoftwareGl) {
              // On GPU keep gentle dust motion; on SwiftShader pace softly during intro only
              if (mode === 'intro') {
                if (cameraProgressRef.current < 1 || !isSoftwareGl) {
                  renderOneFrame();
                } else if (renderDirty) {
                  renderOneFrame();
                }
              } else if (!isSoftwareGl) {
                renderOneFrame();
              } else if (renderDirty) {
                renderOneFrame();
              }
            } else if (renderDirty) {
              renderOneFrame();
            }
          };

          if (isSoftwareGl) {
            afterDraw(finishFrame, mode === 'intro' ? 140 : 60);
          } else {
            finishFrame();
          }
        });
      };

      highlightTriggerRef.current = (compId: string) => {
        applyHighlight(compId);
        renderOneFrame();
      };

      progressRenderTriggerRef.current = () => {
        renderOneFrame();
      };

      if (controls) {
        controls.addEventListener('change', renderOneFrame);
      }

      if (cameraControlRef) {
        cameraControlRef.current = {
          zoomDelta: (delta: number) => {
            if (!controls) return;
            _v.copy(camera.position).sub(controls.target);
            const nextDist = THREE.MathUtils.clamp(
              _v.length() + delta,
              controls.minDistance,
              controls.maxDistance,
            );
            _v.normalize().multiplyScalar(nextDist).add(controls.target);
            camera.position.copy(_v);
            renderOneFrame();
          },
          resetView: () => {
            if (!controls || !container) return;
            const f = getHeroDefaultFraming(
              container.clientWidth || 960,
              container.clientHeight || 540,
            );
            camera.position.copy(f.pos);
            controls.target.copy(f.target);
            renderOneFrame();
          },
        };
      }

      // Interactive raycasting
      const raycaster = new THREE.Raycaster();
      const pointer = new THREE.Vector2();
      let downPos = { x: 0, y: 0 };

      const onPointerDown = (e: PointerEvent) => {
        downPos = { x: e.clientX, y: e.clientY };
      };
      const onPointerUp = (e: PointerEvent) => {
        if (mode !== 'interactive' || !renderer || !onSelectCompRef.current) return;
        if (Math.hypot(e.clientX - downPos.x, e.clientY - downPos.y) > 6) return;
        const rect = renderer.domElement.getBoundingClientRect();
        pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
        pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
        raycaster.setFromCamera(pointer, camera);
        const hits = raycaster.intersectObjects(allInteractive, false);
        if (hits.length > 0) {
          const cids = (hits[0].object.userData.componentIds as string[] | undefined) ?? [];
          const validSet = new Set(validCompIdsRef.current);
          const matched = cids.find((id) => validSet.has(id)) ?? cids[0];
          if (matched) {
            onSelectCompRef.current(matched);
          }
        }
      };

      renderer.domElement.addEventListener('pointerdown', onPointerDown);
      renderer.domElement.addEventListener('pointerup', onPointerUp);

      const handleResize = () => {
        if (!container || !renderer || disposed) return;
        const w = container.clientWidth || 960;
        const h = container.clientHeight || 540;
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        if (mode === 'interactive' && heroFraming && controls) {
          const f = getHeroDefaultFraming(w, h);
          controls.target.copy(f.target);
        }
        renderer.setSize(w, h);
        renderOneFrame();
      };
      window.addEventListener('resize', handleResize);

      const handleContextLost = (ev: Event) => {
        ev.preventDefault();
        setWebglError(true);
      };
      renderer.domElement.addEventListener('webglcontextlost', handleContextLost);

      applyHighlight(selectedCompRef.current);
      if (!isSoftwareGl) {
        renderer.compile(scene, camera);
      }
      renderOneFrame();

      return () => {
        disposed = true;
        cancelAnimationFrame(rafId);
        clearTimeout(timerId);
        window.removeEventListener('resize', handleResize);
        renderer?.domElement.removeEventListener('pointerdown', onPointerDown);
        renderer?.domElement.removeEventListener('pointerup', onPointerUp);
        renderer?.domElement.removeEventListener('webglcontextlost', handleContextLost);
        controls?.dispose();
        skyTex.dispose();
        skyDomeGeo.dispose();
        skyDomeMat.dispose();
        sunDiscGeo?.dispose();
        sunDiscMat?.dispose();
        skyPlanetGeo?.dispose();
        skyPlanetMat?.dispose();
        earthTex?.dispose();
        starGeo.dispose();
        starMat.dispose();
        terrainGeo.dispose();
        terrainMat.dispose();
        terrainTextures?.map.dispose();
        terrainTextures?.bumpMap.dispose();
        rockGeo.dispose();
        rockMat.dispose();
        dustGeo.dispose();
        dustMat.dispose();
        contactGeo.dispose();
        contactMat.dispose();
        shadowTex?.dispose();
        ringGeo?.dispose();
        ringMat?.dispose();
        craftGroup.traverse((child) => {
          if (child instanceof THREE.Mesh) {
            child.geometry.dispose();
            if (Array.isArray(child.material)) {
              child.material.forEach((m) => m.dispose());
            } else {
              child.material.dispose();
            }
          }
        });
        envTex?.dispose();
        renderer?.dispose();
      };
    } catch {
      setWebglError(true);
      onSceneReadyRef.current?.();
    }
  }, [mode, body, modelType, heroFraming]);

  if (webglError) {
    return (
      <div className={`relative w-full h-full overflow-hidden bg-[#080B12] ${className}`}>
        <SafeImage
          src={fallbackImage}
          alt={`${body} surface simulation`}
          className="w-full h-full object-cover opacity-80"
        />
      </div>
    );
  }

  return (
    <div
      ref={mountRef}
      data-testid={`surface-3d-${mode}-${body.toLowerCase()}`}
      className={`w-full h-full ${mode === 'interactive' ? 'cursor-grab active:cursor-grabbing' : ''} ${className}`}
      aria-label={
        mode === 'interactive'
          ? `Interactive 3D ${body} surface environment. Drag to orbit, scroll to zoom, and click hardware parts to inspect.`
          : `Cinematic 3D ${body} mission introduction.`
      }
    />
  );
}
