import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { Minus, Plus, RotateCcw } from 'lucide-react';
import type { BodyTarget, SpaceArtifact } from '../../types/museum';
import { latLonToCartesian } from '../../utils/museumLogic';
import { SafeImage } from '../SafeImage';
import {
  createProceduralPlanetTexture,
  createStudioRenderer,
  detectSoftwareGl,
  setupStudioEnvironment,
} from './threeUtils';

interface PlanetaryGlobe3DProps {
  body: BodyTarget;
  artifacts: SpaceArtifact[];
  selectedId: string;
  onSelectArtifact: (artifactId: string) => void;
  fallbackImage: string;
}

export function PlanetaryGlobe3D({
  body,
  artifacts,
  selectedId,
  onSelectArtifact,
  fallbackImage,
}: PlanetaryGlobe3DProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const selectedIdRef = useRef(selectedId);
  const onSelectRef = useRef(onSelectArtifact);
  const cameraActionRef = useRef<{
    zoomDelta: (delta: number) => void;
    reset: () => void;
    focusLatLon: (lat: number, lon: number) => void;
  } | null>(null);

  const [webglError, setWebglError] = useState(false);

  selectedIdRef.current = selectedId;
  onSelectRef.current = onSelectArtifact;

  useEffect(() => {
    const selected = artifacts.find((a) => a.id === selectedId);
    if (selected && cameraActionRef.current) {
      cameraActionRef.current.focusLatLon(
        selected.coordinates.lat,
        selected.coordinates.lon,
      );
    }
  }, [selectedId, artifacts]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    let disposed = false;
    let frameId = 0;
    let renderer: THREE.WebGLRenderer | null = null;
    let envTex: THREE.Texture | null = null;
    let planetTexture: THREE.CanvasTexture | null = null;

    try {
      const width = container.clientWidth || 560;
      const height = container.clientHeight || 420;
      const isSoftwareGl = detectSoftwareGl();

      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
      camera.position.set(0, 1.1, 4.9);

      renderer = createStudioRenderer(width, height, isSoftwareGl);
      renderer.domElement.style.display = 'block';
      renderer.domElement.style.width = '100%';
      renderer.domElement.style.height = '100%';
      container.innerHTML = '';
      container.appendChild(renderer.domElement);

      envTex = setupStudioEnvironment(renderer, scene);

      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enablePan = false;
      controls.minDistance = 2.6;
      controls.maxDistance = 8.0;
      controls.enableDamping = !isSoftwareGl;
      controls.dampingFactor = 0.06;

      // Subtle starfield using InstancedMesh/Points
      const starCount = 280;
      const starPos = new Float32Array(starCount * 3);
      let s = body === 'Moon' ? 101 : 202;
      const nextRand = () => {
        s = (s * 1664525 + 1013904223) % 4294967296;
        return s / 4294967296;
      };
      for (let i = 0; i < starCount; i++) {
        const theta = nextRand() * Math.PI * 2;
        const phi = Math.acos(2 * nextRand() - 1);
        const r = 18 + nextRand() * 14;
        starPos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
        starPos[i * 3 + 1] = r * Math.cos(phi);
        starPos[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta);
      }
      const starGeo = new THREE.BufferGeometry();
      starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
      const starMat = new THREE.PointsMaterial({
        color: 0xcbd5e1,
        size: 0.08,
        transparent: true,
        opacity: 0.75,
      });
      const stars = new THREE.Points(starGeo, starMat);
      scene.add(stars);

      // Studio lighting
      const keyLight = new THREE.DirectionalLight(
        body === 'Moon' ? 0xfff8eb : 0xffdfc4,
        2.3,
      );
      keyLight.position.set(5, 3, 5);
      scene.add(keyLight);

      const hemiLight = new THREE.HemisphereLight(
        body === 'Moon' ? 0x93c5fd : 0xfdba74,
        0x090d1a,
        0.55,
      );
      scene.add(hemiLight);

      const rimLight = new THREE.DirectionalLight(
        body === 'Moon' ? 0x38dfff : 0xf07843,
        0.9,
      );
      rimLight.position.set(-4, -2, -4);
      scene.add(rimLight);

      // Planet sphere
      const GLOBE_RADIUS = 1.65;
      const maxAniso = renderer.capabilities.getMaxAnisotropy();
      planetTexture = createProceduralPlanetTexture(body, maxAniso);

      const sphereGeo = new THREE.SphereGeometry(GLOBE_RADIUS, 48, 36);
      const sphereMat = new THREE.MeshStandardMaterial({
        map: planetTexture,
        roughness: body === 'Moon' ? 0.88 : 0.82,
        metalness: 0.04,
      });
      const globe = new THREE.Mesh(sphereGeo, sphereMat);
      scene.add(globe);

      // Atmosphere / orbital ring accent
      const ringGeo = new THREE.RingGeometry(GLOBE_RADIUS + 0.25, GLOBE_RADIUS + 0.265, 64);
      const ringMat = new THREE.MeshBasicMaterial({
        color: body === 'Moon' ? 0x38dfff : 0xf07843,
        transparent: true,
        opacity: 0.25,
        side: THREE.DoubleSide,
      });
      const orbitRing = new THREE.Mesh(ringGeo, ringMat);
      orbitRing.rotation.x = Math.PI * 0.44;
      orbitRing.rotation.y = 0.2;
      scene.add(orbitRing);

      // Surface landing markers
      const markerMeshes: THREE.Mesh[] = [];
      const markerGeo = new THREE.SphereGeometry(0.068, 16, 12);
      const haloGeo = new THREE.RingGeometry(0.09, 0.135, 24);

      for (const item of artifacts) {
        const pos = latLonToCartesian(
          item.coordinates.lat,
          item.coordinates.lon,
          GLOBE_RADIUS + 0.03,
        );
        const isActive = item.status === 'Active Operational';
        const isSelected = item.id === selectedIdRef.current;

        const markerMat = new THREE.MeshStandardMaterial({
          color: isSelected
            ? 0x22d3ee
            : isActive
              ? 0x10b981
              : body === 'Moon'
                ? 0xf59e0b
                : 0x3b82f6,
          emissive: isSelected ? 0x0891b2 : 0x000000,
          emissiveIntensity: isSelected ? 1.4 : 0.2,
          roughness: 0.25,
          metalness: 0.4,
        });
        const pin = new THREE.Mesh(markerGeo, markerMat);
        pin.position.set(pos.x, pos.y, pos.z);
        pin.userData.artifactId = item.id;
        scene.add(pin);
        markerMeshes.push(pin);

        const haloMat = new THREE.MeshBasicMaterial({
          color: isSelected ? 0x22d3ee : 0xffffff,
          transparent: true,
          opacity: isSelected ? 0.9 : 0.35,
          side: THREE.DoubleSide,
        });
        const halo = new THREE.Mesh(haloGeo, haloMat);
        halo.position.set(pos.x * 1.01, pos.y * 1.01, pos.z * 1.01);
        halo.lookAt(pos.x * 2, pos.y * 2, pos.z * 2);
        halo.userData.artifactId = item.id;
        halo.userData.isHalo = true;
        scene.add(halo);
        markerMeshes.push(halo);
      }

      // Render on demand + software WebGL pacing
      let renderBusy = false;
      let renderDirty = false;
      let targetCameraPos: THREE.Vector3 | null = null;
      const _tmpVec = new THREE.Vector3();

      function afterDraw(cb: () => void) {
        if (!renderer || disposed) return;
        const gl = renderer.getContext() as WebGL2RenderingContext;
        if (!gl || typeof gl.fenceSync !== 'function') {
          frameId = window.setTimeout(cb, 80);
          return;
        }
        const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
        gl.flush();
        const poll = () => {
          if (disposed) return;
          const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
          if (state === gl.UNSIGNALED) {
            frameId = window.setTimeout(poll, 5);
          } else {
            if (sync) gl.deleteSync(sync);
            frameId = window.setTimeout(cb, 80);
          }
        };
        frameId = window.setTimeout(poll, 5);
      }

      function updateMarkerStyles() {
        for (const m of markerMeshes) {
          const isSel = m.userData.artifactId === selectedIdRef.current;
          if (m.userData.isHalo) {
            const mat = m.material as THREE.MeshBasicMaterial;
            mat.color.setHex(isSel ? 0x22d3ee : 0xffffff);
            mat.opacity = isSel ? 0.95 : 0.35;
          } else {
            const mat = m.material as THREE.MeshStandardMaterial;
            mat.emissive.setHex(isSel ? 0x06b6d4 : 0x000000);
            mat.emissiveIntensity = isSel ? 1.5 : 0.2;
            m.scale.setScalar(isSel ? 1.35 : 1.0);
          }
        }
      }

      function requestRender() {
        if (disposed || !renderer) return;
        if (renderBusy) {
          renderDirty = true;
          return;
        }
        renderBusy = true;
        frameId = requestAnimationFrame(() => {
          if (disposed || !renderer) return;
          renderDirty = false;

          if (targetCameraPos) {
            camera.position.lerp(targetCameraPos, isSoftwareGl ? 1 : 0.14);
            if (camera.position.distanceTo(targetCameraPos) < 0.03) {
              camera.position.copy(targetCameraPos);
              targetCameraPos = null;
            } else {
              renderDirty = true;
            }
          }

          updateMarkerStyles();
          controls.update();
          renderer.render(scene, camera);

          const done = () => {
            renderBusy = false;
            if (renderDirty && !disposed) requestRender();
          };
          if (isSoftwareGl) afterDraw(done);
          else done();
        });
      }

      controls.addEventListener('start', () => {
        targetCameraPos = null;
      });
      controls.addEventListener('change', requestRender);

      cameraActionRef.current = {
        zoomDelta: (delta: number) => {
          targetCameraPos = null;
          _tmpVec.copy(camera.position).normalize();
          const currentDist = camera.position.length();
          const nextDist = THREE.MathUtils.clamp(
            currentDist + delta,
            controls.minDistance,
            controls.maxDistance,
          );
          camera.position.copy(_tmpVec.multiplyScalar(nextDist));
          requestRender();
        },
        reset: () => {
          targetCameraPos = new THREE.Vector3(0, 1.1, 4.9);
          requestRender();
        },
        focusLatLon: (lat: number, lon: number) => {
          const p = latLonToCartesian(lat, lon, camera.position.length());
          targetCameraPos = new THREE.Vector3(p.x, p.y, p.z);
          requestRender();
        },
      };

      // Raycasting on click
      const raycaster = new THREE.Raycaster();
      const pointer = new THREE.Vector2();
      let downPos = { x: 0, y: 0 };

      const handlePointerDown = (e: PointerEvent) => {
        downPos = { x: e.clientX, y: e.clientY };
      };

      const handlePointerUp = (e: PointerEvent) => {
        const moveDist = Math.hypot(e.clientX - downPos.x, e.clientY - downPos.y);
        if (moveDist > 6 || !renderer) return;
        const rect = renderer.domElement.getBoundingClientRect();
        pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
        pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
        raycaster.setFromCamera(pointer, camera);
        const hits = raycaster.intersectObjects(markerMeshes, false);
        if (hits.length > 0) {
          const hitId = hits[0].object.userData.artifactId as string | undefined;
          if (hitId) {
            onSelectRef.current(hitId);
          }
        }
      };

      renderer.domElement.addEventListener('pointerdown', handlePointerDown);
      renderer.domElement.addEventListener('pointerup', handlePointerUp);

      const handleResize = () => {
        if (!container || !renderer || disposed) return;
        const w = container.clientWidth || 560;
        const h = container.clientHeight || 420;
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
        requestRender();
      };
      window.addEventListener('resize', handleResize);

      const handleContextLost = (ev: Event) => {
        ev.preventDefault();
        setWebglError(true);
      };
      renderer.domElement.addEventListener('webglcontextlost', handleContextLost);

      // Focus initially selected artifact
      const initial = artifacts.find((a) => a.id === selectedIdRef.current);
      if (initial) {
        const p = latLonToCartesian(
          initial.coordinates.lat,
          initial.coordinates.lon,
          4.7,
        );
        camera.position.set(p.x, p.y, p.z);
      }

      requestRender();

      return () => {
        disposed = true;
        cancelAnimationFrame(frameId);
        clearTimeout(frameId);
        window.removeEventListener('resize', handleResize);
        renderer?.domElement.removeEventListener('pointerdown', handlePointerDown);
        renderer?.domElement.removeEventListener('pointerup', handlePointerUp);
        renderer?.domElement.removeEventListener('webglcontextlost', handleContextLost);
        controls.dispose();
        sphereGeo.dispose();
        sphereMat.dispose();
        ringGeo.dispose();
        ringMat.dispose();
        starGeo.dispose();
        starMat.dispose();
        markerGeo.dispose();
        haloGeo.dispose();
        markerMeshes.forEach((m) => {
          (m.material as THREE.Material).dispose();
        });
        planetTexture?.dispose();
        envTex?.dispose();
        renderer?.dispose();
      };
    } catch {
      setWebglError(true);
    }
  }, [body, artifacts]);

  if (webglError) {
    return (
      <div className="relative w-full h-[380px] sm:h-[440px] rounded-xl overflow-hidden border border-white/10 bg-[#090E1C]">
        <SafeImage
          src={fallbackImage}
          alt={`${body} interactive landing sites fallback view`}
          className="w-full h-full object-cover opacity-80"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#060913]/90 via-transparent to-[#060913]/40 flex items-end p-5">
          <p className="text-xs font-mono text-slate-300">
            Archival surface view active. Select any documented site from the directory to inspect its mission dossier.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div
      data-testid={`globe-3d-${body.toLowerCase()}`}
      className="relative w-full h-[380px] sm:h-[440px] rounded-xl overflow-hidden border border-white/[0.1] bg-[#080B12]"
    >
      <div
        ref={mountRef}
        className="w-full h-full cursor-grab active:cursor-grabbing"
        aria-label={`Interactive 3D ${body} globe. Drag to rotate, scroll to zoom, or click surface pins to inspect hardware.`}
      />

      <div className="absolute top-3 left-3 pointer-events-none">
        <span className="inline-block px-2.5 py-1 rounded bg-[#0B1220]/90 border border-white/12 text-[11px] font-mono text-[#A6B0C0]">
          Drag to orbit · Click surface markers
        </span>
      </div>

      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#0B1220]/95 border border-white/12">
        <button
          type="button"
          onClick={() => cameraActionRef.current?.zoomDelta(-0.7)}
          aria-label={`Zoom in on ${body}`}
          className="p-1.5 text-[#A6B0C0] hover:text-[#F5F7FA] hover:bg-white/10 rounded transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" aria-hidden="true" />
        </button>
        <button
          type="button"
          onClick={() => cameraActionRef.current?.zoomDelta(0.7)}
          aria-label={`Zoom out on ${body}`}
          className="p-1.5 text-[#A6B0C0] hover:text-[#F5F7FA] hover:bg-white/10 rounded transition-colors cursor-pointer"
        >
          <Minus className="w-4 h-4" aria-hidden="true" />
        </button>
        <button
          type="button"
          onClick={() => cameraActionRef.current?.reset()}
          aria-label={`Reset ${body} camera`}
          className="inline-flex items-center gap-1 px-2 py-1 text-xs font-mono text-[#A6B0C0] hover:text-[#F5F7FA] hover:bg-white/10 rounded transition-colors cursor-pointer whitespace-nowrap"
        >
          <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
          <span>Reset</span>
        </button>
      </div>
    </div>
  );
}
