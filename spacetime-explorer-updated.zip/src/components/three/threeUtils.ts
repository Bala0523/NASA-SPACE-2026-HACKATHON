import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import type { BodyTarget, Model3DType } from '../../types/museum';

export function detectSoftwareGl(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl =
      canvas.getContext('webgl2') ||
      (canvas.getContext('webgl') as WebGLRenderingContext | null);
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export function createStudioRenderer(
  width: number,
  height: number,
  isSoftwareGl: boolean,
): THREE.WebGLRenderer {
  const renderer = new THREE.WebGLRenderer({
    antialias: !isSoftwareGl,
    powerPreference: 'high-performance',
    alpha: true,
  });
  renderer.setSize(width, height);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.12;
  renderer.setPixelRatio(
    isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2),
  );
  renderer.shadowMap.enabled = !isSoftwareGl;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  return renderer;
}

export function setupStudioEnvironment(
  renderer: THREE.WebGLRenderer,
  scene: THREE.Scene,
): THREE.Texture {
  const pmremGenerator = new THREE.PMREMGenerator(renderer);
  const envTex = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
  scene.environment = envTex;
  pmremGenerator.dispose();
  return envTex;
}

export function createProceduralPlanetTexture(
  body: BodyTarget,
  maxAnisotropy: number,
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  if (body === 'Moon') {
    const baseGrad = ctx.createLinearGradient(0, 0, 1024, 512);
    baseGrad.addColorStop(0, '#8d939c');
    baseGrad.addColorStop(0.5, '#a4aab3');
    baseGrad.addColorStop(1, '#7c828b');
    ctx.fillStyle = baseGrad;
    ctx.fillRect(0, 0, 1024, 512);

    const maria = [
      { x: 580, y: 240, rx: 140, ry: 90, a: 0.48 },
      { x: 360, y: 210, rx: 165, ry: 110, a: 0.44 },
      { x: 640, y: 170, rx: 95, ry: 65, a: 0.4 },
      { x: 470, y: 150, rx: 110, ry: 75, a: 0.35 },
    ];
    for (const m of maria) {
      const g = ctx.createRadialGradient(m.x, m.y, 10, m.x, m.y, m.rx);
      g.addColorStop(0, `rgba(45, 50, 58, ${m.a})`);
      g.addColorStop(1, 'rgba(45, 50, 58, 0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.ellipse(m.x, m.y, m.rx, m.ry, 0.2, 0, Math.PI * 2);
      ctx.fill();
    }

    let seed = 1969;
    const rand = () => {
      seed = (seed * 1664525 + 1013904223) % 4294967296;
      return seed / 4294967296;
    };

    for (let i = 0; i < 240; i++) {
      const cx = rand() * 1024;
      const cy = 24 + rand() * 464;
      const r = 3 + rand() * 22;
      ctx.fillStyle = 'rgba(55, 60, 68, 0.35)';
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = 'rgba(220, 226, 235, 0.32)';
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.arc(cx - 1, cy - 1, r, 0, Math.PI * 2);
      ctx.stroke();
    }
  } else {
    const baseGrad = ctx.createLinearGradient(0, 0, 1024, 512);
    baseGrad.addColorStop(0, '#a64d2b');
    baseGrad.addColorStop(0.5, '#c46238');
    baseGrad.addColorStop(1, '#8f3f24');
    ctx.fillStyle = baseGrad;
    ctx.fillRect(0, 0, 1024, 512);

    const plains = [
      { x: 640, y: 230, rx: 130, ry: 75, a: 0.42 },
      { x: 380, y: 185, rx: 145, ry: 85, a: 0.36 },
      { x: 780, y: 280, rx: 110, ry: 60, a: 0.35 },
    ];
    for (const p of plains) {
      const g = ctx.createRadialGradient(p.x, p.y, 8, p.x, p.y, p.rx);
      g.addColorStop(0, `rgba(68, 28, 18, ${p.a})`);
      g.addColorStop(1, 'rgba(68, 28, 18, 0)');
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.ellipse(p.x, p.y, p.rx, p.ry, -0.25, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.strokeStyle = 'rgba(58, 20, 12, 0.55)';
    ctx.lineWidth = 7;
    ctx.beginPath();
    ctx.moveTo(280, 272);
    ctx.quadraticCurveTo(360, 282, 435, 268);
    ctx.stroke();

    const northCap = ctx.createLinearGradient(0, 0, 0, 38);
    northCap.addColorStop(0, 'rgba(241, 245, 249, 0.9)');
    northCap.addColorStop(1, 'rgba(241, 245, 249, 0)');
    ctx.fillStyle = northCap;
    ctx.fillRect(0, 0, 1024, 38);

    const southCap = ctx.createLinearGradient(0, 478, 0, 512);
    southCap.addColorStop(0, 'rgba(241, 245, 249, 0)');
    southCap.addColorStop(1, 'rgba(241, 245, 249, 0.85)');
    ctx.fillStyle = southCap;
    ctx.fillRect(0, 478, 1024, 34);

    let seed = 2021;
    const rand = () => {
      seed = (seed * 1664525 + 1013904223) % 4294967296;
      return seed / 4294967296;
    };
    for (let i = 0; i < 160; i++) {
      const cx = rand() * 1024;
      const cy = 42 + rand() * 428;
      const r = 2 + rand() * 14;
      ctx.fillStyle = 'rgba(72, 26, 15, 0.28)';
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  texture.needsUpdate = true;
  return texture;
}

export function createSurfaceTerrainTextures(
  body: BodyTarget,
  maxAnisotropy: number,
): { map: THREE.CanvasTexture; bumpMap: THREE.CanvasTexture } {
  const size = 512;
  const colorCanvas = document.createElement('canvas');
  colorCanvas.width = size;
  colorCanvas.height = size;
  const cCtx = colorCanvas.getContext('2d')!;

  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = size;
  bumpCanvas.height = size;
  const bCtx = bumpCanvas.getContext('2d')!;

  let seed = body === 'Mars' ? 4096 : 1971;
  const rand = () => {
    seed = (seed * 1664525 + 1013904223) % 4294967296;
    return seed / 4294967296;
  };

  if (body === 'Mars') {
    cCtx.fillStyle = '#9c4c28';
    cCtx.fillRect(0, 0, size, size);
    bCtx.fillStyle = '#7a7a7a';
    bCtx.fillRect(0, 0, size, size);

    // Wind-carved iron-oxide sand ripples
    for (let y = 0; y < size; y += 6) {
      const shade = 0.08 + rand() * 0.09;
      cCtx.fillStyle = rand() > 0.5 ? `rgba(218, 128, 72, ${shade})` : `rgba(74, 28, 14, ${shade})`;
      cCtx.fillRect(0, y, size, 3);
      bCtx.fillStyle = rand() > 0.5 ? 'rgba(185,185,185,0.22)' : 'rgba(70,70,70,0.22)';
      bCtx.fillRect(0, y, size, 3);
    }

    // Scattered mineral dust patches & basalt pebbles
    for (let i = 0; i < 650; i++) {
      const px = rand() * size;
      const py = rand() * size;
      const r = 1 + rand() * 5.5;
      cCtx.fillStyle =
        rand() > 0.45 ? 'rgba(54, 22, 13, 0.35)' : 'rgba(214, 118, 62, 0.28)';
      cCtx.beginPath();
      cCtx.arc(px, py, r, 0, Math.PI * 2);
      cCtx.fill();

      bCtx.fillStyle = rand() > 0.5 ? 'rgba(220,220,220,0.35)' : 'rgba(40,40,40,0.35)';
      bCtx.beginPath();
      bCtx.arc(px, py, r, 0, Math.PI * 2);
      bCtx.fill();
    }
  } else {
    cCtx.fillStyle = '#6c727d';
    cCtx.fillRect(0, 0, size, size);
    bCtx.fillStyle = '#808080';
    bCtx.fillRect(0, 0, size, size);

    // Regolith micro-craters & rover/boot dust disturbance streaks
    for (let i = 0; i < 420; i++) {
      const px = rand() * size;
      const py = rand() * size;
      const r = 1.5 + rand() * 9;
      cCtx.fillStyle = 'rgba(46, 51, 58, 0.36)';
      cCtx.beginPath();
      cCtx.arc(px, py, r, 0, Math.PI * 2);
      cCtx.fill();

      cCtx.strokeStyle = 'rgba(190, 198, 210, 0.24)';
      cCtx.lineWidth = 1.2;
      cCtx.beginPath();
      cCtx.arc(px - 0.8, py - 0.8, r, 0, Math.PI * 2);
      cCtx.stroke();

      bCtx.fillStyle = 'rgba(48,48,48,0.45)';
      bCtx.beginPath();
      bCtx.arc(px, py, r, 0, Math.PI * 2);
      bCtx.fill();
    }
  }

  const map = new THREE.CanvasTexture(colorCanvas);
  map.colorSpace = THREE.SRGBColorSpace;
  map.wrapS = THREE.RepeatWrapping;
  map.wrapT = THREE.RepeatWrapping;
  map.repeat.set(8, 8);
  map.anisotropy = maxAnisotropy;

  const bumpMap = new THREE.CanvasTexture(bumpCanvas);
  bumpMap.wrapS = THREE.RepeatWrapping;
  bumpMap.wrapT = THREE.RepeatWrapping;
  bumpMap.repeat.set(8, 8);
  bumpMap.anisotropy = maxAnisotropy;

  return { map, bumpMap };
}

export function createEarthSkyTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;

  const ocean = ctx.createLinearGradient(0, 0, 256, 128);
  ocean.addColorStop(0, '#0f4c81');
  ocean.addColorStop(0.5, '#1d75c2');
  ocean.addColorStop(1, '#0c3b66');
  ctx.fillStyle = ocean;
  ctx.fillRect(0, 0, 256, 128);

  // Continents & polar clouds
  ctx.fillStyle = 'rgba(90, 168, 118, 0.72)';
  ctx.beginPath();
  ctx.ellipse(90, 56, 26, 18, 0.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(165, 64, 32, 22, -0.3, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = 'rgba(240, 248, 255, 0.78)';
  ctx.fillRect(0, 0, 256, 12);
  ctx.fillRect(0, 116, 256, 12);
  for (let i = 0; i < 14; i++) {
    ctx.beginPath();
    ctx.ellipse(20 + i * 18, 30 + ((i * 23) % 68), 18, 5, 0.2, 0, Math.PI * 2);
    ctx.fill();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export function createRadialShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(64, 64, 8, 64, 64, 62);
  grad.addColorStop(0, 'rgba(0,0,0,0.68)');
  grad.addColorStop(0.6, 'rgba(0,0,0,0.28)');
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);
  const tex = new THREE.CanvasTexture(canvas);
  tex.needsUpdate = true;
  return tex;
}

export function buildSpacecraftModel(
  type: Model3DType,
): { group: THREE.Group; partMeshes: Map<string, THREE.Mesh[]> } {
  const group = new THREE.Group();
  const partMeshes = new Map<string, THREE.Mesh[]>();

  const registerPart = (partIds: string | string[], mesh: THREE.Mesh) => {
    const ids = Array.isArray(partIds) ? partIds : [partIds];
    mesh.userData.componentId = ids[0];
    mesh.userData.componentIds = ids;
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    for (const partId of ids) {
      const list = partMeshes.get(partId) ?? [];
      list.push(mesh);
      partMeshes.set(partId, list);
    }
    group.add(mesh);
  };

  const addStructuralMesh = (mesh: THREE.Mesh) => {
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    group.add(mesh);
  };

  const goldFoilMat = new THREE.MeshStandardMaterial({
    color: 0xe3a128,
    metalness: 0.88,
    roughness: 0.26,
  });
  const titaniumMat = new THREE.MeshStandardMaterial({
    color: 0xc2ccd8,
    metalness: 0.84,
    roughness: 0.24,
  });
  const whiteThermalMat = new THREE.MeshStandardMaterial({
    color: 0xeaf0f7,
    metalness: 0.16,
    roughness: 0.52,
  });
  const darkCarbonMat = new THREE.MeshStandardMaterial({
    color: 0x1c2431,
    metalness: 0.45,
    roughness: 0.68,
  });
  const solarCellMat = new THREE.MeshStandardMaterial({
    color: 0x11366f,
    metalness: 0.72,
    roughness: 0.18,
  });
  const cyanOpticMat = new THREE.MeshStandardMaterial({
    color: 0x22d3ee,
    emissive: 0x0891b2,
    emissiveIntensity: 0.75,
    metalness: 0.3,
    roughness: 0.15,
  });

  if (type === 'lunar-module') {
    const descentBody = new THREE.Mesh(
      new THREE.CylinderGeometry(1.1, 1.15, 0.82, 8),
      goldFoilMat.clone(),
    );
    descentBody.position.y = 0.92;
    registerPart(['kapton-descent', 'snap27'], descentBody);

    const bell = new THREE.Mesh(
      new THREE.CylinderGeometry(0.18, 0.42, 0.55, 24, 1, true),
      darkCarbonMat.clone(),
    );
    bell.position.y = 0.35;
    registerPart(['kapton-descent', 'ascent-engine', 'pse'], bell);

    for (let i = 0; i < 4; i++) {
      const angle = (i * Math.PI) / 2 + Math.PI / 4;
      const strut = new THREE.Mesh(
        new THREE.CylinderGeometry(0.055, 0.055, 1.45, 12),
        goldFoilMat.clone(),
      );
      strut.position.set(
        Math.cos(angle) * 1.35,
        0.52,
        Math.sin(angle) * 1.35,
      );
      strut.rotation.z = Math.cos(angle) * 0.48;
      strut.rotation.x = -Math.sin(angle) * 0.48;
      registerPart(['landing-gear', 'pse'], strut);

      const footpad = new THREE.Mesh(
        new THREE.CylinderGeometry(0.28, 0.32, 0.08, 20),
        goldFoilMat.clone(),
      );
      footpad.position.set(
        Math.cos(angle) * 1.65,
        0.04,
        Math.sin(angle) * 1.65,
      );
      registerPart(['landing-gear', 'pse'], footpad);
    }

    const ascentMain = new THREE.Mesh(
      new THREE.CylinderGeometry(0.86, 0.92, 0.95, 10),
      whiteThermalMat.clone(),
    );
    ascentMain.position.y = 1.82;
    registerPart(['ascent-cabin', 'lsm'], ascentMain);

    const forwardHatch = new THREE.Mesh(
      new THREE.BoxGeometry(0.75, 0.78, 0.58),
      darkCarbonMat.clone(),
    );
    forwardHatch.position.set(0, 1.78, 0.72);
    registerPart(['ascent-cabin', 'lsm'], forwardHatch);

    for (const wx of [-0.22, 0.22]) {
      const windowPane = new THREE.Mesh(
        new THREE.BoxGeometry(0.2, 0.16, 0.05),
        cyanOpticMat.clone(),
      );
      windowPane.position.set(wx, 1.98, 1.01);
      addStructuralMesh(windowPane);
    }

    const dockingRing = new THREE.Mesh(
      new THREE.CylinderGeometry(0.34, 0.36, 0.22, 18),
      titaniumMat.clone(),
    );
    dockingRing.position.set(0, 2.38, 0);
    registerPart(['docking-tunnel', 'ascent-cabin'], dockingRing);

    const dishMast = new THREE.Mesh(
      new THREE.CylinderGeometry(0.04, 0.04, 0.55, 10),
      titaniumMat.clone(),
    );
    dishMast.position.set(0.55, 2.45, 0.25);
    registerPart(['s-band-dish', 'central-station'], dishMast);

    const dish = new THREE.Mesh(
      new THREE.ConeGeometry(0.38, 0.14, 24, 1, true),
      titaniumMat.clone(),
    );
    dish.position.set(0.55, 2.74, 0.3);
    dish.rotation.x = Math.PI * 0.65;
    registerPart(['s-band-dish', 'central-station'], dish);
  } else if (type === 'lunar-rover') {
    const deck = new THREE.Mesh(
      new THREE.BoxGeometry(1.5, 0.14, 2.2),
      titaniumMat.clone(),
    );
    deck.position.y = 0.56;
    registerPart('nav-console', deck);

    for (const sx of [-0.36, 0.36]) {
      const seat = new THREE.Mesh(
        new THREE.BoxGeometry(0.45, 0.45, 0.48),
        whiteThermalMat.clone(),
      );
      seat.position.set(sx, 0.85, -0.15);
      registerPart('nav-console', seat);
    }

    const wheelOffsets: Array<[number, number]> = [
      [-0.88, 0.82],
      [0.88, 0.82],
      [-0.88, -0.82],
      [0.88, -0.82],
    ];
    for (const [wx, wz] of wheelOffsets) {
      const wheel = new THREE.Mesh(
        new THREE.CylinderGeometry(0.36, 0.36, 0.22, 22),
        titaniumMat.clone(),
      );
      wheel.rotation.z = Math.PI / 2;
      wheel.position.set(wx, 0.36, wz);
      registerPart('wire-wheels', wheel);

      const hub = new THREE.Mesh(
        new THREE.CylinderGeometry(0.14, 0.14, 0.25, 12),
        goldFoilMat.clone(),
      );
      hub.rotation.z = Math.PI / 2;
      hub.position.set(wx, 0.36, wz);
      addStructuralMesh(hub);
    }

    const dishPole = new THREE.Mesh(
      new THREE.CylinderGeometry(0.03, 0.03, 0.9, 10),
      titaniumMat.clone(),
    );
    dishPole.position.set(0.42, 1.05, 0.78);
    registerPart('high-gain-dish', dishPole);

    const umbrellaDish = new THREE.Mesh(
      new THREE.ConeGeometry(0.52, 0.22, 18, 1, true),
      goldFoilMat.clone(),
    );
    umbrellaDish.position.set(0.42, 1.5, 0.82);
    umbrellaDish.rotation.x = Math.PI * 0.72;
    registerPart('high-gain-dish', umbrellaDish);

    const camPole = new THREE.Mesh(
      new THREE.CylinderGeometry(0.035, 0.035, 0.85, 10),
      titaniumMat.clone(),
    );
    camPole.position.set(-0.35, 1.0, 0.72);
    registerPart('lcrv-camera', camPole);

    const camHead = new THREE.Mesh(
      new THREE.BoxGeometry(0.24, 0.2, 0.32),
      whiteThermalMat.clone(),
    );
    camHead.position.set(-0.35, 1.44, 0.75);
    registerPart('lcrv-camera', camHead);

    const lens = new THREE.Mesh(
      new THREE.CylinderGeometry(0.06, 0.06, 0.06, 12),
      cyanOpticMat.clone(),
    );
    lens.rotation.x = Math.PI / 2;
    lens.position.set(-0.35, 1.44, 0.92);
    addStructuralMesh(lens);
  } else if (type === 'mer-rover') {
    const warmBox = new THREE.Mesh(
      new THREE.BoxGeometry(0.95, 0.45, 1.05),
      goldFoilMat.clone(),
    );
    warmBox.position.y = 0.65;
    registerPart('apxs', warmBox);

    const solarDeck = new THREE.Mesh(
      new THREE.BoxGeometry(1.98, 0.06, 1.42),
      solarCellMat.clone(),
    );
    solarDeck.position.y = 0.9;
    registerPart('mer-solar-wings', solarDeck);

    // Solar wing side flaps
    for (const sx of [-1.18, 1.18]) {
      const wing = new THREE.Mesh(
        new THREE.BoxGeometry(0.46, 0.04, 1.1),
        solarCellMat.clone(),
      );
      wing.position.set(sx, 0.88, -0.05);
      wing.rotation.z = sx < 0 ? 0.08 : -0.08;
      registerPart('mer-solar-wings', wing);
    }

    // Rocker-bogie suspension struts + 6 wheels with hub caps
    for (const sx of [-0.78, 0.78]) {
      const bogieBar = new THREE.Mesh(
        new THREE.BoxGeometry(0.06, 0.06, 1.46),
        titaniumMat.clone(),
      );
      bogieBar.position.set(sx * 0.85, 0.46, 0);
      addStructuralMesh(bogieBar);

      for (const sz of [-0.72, 0, 0.72]) {
        const wheel = new THREE.Mesh(
          new THREE.CylinderGeometry(0.22, 0.22, 0.16, 18),
          darkCarbonMat.clone(),
        );
        wheel.rotation.z = Math.PI / 2;
        wheel.position.set(sx, 0.22, sz);
        registerPart(['opp-wheels', 'rocker-bogie'], wheel);

        const hub = new THREE.Mesh(
          new THREE.CylinderGeometry(0.09, 0.09, 0.18, 12),
          titaniumMat.clone(),
        );
        hub.rotation.z = Math.PI / 2;
        hub.position.set(sx, 0.22, sz);
        addStructuralMesh(hub);
      }
    }

    const mast = new THREE.Mesh(
      new THREE.CylinderGeometry(0.045, 0.045, 0.95, 10),
      titaniumMat.clone(),
    );
    mast.position.set(0.22, 1.35, 0.38);
    registerPart(['pancam-mast', 'opp-pancam'], mast);

    const mastHead = new THREE.Mesh(
      new THREE.BoxGeometry(0.44, 0.16, 0.18),
      whiteThermalMat.clone(),
    );
    mastHead.position.set(0.22, 1.85, 0.42);
    registerPart(['pancam-mast', 'opp-pancam'], mastHead);

    for (const ex of [0.1, 0.34]) {
      const eye = new THREE.Mesh(
        new THREE.CylinderGeometry(0.036, 0.036, 0.05, 12),
        cyanOpticMat.clone(),
      );
      eye.rotation.x = Math.PI / 2;
      eye.position.set(ex, 1.86, 0.52);
      addStructuralMesh(eye);
    }

    // High-gain antenna dish
    const hga = new THREE.Mesh(
      new THREE.CylinderGeometry(0.24, 0.06, 0.08, 18),
      titaniumMat.clone(),
    );
    hga.position.set(-0.38, 1.06, -0.35);
    hga.rotation.x = -0.35;
    addStructuralMesh(hga);

    // Instrument Deployment Arm + RAT
    const armUpper = new THREE.Mesh(
      new THREE.BoxGeometry(0.09, 0.09, 0.82),
      titaniumMat.clone(),
    );
    armUpper.position.set(-0.22, 0.7, 0.82);
    armUpper.rotation.x = 0.35;
    registerPart(['rat-arm', 'apxs'], armUpper);

    const armHead = new THREE.Mesh(
      new THREE.CylinderGeometry(0.11, 0.11, 0.14, 14),
      goldFoilMat.clone(),
    );
    armHead.position.set(-0.22, 0.52, 1.24);
    registerPart(['rat-arm', 'apxs'], armHead);
  } else if (type === 'msl-rover') {
    // White chassis + internal MOXIE bay
    const body = new THREE.Mesh(
      new THREE.BoxGeometry(1.18, 0.56, 1.85),
      whiteThermalMat.clone(),
    );
    body.position.y = 0.78;
    registerPart('moxie-unit', body);

    const topDeck = new THREE.Mesh(
      new THREE.BoxGeometry(1.12, 0.08, 1.65),
      goldFoilMat.clone(),
    );
    topDeck.position.y = 1.08;
    addStructuralMesh(topDeck);

    // Rear MMRTG Nuclear Battery + cooling fins
    const mmrtg = new THREE.Mesh(
      new THREE.CylinderGeometry(0.24, 0.28, 0.78, 12),
      darkCarbonMat.clone(),
    );
    mmrtg.rotation.x = Math.PI * 0.28;
    mmrtg.position.set(0, 0.92, -1.12);
    registerPart('mmrtg', mmrtg);

    for (let f = 0; f < 4; f++) {
      const fin = new THREE.Mesh(
        new THREE.BoxGeometry(0.62, 0.03, 0.65),
        titaniumMat.clone(),
      );
      fin.rotation.x = Math.PI * 0.28;
      fin.rotation.z = (f * Math.PI) / 4;
      fin.position.set(0, 0.92, -1.12);
      addStructuralMesh(fin);
    }

    // Rocker-bogie struts + 6 large cleated wheels
    for (const sx of [-0.95, 0.95]) {
      const strut = new THREE.Mesh(
        new THREE.BoxGeometry(0.07, 0.08, 1.88),
        titaniumMat.clone(),
      );
      strut.position.set(sx * 0.84, 0.58, 0);
      addStructuralMesh(strut);

      for (const sz of [-0.92, 0, 0.92]) {
        const wheel = new THREE.Mesh(
          new THREE.CylinderGeometry(0.3, 0.3, 0.24, 22),
          darkCarbonMat.clone(),
        );
        wheel.rotation.z = Math.PI / 2;
        wheel.position.set(sx, 0.3, sz);
        addStructuralMesh(wheel);

        const hub = new THREE.Mesh(
          new THREE.CylinderGeometry(0.12, 0.12, 0.26, 12),
          titaniumMat.clone(),
        );
        hub.rotation.z = Math.PI / 2;
        hub.position.set(sx, 0.3, sz);
        addStructuralMesh(hub);
      }
    }

    // Mastcam / ChemCam / SuperCam Head
    const mastPole = new THREE.Mesh(
      new THREE.CylinderGeometry(0.055, 0.055, 0.92, 10),
      whiteThermalMat.clone(),
    );
    mastPole.position.set(0.28, 1.48, 0.55);
    registerPart(['chemcam', 'supercam-head'], mastPole);

    const headBox = new THREE.Mesh(
      new THREE.BoxGeometry(0.46, 0.24, 0.3),
      whiteThermalMat.clone(),
    );
    headBox.position.set(0.28, 1.98, 0.58);
    registerPart(['chemcam', 'supercam-head'], headBox);

    const cyclops = new THREE.Mesh(
      new THREE.CylinderGeometry(0.065, 0.065, 0.06, 16),
      cyanOpticMat.clone(),
    );
    cyclops.rotation.x = Math.PI / 2;
    cyclops.position.set(0.28, 1.99, 0.74);
    addStructuralMesh(cyclops);

    // High-gain antenna
    const hga = new THREE.Mesh(
      new THREE.CylinderGeometry(0.26, 0.06, 0.09, 20),
      whiteThermalMat.clone(),
    );
    hga.position.set(-0.35, 1.24, -0.45);
    hga.rotation.x = -0.3;
    addStructuralMesh(hga);

    // 5-DOF Coring Drill Arm + Turret
    const armSeg = new THREE.Mesh(
      new THREE.BoxGeometry(0.12, 0.12, 1.05),
      titaniumMat.clone(),
    );
    armSeg.position.set(-0.25, 0.72, 1.32);
    armSeg.rotation.x = 0.22;
    registerPart(['sample-arm', 'corer-turret'], armSeg);

    const turret = new THREE.Mesh(
      new THREE.CylinderGeometry(0.24, 0.24, 0.22, 16),
      goldFoilMat.clone(),
    );
    turret.position.set(-0.25, 0.58, 1.82);
    registerPart(['sample-arm', 'corer-turret'], turret);
  } else {
    const deck = new THREE.Mesh(
      new THREE.CylinderGeometry(0.85, 0.85, 0.28, 6),
      goldFoilMat.clone(),
    );
    deck.position.y = 0.72;
    addStructuralMesh(deck);

    for (let i = 0; i < 3; i++) {
      const a = (i * Math.PI * 2) / 3;
      const leg = new THREE.Mesh(
        new THREE.CylinderGeometry(0.045, 0.045, 0.85, 10),
        titaniumMat.clone(),
      );
      leg.position.set(Math.cos(a) * 0.78, 0.36, Math.sin(a) * 0.78);
      leg.rotation.z = Math.cos(a) * 0.35;
      leg.rotation.x = -Math.sin(a) * 0.35;
      addStructuralMesh(leg);
    }

    const armBoom = new THREE.Mesh(
      new THREE.BoxGeometry(0.08, 0.08, 1.05),
      titaniumMat.clone(),
    );
    armBoom.position.set(0.24, 0.92, 0.78);
    armBoom.rotation.x = 0.34;
    armBoom.rotation.y = -0.18;
    registerPart(['ida-arm', 'soil-scoop'], armBoom);

    for (const sx of [-1.55, 1.55]) {
      const array = new THREE.Mesh(
        new THREE.CylinderGeometry(0.75, 0.75, 0.04, 10),
        solarCellMat.clone(),
      );
      array.position.set(sx, 0.84, 0);
      registerPart(['ultraflex-arrays', 'solar-mast'], array);
    }

    const dome = new THREE.Mesh(
      new THREE.SphereGeometry(0.32, 20, 14, 0, Math.PI * 2, 0, Math.PI / 2),
      whiteThermalMat.clone(),
    );
    dome.position.set(0, 0.02, 1.28);
    registerPart('seis-dome', dome);
  }

  return { group, partMeshes };
}
