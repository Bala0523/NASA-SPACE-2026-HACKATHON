import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { Eye, EyeOff, Minus, Plus, RotateCcw } from 'lucide-react';
import type { LearningMode, SpaceArtifact } from '../../types/museum';
import { SafeImage } from '../SafeImage';
import {
  buildSpacecraftModel,
  createStudioRenderer,
  detectSoftwareGl,
  setupStudioEnvironment,
} from './threeUtils';

interface EquipmentMuseum3DProps {
  artifacts: SpaceArtifact[];
  selectedArtifactId: string;
  onSelectArtifactId: (id: string) => void;
  learningMode: LearningMode;
}

export function EquipmentMuseum3D({
  artifacts,
  selectedArtifactId,
  onSelectArtifactId,
  learningMode,
}: EquipmentMuseum3DProps) {
  const activeArtifact =
    artifacts.find((a) => a.id === selectedArtifactId) ?? artifacts[0];

  const [selectedComponentId, setSelectedComponentId] = useState<string>(
    activeArtifact.components[0]?.id ?? '',
  );
  const [controlsCollapsed, setControlsCollapsed] = useState(false);
  const [webglError, setWebglError] = useState(false);

  const mountRef = useRef<HTMLDivElement>(null);
  const selectedCompRef = useRef(selectedComponentId);
  const activeComponentsRef = useRef(activeArtifact.components);
  const cameraApiRef = useRef<{
    zoom: (delta: number) => void;
    reset: () => void;
    highlightComponent: (compId: string) => void;
  } | null>(null);

  selectedCompRef.current = selectedComponentId;
  activeComponentsRef.current = activeArtifact.components;

  useEffect(() => {
    setSelectedComponentId(activeArtifact.components[0]?.id ?? '');
  }, [activeArtifact.id, activeArtifact.components]);

  useEffect(() => {
    if (selectedComponentId && cameraApiRef.current) {
      cameraApiRef.current.highlightComponent(selectedComponentId);
    }
  }, [selectedComponentId]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    let disposed = false;
    let frameId = 0;
    let renderer: THREE.WebGLRenderer | null = null;
    let envTex: THREE.Texture | null = null;

    try {
      const width = container.clientWidth || 720;
      const height = container.clientHeight || 460;
      const isSoftwareGl = detectSoftwareGl();

      const scene = new THREE.Scene();
      scene.background = new THREE.Color(0x080b12);
      scene.fog = new THREE.FogExp2(0x080b12, 0.045);

      const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
      camera.position.set(4.1, 2.7, 5.2);

      renderer = createStudioRenderer(width, height, isSoftwareGl);
      renderer.domElement.style.display = 'block';
      renderer.domElement.style.width = '100%';
      renderer.domElement.style.height = '100%';
      container.innerHTML = '';
      container.appendChild(renderer.domElement);

      envTex = setupStudioEnvironment(renderer, scene);

      const controls = new OrbitControls(camera, renderer.domElement);
      controls.target.set(0, 1.0, 0);
      controls.minDistance = 2.6;
      controls.maxDistance = 9.5;
      controls.maxPolarAngle = Math.PI * 0.54;
      controls.enableDamping = !isSoftwareGl;
      controls.dampingFactor = 0.06;

      // Museum Pedestal & Subtle Grid Floor
      const floorGeo = new THREE.CircleGeometry(6, 48);
      const floorMat = new THREE.MeshStandardMaterial({
        color: 0x0b1220,
        roughness: 0.85,
        metalness: 0.15,
      });
      const floor = new THREE.Mesh(floorGeo, floorMat);
      floor.rotation.x = -Math.PI / 2;
      floor.receiveShadow = true;
      scene.add(floor);

      const pedestalGeo = new THREE.CylinderGeometry(1.9, 2.1, 0.08, 40);
      const pedestalMat = new THREE.MeshStandardMaterial({
        color: 0x101b2d,
        roughness: 0.45,
        metalness: 0.6,
      });
      const pedestal = new THREE.Mesh(pedestalGeo, pedestalMat);
      pedestal.position.y = 0.04;
      pedestal.receiveShadow = true;
      scene.add(pedestal);

      // 3-point museum studio lighting
      const keyLight = new THREE.DirectionalLight(0xfff4e0, 2.4);
      keyLight.position.set(5, 7, 4);
      if (!isSoftwareGl) {
        keyLight.castShadow = true;
        keyLight.shadow.mapSize.set(1024, 1024);
        keyLight.shadow.bias = -0.0005;
      }
      scene.add(keyLight);

      const hemi = new THREE.HemisphereLight(0x8beaff, 0x080b12, 0.75);
      scene.add(hemi);

      const rimLight = new THREE.DirectionalLight(0x38dfff, 1.15);
      rimLight.position.set(-5, 3, -5);
      scene.add(rimLight);

      // Build active composite procedural spacecraft model
      const { group, partMeshes } = buildSpacecraftModel(
        activeArtifact.model3DType,
      );
      group.position.y = 0.08;
      scene.add(group);

      const allInteractiveSet = new Set<THREE.Mesh>();
      partMeshes.forEach((list) => {
        for (const m of list) allInteractiveSet.add(m);
      });
      const allInteractive = Array.from(allInteractiveSet);

      let renderBusy = false;
      let renderDirty = false;
      const _vec = new THREE.Vector3();

      function applyComponentHighlight(compId: string) {
        for (const m of allInteractive) {
          const ids = (m.userData.componentIds as string[] | undefined) ?? [];
          const isMatch = ids.includes(compId);
          const mat = m.material as THREE.MeshStandardMaterial;
          mat.emissive.setHex(isMatch ? 0x38dfff : 0x000000);
          mat.emissiveIntensity = isMatch ? 0.3 : 0;
        }
      }

      function afterDraw(cb: () => void) {
        if (!renderer || disposed) return;
        const gl = renderer.getContext() as WebGL2RenderingContext;
        if (!gl || typeof gl.fenceSync !== 'function') {
          frameId = window.setTimeout(cb, 80);
          return;
        }
        const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
        gl.flush();
        const poll = () => {
          if (disposed) return;
          const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
          if (state === gl.UNSIGNALED) {
            frameId = window.setTimeout(poll, 5);
          } else {
            if (sync) gl.deleteSync(sync);
            frameId = window.setTimeout(cb, 80);
          }
        };
        frameId = window.setTimeout(poll, 5);
      }

      function requestRender() {
        if (disposed || !renderer) return;
        if (renderBusy) {
          renderDirty = true;
          return;
        }
        renderBusy = true;
        frameId = requestAnimationFrame(() => {
          if (disposed || !renderer) return;
          renderDirty = false;
          controls.update();
          renderer.render(scene, camera);
          const done = () => {
            renderBusy = false;
            if (renderDirty && !disposed) requestRender();
          };
          if (isSoftwareGl) afterDraw(done);
          else done();
        });
      }

      controls.addEventListener('change', requestRender);

      cameraApiRef.current = {
        zoom: (delta: number) => {
          _vec.copy(camera.position).sub(controls.target);
          const dist = THREE.MathUtils.clamp(
            _vec.length() + delta,
            controls.minDistance,
            controls.maxDistance,
          );
          _vec.normalize().multiplyScalar(dist).add(controls.target);
          camera.position.copy(_vec);
          requestRender();
        },
        reset: () => {
          camera.position.set(4.1, 2.7, 5.2);
          controls.target.set(0, 1.0, 0);
          requestRender();
        },
        highlightComponent: (compId: string) => {
          applyComponentHighlight(compId);
          requestRender();
        },
      };

      // Raycasting on component click
      const raycaster = new THREE.Raycaster();
      const pointer = new THREE.Vector2();
      let downPos = { x: 0, y: 0 };

      const handlePointerDown = (e: PointerEvent) => {
        downPos = { x: e.clientX, y: e.clientY };
      };
      const handlePointerUp = (e: PointerEvent) => {
        if (Math.hypot(e.clientX - downPos.x, e.clientY - downPos.y) > 6 || !renderer) {
          return;
        }
        const rect = renderer.domElement.getBoundingClientRect();
        pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
        pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
        raycaster.setFromCamera(pointer, camera);
        const hits = raycaster.intersectObjects(allInteractive, false);
        if (hits.length > 0) {
          const cids = (hits[0].object.userData.componentIds as string[] | undefined) ?? [];
          const validIds = new Set(activeComponentsRef.current.map((c) => c.id));
          const matched = cids.find((id) => validIds.has(id)) ?? cids[0];
          if (matched) {
            setSelectedComponentId(matched);
          }
        }
      };

      renderer.domElement.addEventListener('pointerdown', handlePointerDown);
      renderer.domElement.addEventListener('pointerup', handlePointerUp);

      const handleResize = () => {
        if (!container || !renderer || disposed) return;
        const w = container.clientWidth || 720;
        const h = container.clientHeight || 460;
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
        requestRender();
      };
      window.addEventListener('resize', handleResize);

      const handleContextLost = (ev: Event) => {
        ev.preventDefault();
        setWebglError(true);
      };
      renderer.domElement.addEventListener('webglcontextlost', handleContextLost);

      applyComponentHighlight(selectedCompRef.current);
      requestRender();

      return () => {
        disposed = true;
        cancelAnimationFrame(frameId);
        clearTimeout(frameId);
        window.removeEventListener('resize', handleResize);
        renderer?.domElement.removeEventListener('pointerdown', handlePointerDown);
        renderer?.domElement.removeEventListener('pointerup', handlePointerUp);
        renderer?.domElement.removeEventListener('webglcontextlost', handleContextLost);
        controls.dispose();
        floorGeo.dispose();
        floorMat.dispose();
        pedestalGeo.dispose();
        pedestalMat.dispose();
        group.traverse((child) => {
          if (child instanceof THREE.Mesh) {
            child.geometry.dispose();
            if (Array.isArray(child.material)) {
              child.material.forEach((m) => m.dispose());
            } else {
              child.material.dispose();
            }
          }
        });
        envTex?.dispose();
        renderer?.dispose();
      };
    } catch {
      setWebglError(true);
    }
  }, [activeArtifact.id, activeArtifact.model3DType]);

  const activeComponent =
    activeArtifact.components.find((c) => c.id === selectedComponentId) ??
    activeArtifact.components[0];

  return (
    <section
      id="equipment-museum"
      className="py-20 lg:py-24 border-b border-white/[0.08] bg-[#080B12]"
    >
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10">
          <div>
            <p className="text-xs font-mono tracking-[0.16em] uppercase text-[#38DFFF] mb-2.5">
              03 · Interactive 3D Space Equipment Museum
            </p>
            <h2 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#F5F7FA] tracking-[-0.02em]">
              Inspect Authentic Spacecraft Subsystems
            </h2>
            <p className="mt-3 text-[#A6B0C0] max-w-2xl text-sm sm:text-base leading-relaxed">
              Rotate, zoom, and click highlighted hardware assemblies on each
              3D museum specimen to learn how engineers built machines to
              survive the Moon and Mars.
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            {[
              { id: 'apollo-11-eagle-descent', label: 'Apollo 11 LM' },
              { id: 'apollo-15-lrv', label: 'Apollo 15 LRV' },
              { id: 'opportunity-mer-b', label: 'Opportunity MER' },
              { id: 'insight-mars', label: 'InSight Lander' },
              { id: 'perseverance-mars2020', label: 'Perseverance MSL' },
            ].map((specimen) => (
              <button
                key={specimen.id}
                type="button"
                onClick={() => onSelectArtifactId(specimen.id)}
                className={`px-3.5 py-2 text-xs font-mono rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  specimen.id === activeArtifact.id
                    ? 'bg-[#38DFFF]/15 border-[#38DFFF]/70 text-[#8BEAFF]'
                    : 'bg-[#0B1220] border-white/12 text-[#A6B0C0] hover:text-[#F5F7FA] hover:border-[#38DFFF]/40'
                }`}
              >
                {specimen.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          <div className="lg:col-span-8 min-w-0 relative h-[440px] sm:h-[520px] rounded-xl overflow-hidden border border-[#38DFFF]/25 bg-[#080B12]">
            {webglError ? (
              <SafeImage
                src={activeArtifact.imageUrl}
                alt={activeArtifact.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <div
                ref={mountRef}
                data-testid="museum-3d-viewport"
                data-active-component={activeComponent?.id ?? ''}
                className="w-full h-full cursor-grab active:cursor-grabbing"
                aria-label={`3D model viewer for ${activeArtifact.name}. Drag to rotate, scroll to zoom, click subsystems to inspect.`}
              />
            )}

            <div className="absolute top-3 left-3 pointer-events-none">
              <div className="px-3 py-1.5 rounded-lg bg-[#0B1220]/90 border border-white/15">
                <span className="text-xs font-semibold text-[#F5F7FA]">
                  {activeArtifact.name}
                </span>
                <span className="text-xs text-[#737F91] mx-2">·</span>
                <span className="text-xs font-mono tabular-nums text-[#38DFFF]">
                  {activeArtifact.massKg.toLocaleString()} kg
                </span>
              </div>
            </div>

            <div className="absolute bottom-3 left-3 right-3 flex flex-col items-center gap-1.5">
              <button
                type="button"
                onClick={() => setControlsCollapsed((v) => !v)}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#0B1220]/95 border border-white/15 text-[11px] font-mono text-[#A6B0C0] hover:text-[#F5F7FA] cursor-pointer"
              >
                {controlsCollapsed ? (
                  <>
                    <Eye className="w-3 h-3" aria-hidden="true" />
                    <span>Show Controls</span>
                  </>
                ) : (
                  <>
                    <EyeOff className="w-3 h-3" aria-hidden="true" />
                    <span>Hide Controls</span>
                  </>
                )}
              </button>

              {!controlsCollapsed && (
                <div className="flex items-center gap-1 p-1 rounded-xl bg-[#0B1220]/95 border border-white/15 overflow-x-auto max-w-full">
                  {activeArtifact.components.map((comp) => (
                    <button
                      key={comp.id}
                      type="button"
                      onClick={() => setSelectedComponentId(comp.id)}
                      className={`px-2.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                        comp.id === activeComponent?.id
                          ? 'bg-[#38DFFF]/18 text-[#8BEAFF] border border-[#38DFFF]/50'
                          : 'text-[#A6B0C0] hover:text-[#F5F7FA] hover:bg-white/5 border border-transparent'
                      }`}
                    >
                      {comp.name}
                    </button>
                  ))}

                  <div className="h-4 w-px bg-white/15 mx-1 shrink-0" aria-hidden="true" />

                  <button
                    type="button"
                    onClick={() => cameraApiRef.current?.zoom(-0.7)}
                    aria-label="Zoom in 3D equipment"
                    className="p-1.5 text-[#A6B0C0] hover:text-[#F5F7FA] hover:bg-white/10 rounded cursor-pointer shrink-0"
                  >
                    <Plus className="w-4 h-4" aria-hidden="true" />
                  </button>
                  <button
                    type="button"
                    onClick={() => cameraApiRef.current?.zoom(0.7)}
                    aria-label="Zoom out 3D equipment"
                    className="p-1.5 text-[#A6B0C0] hover:text-[#F5F7FA] hover:bg-white/10 rounded cursor-pointer shrink-0"
                  >
                    <Minus className="w-4 h-4" aria-hidden="true" />
                  </button>
                  <button
                    type="button"
                    onClick={() => cameraApiRef.current?.reset()}
                    aria-label="Reset 3D equipment view"
                    className="p-1.5 text-[#A6B0C0] hover:text-[#F5F7FA] hover:bg-white/10 rounded cursor-pointer shrink-0"
                  >
                    <RotateCcw className="w-4 h-4" aria-hidden="true" />
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="lg:col-span-4 min-w-0 flex flex-col justify-between gap-6 lg:border-l lg:border-white/[0.08] lg:pl-7">
            <div>
              <div className="text-[11px] font-mono uppercase tracking-[0.14em] text-[#E7C9A1]">
                Highlighted Subsystem · {activeArtifact.body} Hardware
              </div>
              <h3 className="mt-2 font-editorial text-2xl font-semibold text-[#F5F7FA]">
                {activeComponent?.name ?? 'Spacecraft Assembly'}
              </h3>
              <p className="mt-1.5 text-xs font-mono text-[#38DFFF]">
                Role: {activeComponent?.role}
              </p>

              <p className="mt-4 text-sm text-[#A6B0C0] leading-relaxed">
                {learningMode === 'student'
                  ? activeComponent?.studentExplanation
                  : activeComponent?.scientificExplanation}
              </p>

              <div className="mt-6 pt-5 border-t border-white/[0.08] space-y-3 text-xs">
                <div className="flex justify-between gap-4">
                  <span className="text-[#737F91]">Power Source</span>
                  <span className="text-[#F5F7FA] text-right font-mono">
                    {activeArtifact.powerSource}
                  </span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-[#737F91]">Dry Mass</span>
                  <span className="text-[#F5F7FA] font-mono tabular-nums">
                    {activeArtifact.massKg.toLocaleString()} kg
                  </span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-[#737F91]">Operational Status</span>
                  <span className="text-[#8BEAFF] font-mono text-right">
                    {activeArtifact.status}
                  </span>
                </div>
              </div>
            </div>

            <div className="group rounded-lg overflow-hidden border border-white/[0.08] h-44 relative">
              <SafeImage
                src={activeArtifact.imageUrl}
                alt={`Archival view of ${activeArtifact.name}`}
                className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.03]"
              />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#080B12]/90 to-transparent px-3 py-2.5">
                <p className="text-[11px] font-mono text-[#E7C9A1] truncate">
                  Archival Plate · {activeArtifact.imageAttribution}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
