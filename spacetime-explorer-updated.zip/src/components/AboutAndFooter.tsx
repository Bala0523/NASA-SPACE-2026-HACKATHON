export function AboutAndFooter() {
  return (
    <>
      <section
        id="about-project"
        className="py-20 lg:py-24 border-b border-white/[0.08] bg-[#080B12]"
      >
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <div className="mb-12">
            <p className="text-xs font-mono tracking-[0.16em] uppercase text-[#38DFFF] mb-2.5">
              10 · About the Project
            </p>
            <h2 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#F5F7FA] tracking-[-0.02em]">
              Preserving Humanity&apos;s Off-World Scientific Legacy
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 border-t border-b border-white/[0.08] divide-y lg:divide-y-0 lg:divide-x divide-white/[0.08]">
            <div className="py-8 lg:pr-8">
              <div className="text-xs font-mono text-[#E7C9A1] mb-2">01 · CONTEXT</div>
              <h3 className="font-editorial text-xl font-semibold text-[#F5F7FA]">
                The Problem
              </h3>
              <p className="mt-3 text-sm text-[#A6B0C0] leading-relaxed">
                NASA&apos;s exploration of the Moon and Mars has left behind
                numerous scientific instruments, spacecraft components, and
                retired rovers. Their historical and scientific importance is
                often overlooked or misunderstood as mere space debris.
              </p>
            </div>

            <div className="py-8 lg:px-8">
              <div className="text-xs font-mono text-[#E7C9A1] mb-2">02 · ARCHITECTURE</div>
              <h3 className="font-editorial text-xl font-semibold text-[#F5F7FA]">
                Our Solution
              </h3>
              <p className="mt-3 text-sm text-[#A6B0C0] leading-relaxed">
                SpaceTime Explorer transforms documented lunar and Martian
                hardware into an interactive educational museum combining 3D
                planetary globes, inspectable subsystem models, five-stage
                storytelling, NASA open data, and the ASTRA guide.
              </p>
            </div>

            <div className="py-8 lg:pl-8">
              <div className="text-xs font-mono text-[#E7C9A1] mb-2">03 · PURPOSE</div>
              <h3 className="font-editorial text-xl font-semibold text-[#F5F7FA]">
                Educational Impact
              </h3>
              <ul className="mt-3 space-y-2.5 text-sm text-[#A6B0C0] leading-relaxed">
                <li>Improves accessible K-12 and public space science education</li>
                <li>Preserves verified off-world engineering heritage</li>
                <li>Distinguishes retired relics from active Mars laboratories</li>
                <li>Connects Apollo &amp; MER history to future Artemis missions</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <footer className="bg-[#080B12] pt-12 pb-24 sm:pb-14">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="font-display text-base font-bold tracking-[0.06em] text-[#F5F7FA]">
              SPACETIME <span className="text-[#38DFFF]">EXPLORER</span>
            </div>
            <p className="mt-1.5 text-xs text-[#737F91] max-w-md leading-relaxed">
              Built for the 2026 NASA Space Apps Challenge (&ldquo;Abandoned but
              not Forgotten&rdquo;). Independent educational project using
              publicly available NASA mission records; not an official NASA
              endorsement.
            </p>
          </div>

          <div className="flex flex-wrap gap-6 text-xs font-mono text-[#A6B0C0]">
            <a href="#moon-explorer" className="hover:text-[#F5F7FA] transition-colors">
              Moon
            </a>
            <a href="#mars-explorer" className="hover:text-[#F5F7FA] transition-colors">
              Mars
            </a>
            <a href="#equipment-museum" className="hover:text-[#F5F7FA] transition-colors">
              3D Museum
            </a>
            <a href="#discovery-archive" className="hover:text-[#F5F7FA] transition-colors">
              Archive
            </a>
            <a href="#space-quiz" className="hover:text-[#F5F7FA] transition-colors">
              Quiz
            </a>
            <a
              href="https://science.nasa.gov/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#38DFFF] hover:text-[#8BEAFF] transition-colors"
            >
              NASA Science
            </a>
          </div>
        </div>
      </footer>
    </>
  );
}
