import { useEffect, useState } from 'react';
import { Database, ExternalLink, Loader2, Search } from 'lucide-react';
import { FALLBACK_NASA_MEDIA } from '../data/spaceEquipment';
import type {
  BodyTarget,
  NasaMediaItem,
  TimelineMilestone,
} from '../types/museum';
import { filterTimeline } from '../utils/museumLogic';
import { SafeImage } from './SafeImage';

interface TimelineAndNasaDataSectionProps {
  milestones: TimelineMilestone[];
}

const PRESET_QUERIES = [
  'Apollo 11 Lunar Module',
  'Lunar Roving Vehicle',
  'Mars Perseverance Rover',
  'Opportunity Rover Mars',
];

export function TimelineAndNasaDataSection({
  milestones,
}: TimelineAndNasaDataSectionProps) {
  const [bodyFilter, setBodyFilter] = useState<'All' | BodyTarget>('All');
  const [mediaQuery, setMediaQuery] = useState('Apollo 11 Lunar Module');
  const [mediaItems, setMediaItems] = useState<NasaMediaItem[]>(
    FALLBACK_NASA_MEDIA,
  );
  const [mediaSource, setMediaSource] = useState<string>('verified-local-archive');
  const [loadingMedia, setLoadingMedia] = useState(false);
  const [mediaNotice, setMediaNotice] = useState<string | null>(null);

  const visibleMilestones = filterTimeline(milestones, bodyFilter);

  const fetchNasaMedia = async (q: string) => {
    setLoadingMedia(true);
    setMediaNotice(null);
    try {
      const res = await fetch(`/api/nasa-media?q=${encodeURIComponent(q)}`);
      if (!res.ok) {
        throw new Error('NASA Image Library request failed');
      }
      const data = (await res.json()) as {
        source: string;
        items: NasaMediaItem[];
      };
      setMediaItems(data.items);
      setMediaSource(data.source);
      if (data.source !== 'nasa-images-api') {
        setMediaNotice(
          'Showing verified archival fallback photographs because live NASA Image Library search was unavailable.',
        );
      }
    } catch {
      setMediaItems(FALLBACK_NASA_MEDIA);
      setMediaSource('verified-local-archive');
      setMediaNotice(
        'Showing verified archival fallback photographs (NASA Image Library API unreachable).',
      );
    } finally {
      setLoadingMedia(false);
    }
  };

  useEffect(() => {
    fetchNasaMedia('Apollo 11 Lunar Module');
  }, []);

  return (
    <section
      id="timeline-and-data"
      className="py-20 lg:py-24 border-b border-white/[0.08] bg-[#0B1220]/45"
    >
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 space-y-20">
        <div>
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
            <div>
              <p className="text-xs font-mono tracking-[0.16em] uppercase text-[#38DFFF] mb-2.5">
                06 · Space Discovery Timeline
              </p>
              <h2 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#F5F7FA] tracking-[-0.02em]">
                Chronology of Moon &amp; Mars Milestones
              </h2>
            </div>

            <div
              role="group"
              aria-label="Timeline destination filter"
              className="inline-flex items-center p-1 bg-[#0B1220] border border-white/12 rounded-lg self-start"
            >
              {(['All', 'Moon', 'Mars'] as const).map((target) => (
                <button
                  key={target}
                  type="button"
                  onClick={() => setBodyFilter(target)}
                  className={`px-3.5 py-1.5 text-xs font-mono rounded-md transition-colors cursor-pointer whitespace-nowrap ${
                    bodyFilter === target
                      ? 'bg-[#38DFFF] text-[#080B12] font-semibold'
                      : 'text-[#A6B0C0] hover:text-[#F5F7FA]'
                  }`}
                >
                  {target === 'All' ? 'All Milestones' : `${target}`}
                </button>
              ))}
            </div>
          </div>

          <div className="border-t border-b border-white/[0.08] divide-y divide-white/[0.08]">
            {visibleMilestones.map((m) => (
              <div
                key={m.id}
                className="py-6 grid grid-cols-1 md:grid-cols-12 gap-4 items-start hover:bg-white/[0.02] transition-colors px-2 sm:px-3"
              >
                <div className="md:col-span-2">
                  <div className="text-2xl sm:text-3xl font-mono font-bold tabular-nums text-[#E7C9A1]">
                    {m.year}
                  </div>
                  <div
                    className={`text-xs font-mono mt-1 ${
                      m.destination === 'Mars'
                        ? 'text-[#F07843]'
                        : 'text-[#38DFFF]'
                    }`}
                  >
                    {m.destination}
                  </div>
                </div>

                <div className="md:col-span-7">
                  <h3 className="font-editorial text-base sm:text-lg font-semibold text-[#F5F7FA]">
                    {m.missionName} · {m.equipment}
                  </h3>
                  <p className="mt-1.5 text-sm text-[#A6B0C0] leading-relaxed">
                    {m.achievement}
                  </p>
                </div>

                <div className="md:col-span-3 flex flex-col md:items-end justify-between gap-2">
                  <span
                    className={`text-xs font-mono ${
                      m.status === 'Active Operational'
                        ? 'text-[#38DFFF]'
                        : 'text-[#737F91]'
                    }`}
                  >
                    {m.status}
                  </span>
                  <a
                    href={m.referenceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs text-[#38DFFF] hover:text-[#8BEAFF] underline underline-offset-4"
                  >
                    <span>NASA Source</span>
                    <ExternalLink className="w-3 h-3" aria-hidden="true" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div id="nasa-open-data">
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-8">
            <div>
              <p className="text-xs font-mono tracking-[0.16em] uppercase text-[#38DFFF] mb-2.5">
                07 · NASA Open Data &amp; Image Archive
              </p>
              <h2 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#F5F7FA] tracking-[-0.02em]">
                Live NASA Image Library Explorer
              </h2>
              <p className="mt-3 text-[#A6B0C0] max-w-2xl text-sm sm:text-base leading-relaxed">
                Queries the official NASA Image and Video Library API with
                automatic fallback to verified archival records.
              </p>
            </div>

            <div className="flex flex-wrap gap-3 text-xs font-mono">
              <a
                href="https://images.nasa.gov/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-[#38DFFF] hover:text-[#8BEAFF] underline underline-offset-4"
              >
                <Database className="w-3.5 h-3.5" aria-hidden="true" />
                <span>images.nasa.gov</span>
              </a>
              <a
                href="https://api.nasa.gov/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#38DFFF] hover:text-[#8BEAFF] underline underline-offset-4"
              >
                api.nasa.gov
              </a>
              <a
                href="https://science.nasa.gov/mars/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#38DFFF] hover:text-[#8BEAFF] underline underline-offset-4"
              >
                science.nasa.gov/mars
              </a>
              <a
                href="https://science.nasa.gov/solar-system/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#38DFFF] hover:text-[#8BEAFF] underline underline-offset-4"
              >
                science.nasa.gov/solar-system
              </a>
            </div>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              fetchNasaMedia(mediaQuery);
            }}
            className="flex flex-col sm:flex-row gap-3 mb-4"
          >
            <div className="relative flex-1">
              <label htmlFor="nasa-media-search" className="sr-only">
                Search NASA Image and Video Library
              </label>
              <Search
                className="w-4 h-4 text-[#737F91] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                id="nasa-media-search"
                type="text"
                value={mediaQuery}
                onChange={(e) => setMediaQuery(e.target.value)}
                placeholder="Query NASA Image Library (e.g. Apollo 15, InSight, Spirit)..."
                className="w-full pl-10 pr-4 py-2.5 text-sm bg-[#0B1220] border border-white/15 rounded-lg text-[#F5F7FA] placeholder:text-[#737F91] focus:outline-2 focus:outline-[#38DFFF]"
              />
            </div>
            <button
              type="submit"
              disabled={loadingMedia}
              className="px-5 py-2.5 text-xs sm:text-sm font-mono font-semibold text-[#080B12] bg-[#38DFFF] hover:bg-[#8BEAFF] disabled:opacity-60 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              {loadingMedia ? 'Fetching NASA Archive...' : 'Search NASA Library'}
            </button>
          </form>

          <div className="flex flex-wrap items-center gap-2 mb-6">
            {PRESET_QUERIES.map((preset) => (
              <button
                key={preset}
                type="button"
                onClick={() => {
                  setMediaQuery(preset);
                  fetchNasaMedia(preset);
                }}
                className="px-3 py-1.5 text-xs font-mono text-[#A6B0C0] hover:text-[#F5F7FA] bg-[#0B1220] border border-white/10 hover:border-[#38DFFF]/50 rounded-lg transition-colors cursor-pointer"
              >
                {preset}
              </button>
            ))}
            <span className="ml-auto text-xs font-mono text-[#737F91]">
              Feed:{' '}
              {mediaSource === 'nasa-images-api'
                ? 'Live NASA Images API'
                : 'Verified Archival Fallback'}
            </span>
          </div>

          {mediaNotice && (
            <p className="mb-4 text-xs font-mono text-[#E7C9A1] bg-[#101B2D] border border-[#E7C9A1]/25 rounded-lg px-4 py-2.5">
              {mediaNotice}
            </p>
          )}

          {loadingMedia ? (
            <div className="py-16 flex items-center justify-center gap-3 text-[#A6B0C0]">
              <Loader2 className="w-5 h-5 animate-spin text-[#38DFFF]" aria-hidden="true" />
              <span className="text-sm font-mono">
                Loading NASA archival imagery...
              </span>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {mediaItems.map((item) => (
                <article
                  key={item.nasaId}
                  className="group rounded-xl border border-white/[0.08] hover:border-[#38DFFF]/40 bg-[#0B1220] overflow-hidden flex flex-col justify-between transition-colors"
                >
                  <div>
                    <div className="h-44 overflow-hidden border-b border-white/[0.08]">
                      <SafeImage
                        src={item.imageUrl}
                        alt={item.title}
                        className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.03]"
                      />
                    </div>
                    <div className="p-5">
                      <div className="text-xs font-mono text-[#E7C9A1] tabular-nums">
                        {item.center} · {item.dateCreated} · {item.nasaId}
                      </div>
                      <h3 className="mt-1.5 font-editorial text-base font-semibold text-[#F5F7FA] line-clamp-2">
                        {item.title}
                      </h3>
                      <p className="mt-2 text-xs text-[#A6B0C0] leading-relaxed line-clamp-3">
                        {item.description}
                      </p>
                    </div>
                  </div>
                  <div className="px-5 py-3 border-t border-white/[0.08] bg-[#080B12]/70">
                    <a
                      href={item.nasaUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs text-[#38DFFF] hover:text-[#8BEAFF] underline underline-offset-4"
                    >
                      <span>View on images.nasa.gov</span>
                      <ExternalLink className="w-3 h-3" aria-hidden="true" />
                    </a>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
