export function Footer() {
  return (
    <footer className="border-t border-slate-800/90 bg-[#07090E] py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="font-display text-base font-bold text-white">
            NASA Space Apps 2026
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Global Open Science Hackathon · November 14–16, 2026 · Houston &amp;
            Worldwide Remote
          </p>
        </div>

        <nav
          aria-label="Footer Navigation"
          className="flex flex-wrap items-center gap-6 text-xs font-medium text-slate-400"
        >
          <a href="#featured-brief" className="hover:text-white transition-colors">
            First Brief
          </a>
          <a href="#challenges" className="hover:text-white transition-colors">
            Challenges
          </a>
          <a href="#datasets" className="hover:text-white transition-colors">
            Datasets
          </a>
          <a href="#schedule" className="hover:text-white transition-colors">
            Schedule
          </a>
          <a href="#register" className="hover:text-white transition-colors">
            Team Registration
          </a>
        </nav>
      </div>
    </footer>
  );
}
