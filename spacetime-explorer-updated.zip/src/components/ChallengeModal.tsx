import { useEffect } from 'react';
import { X, Check, Plus } from 'lucide-react';
import { NASA_DATASETS } from '../data/hackathonData';
import { Challenge } from '../types/hackathon';

interface ChallengeModalProps {
  challenge: Challenge | null;
  missionKitIds: string[];
  onToggleDataset: (datasetId: string) => void;
  onSelectForTeam: (challenge: Challenge) => void;
  onClose: () => void;
}

export function ChallengeModal({
  challenge,
  missionKitIds,
  onToggleDataset,
  onSelectForTeam,
  onClose,
}: ChallengeModalProps) {
  useEffect(() => {
    if (!challenge) return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [challenge, onClose]);

  if (!challenge) return null;

  const linkedDatasets = NASA_DATASETS.filter((d) =>
    challenge.datasetIds.includes(d.id)
  );

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="challenge-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl max-h-[88vh] overflow-y-auto bg-[#0B0F17] border border-slate-700 rounded-xl p-6 sm:p-8 text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 pb-5 border-b border-slate-800">
          <div>
            <div className="text-xs font-mono text-slate-400 mb-1.5">
              {challenge.track} <span aria-hidden="true">·</span>{' '}
              {challenge.difficulty} <span aria-hidden="true">·</span>{' '}
              {challenge.center}
            </div>
            <h3
              id="challenge-modal-title"
              className="font-display text-2xl font-bold text-white leading-snug"
            >
              {challenge.index}. {challenge.title}
            </h3>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close challenge brief"
            className="w-10 h-10 inline-flex items-center justify-center rounded-md border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="py-6 space-y-6">
          <div>
            <h4 className="text-xs font-mono text-slate-400 mb-2">
              Problem Statement
            </h4>
            <p className="text-sm sm:text-base text-slate-200 leading-relaxed">
              {challenge.problemStatement}
            </p>
          </div>

          <div>
            <h4 className="text-xs font-mono text-slate-400 mb-2">
              Expected Deliverables
            </h4>
            <ul className="space-y-2 text-sm text-slate-300">
              {challenge.deliverables.map((item) => (
                <li key={item} className="flex items-start gap-2.5">
                  <span className="text-blue-400 font-mono mt-0.5">—</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-mono text-slate-400 mb-2">
              Judging Criteria
            </h4>
            <ul className="space-y-1.5 text-sm text-slate-300">
              {challenge.evaluationCriteria.map((criterion) => (
                <li key={criterion} className="flex items-start gap-2.5">
                  <span className="text-slate-500 font-mono mt-0.5">·</span>
                  <span>{criterion}</span>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-mono text-slate-400 mb-3">
              Recommended NASA Datasets
            </h4>
            <div className="space-y-2">
              {linkedDatasets.map((dataset) => {
                const inKit = missionKitIds.includes(dataset.id);
                return (
                  <div
                    key={dataset.id}
                    className="flex items-center justify-between gap-4 p-3 rounded-lg border border-slate-800 bg-[#07090E]"
                  >
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-white truncate">
                        {dataset.name}
                      </div>
                      <div className="text-xs font-mono text-slate-400">
                        {dataset.sourceCenter} · {dataset.resolution}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => onToggleDataset(dataset.id)}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                        inKit
                          ? 'bg-blue-600/20 text-blue-300 border border-blue-500/40'
                          : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
                      }`}
                    >
                      {inKit ? (
                        <>
                          <Check className="w-3.5 h-3.5" aria-hidden="true" />
                          In Kit
                        </>
                      ) : (
                        <>
                          <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                          Add to Kit
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="pt-5 border-t border-slate-800 flex flex-wrap items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white border border-slate-700 rounded-md"
          >
            Close
          </button>
          <button
            type="button"
            onClick={() => {
              onSelectForTeam(challenge);
              onClose();
            }}
            className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-md transition-colors"
          >
            Select Track for Registration
          </button>
        </div>
      </div>
    </div>
  );
}
