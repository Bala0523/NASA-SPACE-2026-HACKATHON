import type {
  ArtifactFilterCriteria,
  AstraSource,
  BodyTarget,
  QuizQuestion,
  SpaceArtifact,
  TimelineMilestone,
} from '../types/museum';

export function filterArtifacts(
  artifacts: SpaceArtifact[],
  criteria: ArtifactFilterCriteria,
): SpaceArtifact[] {
  const q = criteria.query.trim().toLowerCase();

  return artifacts.filter((item) => {
    if (criteria.body !== 'All' && item.body !== criteria.body) {
      return false;
    }
    if (criteria.category !== 'All' && item.category !== criteria.category) {
      return false;
    }
    if (criteria.status !== 'All' && item.status !== criteria.status) {
      return false;
    }
    if (!q) {
      return true;
    }
    const searchable = [
      item.name,
      item.missionName,
      item.body,
      String(item.missionYear),
      item.category,
      item.siteName,
      item.status,
    ]
      .join(' ')
      .toLowerCase();
    return searchable.includes(q);
  });
}

export function filterTimeline(
  milestones: TimelineMilestone[],
  bodyFilter: 'All' | BodyTarget,
): TimelineMilestone[] {
  const filtered =
    bodyFilter === 'All'
      ? milestones
      : milestones.filter((m) => m.destination === bodyFilter);
  return [...filtered].sort((a, b) => a.year - b.year);
}

export function calculateQuizScore(
  questions: QuizQuestion[],
  selectedAnswers: Record<string, number>,
): { correct: number; total: number; percentage: number } {
  const total = questions.length;
  if (total === 0) {
    return { correct: 0, total: 0, percentage: 0 };
  }
  let correct = 0;
  for (const q of questions) {
    if (selectedAnswers[q.id] === q.correctIndex) {
      correct += 1;
    }
  }
  return {
    correct,
    total,
    percentage: Math.round((correct / total) * 100),
  };
}

export function latLonToCartesian(
  latDeg: number,
  lonDeg: number,
  radius: number,
): { x: number; y: number; z: number } {
  const phi = ((90 - latDeg) * Math.PI) / 180;
  const theta = ((lonDeg + 180) * Math.PI) / 180;

  const x = -radius * Math.sin(phi) * Math.cos(theta);
  const z = radius * Math.sin(phi) * Math.sin(theta);
  const y = radius * Math.cos(phi);

  return { x, y, z };
}

export function getObjectOfTheDay(
  artifacts: SpaceArtifact[],
  date: Date = new Date(),
): SpaceArtifact | null {
  if (artifacts.length === 0) return null;
  const daySeed =
    date.getUTCFullYear() * 366 +
    date.getUTCMonth() * 31 +
    date.getUTCDate();
  return artifacts[daySeed % artifacts.length];
}

export interface KnowledgeMatch {
  answer: string;
  sources: AstraSource[];
}

export function matchAstraKnowledge(rawQuery: string): KnowledgeMatch {
  const q = rawQuery.toLowerCase().trim();

  if (
    q.includes('leave') ||
    q.includes('left behind') ||
    q.includes('abandoned') ||
    q.includes('moon') && q.includes('why')
  ) {
    return {
      answer:
        'NASA left descent stages, Lunar Roving Vehicles, and ALSEP science stations on the Moon primarily because of strict rocket mass budgets: every kilogram lifted off the lunar surface required extra fuel in the Lunar Module Ascent Stage. Descent stages doubled as launch pads for the crew’s return, while ALSEP stations kept transmitting seismic, solar-wind, and laser-ranging data for years after astronauts departed.',
      sources: [
        {
          title: 'NASA Apollo Lunar Surface Journal',
          url: 'https://www.nasa.gov/history/alsj/',
        },
        {
          title: 'NASA Lunar Reconnaissance Orbiter — Apollo Sites',
          url: 'https://science.nasa.gov/moon/',
        },
      ],
    };
  }

  if (q.includes('lunar module') || q.includes('eagle')) {
    return {
      answer:
        'The Apollo Lunar Module had two parts. The gold-wrapped Descent Stage remained on the lunar surface as a launch platform (Eagle’s descent stage still sits at Tranquility Base, imaged by NASA’s Lunar Reconnaissance Orbiter). Once astronauts transferred back to the Command Module in lunar orbit, the Ascent Stage was intentionally jettisoned; most later impacted the Moon for seismic experiments, though Apollo 11’s Eagle ascent stage site remains unconfirmed.',
      sources: [
        {
          title: 'NASA NSSDC — Apollo 11 Lunar Module (Eagle)',
          url: 'https://nssdc.gsfc.nasa.gov/nmc/spacecraft/display.action?id=1969-059C',
        },
      ],
    };
  }

  if (q.includes('spirit')) {
    return {
      answer:
        'NASA’s Spirit rover (MER-A) landed in Gusev Crater in January 2004 on a planned 90-sol mission to search for geological clues about past water on Mars. It operated for over six years (2,208 sols), climbing Husband Hill and uncovering silica-rich soils that pointed to ancient hydrothermal hot springs before becoming trapped in soft sand at Troy and ending communications in March 2010.',
      sources: [
        {
          title: 'NASA Science — Spirit Rover',
          url: 'https://science.nasa.gov/mission/mer-spirit/',
        },
      ],
    };
  }

  if (q.includes('opportunity')) {
    return {
      answer:
        'Opportunity (MER-B) landed at Meridiani Planum in 2004 and drove an off-world record of 45.16 kilometers over nearly 15 years. It discovered tiny iron-rich spheres nicknamed "blueberries" (hematite) and clay-bearing rocks in Endeavour Crater, proving that liquid water once flowed across and soaked ancient Martian rock. A planet-encircling dust storm in 2018 blocked its solar panels, and NASA concluded the mission in February 2019.',
      sources: [
        {
          title: 'NASA Science — Opportunity Rover',
          url: 'https://science.nasa.gov/mission/mer-opportunity/',
        },
      ],
    };
  }

  if (
    q.includes('still operational') ||
    q.includes('active') ||
    q.includes('working') ||
    q.includes('functioning')
  ) {
    return {
      answer:
        'On Mars, two NASA surface rovers remain active and operational: Curiosity (landed 2012 in Gale Crater) and Perseverance (landed 2021 in Jezero Crater). Both run on plutonium-238 radioisotope thermoelectric generators (MMRTGs), allowing them to operate regardless of Martian dust storms. By contrast, Sojourner, Spirit, Opportunity, InSight, and Ingenuity have completed their missions and are no longer operating. On the Moon, passive Apollo Lunar Laser Ranging Retroreflectors continue to reflect Earth-based laser pulses.',
      sources: [
        {
          title: 'NASA Mars Exploration Program',
          url: 'https://science.nasa.gov/mars/',
        },
      ],
    };
  }

  if (q.includes('lander') && q.includes('rover')) {
    return {
      answer:
        'A lander (such as Surveyor 3 or Mars InSight) touches down at one fixed spot and conducts stationary science—like measuring marsquakes, heat flow, or weather—using robotic arms or deployed instruments. A rover (such as Sojourner, Spirit, Opportunity, Curiosity, Perseverance, or the Apollo Lunar Roving Vehicle) has wheels and mobility systems to drive across kilometers of terrain and examine diverse rocks and craters.',
      sources: [
        {
          title: 'NASA Solar System Exploration',
          url: 'https://science.nasa.gov/solar-system/',
        },
      ],
    };
  }

  if (q.includes('curiosity') || q.includes('perseverance') || q.includes('insight')) {
    return {
      answer:
        'Curiosity (2012, Gale Crater) and Perseverance (2021, Jezero Crater) are active nuclear-powered laboratories studying Mars’s past habitability and caching rock samples. InSight (2018–2022, Elysium Planitia) was a stationary geophysical lander that recorded over 1,300 marsquakes with its SEIS seismometer before dust accumulation ended solar power generation in December 2022.',
      sources: [
        {
          title: 'NASA Mars Science Missions',
          url: 'https://science.nasa.gov/mars/',
        },
      ],
    };
  }

  return {
    answer:
      'I can help explain NASA’s verified Moon and Mars hardware—including why Apollo descent stages and ALSEP instruments remain on the Moon, how Spirit and Opportunity explored Mars, which rovers (Curiosity and Perseverance) are still active today, and how landers differ from rovers. Try asking about a specific mission like Apollo 11, Apollo 15 LRV, Surveyor 3, Sojourner, Spirit, Opportunity, InSight, Curiosity, or Perseverance.',
    sources: [
      {
        title: 'NASA Solar System Exploration',
        url: 'https://science.nasa.gov/solar-system/',
      },
      {
        title: 'NASA Image and Video Library',
        url: 'https://images.nasa.gov/',
      },
    ],
  };
}

export function getPlanetaryGroundHeight(
  x: number,
  z: number,
  body: BodyTarget,
): number {
  const distFromCenter = Math.hypot(x, z);
  // Keep landing pad radius within 2.5m almost level so hardware sits flush without clipping
  const padFlatten = Math.min(1, Math.max(0, (distFromCenter - 2.3) / 4.5));

  if (body === 'Mars') {
    const dunes =
      Math.sin(x * 0.2 + z * 0.14) * 0.34 +
      Math.cos(x * 0.11 - z * 0.24) * 0.28;
    // Dramatic Martian canyon wall / mountain silhouette in the far background
    const ridgeFactor = Math.max(0, (distFromCenter - 17) / 14);
    const mountains =
      ridgeFactor *
      ridgeFactor *
      (1.85 +
        Math.sin(x * 0.28) * 1.05 +
        Math.cos(z * 0.24 + x * 0.16) * 0.9);
    const backWall =
      z < -15
        ? Math.pow((-15 - z) / 12, 1.35) *
          (1.9 + Math.sin(x * 0.22 + 1.1) * 1.0)
        : 0;
    return dunes * padFlatten + mountains + backWall;
  }

  // Moon: gentle regolith undulations + crater basins and rim walls
  const regolith =
    Math.sin(x * 0.18 + z * 0.19) * 0.18 +
    Math.cos(x * 0.31 - z * 0.12) * 0.14;

  // Deterministic off-center crater bowls
  const craters = [
    { cx: -7.5, cz: -8.5, r: 3.4, depth: 0.85 },
    { cx: 8.5, cz: -7.0, r: 4.1, depth: 1.0 },
    { cx: -11.0, cz: 5.5, r: 4.5, depth: 1.05 },
    { cx: 9.5, cz: 8.0, r: 3.1, depth: 0.75 },
  ];
  let craterOffset = 0;
  for (const c of craters) {
    const d = Math.hypot(x - c.cx, z - c.cz);
    if (d < c.r * 1.35) {
      const t = d / c.r;
      if (t < 0.82) {
        craterOffset -= c.depth * (1 - (t / 0.82) * (t / 0.82));
      } else {
        const rimT = (t - 0.82) / 0.53;
        craterOffset += c.depth * 0.26 * Math.sin(rimT * Math.PI);
      }
    }
  }

  const highlands =
    distFromCenter > 18
      ? Math.pow((distFromCenter - 18) / 14, 1.5) *
        (1.4 + Math.sin(x * 0.22 - z * 0.2) * 0.7)
      : 0;

  return (regolith + craterOffset) * padFlatten + highlands;
}

export interface IntroSceneState {
  sceneIndex: 1 | 2 | 3 | 4 | 5;
  phaseLabel: string;
  headlineLine1: string;
  headlineLine2: string;
  showStoryText: boolean;
  showRoverTelemetry: boolean;
  showEnterCta: boolean;
  cameraProgress: number;
}

export function getIntroSceneState(elapsedSec: number): IntroSceneState {
  const t = Math.max(0, elapsedSec);

  if (t < 2.8) {
    return {
      sceneIndex: 1,
      phaseLabel: 'SCENE 01 · SOL 001 MARS ESTABLISHING HORIZON',
      headlineLine1: '',
      headlineLine2: '',
      showStoryText: false,
      showRoverTelemetry: false,
      showEnterCta: false,
      cameraProgress: t / 12.0,
    };
  }
  if (t < 6.0) {
    return {
      sceneIndex: 2,
      phaseLabel: 'SCENE 02 · ARCHIVAL REMEMBRANCE',
      headlineLine1: 'NOT ALL EXPLORERS CAME HOME.',
      headlineLine2: t >= 4.0 ? 'BUT NONE OF THEM EVER LEFT.' : '',
      showStoryText: true,
      showRoverTelemetry: false,
      showEnterCta: false,
      cameraProgress: t / 12.0,
    };
  }
  if (t < 8.8) {
    return {
      sceneIndex: 3,
      phaseLabel: 'SCENE 03 · ROVER HARDWARE INSPECTION',
      headlineLine1: '',
      headlineLine2: '',
      showStoryText: false,
      showRoverTelemetry: false,
      showEnterCta: false,
      cameraProgress: t / 12.0,
    };
  }
  if (t < 11.6) {
    return {
      sceneIndex: 4,
      phaseLabel: 'SCENE 04 · HOLOGRAPHIC TELEMETRY LOCK',
      headlineLine1: '',
      headlineLine2: '',
      showStoryText: false,
      showRoverTelemetry: true,
      showEnterCta: false,
      cameraProgress: t / 12.0,
    };
  }

  return {
    sceneIndex: 5,
    phaseLabel: 'SCENE 05 · SPACETIME EXPLORER READY',
    headlineLine1: 'SPACETIME EXPLORER',
    headlineLine2: 'Every abandoned object has a story. Every story reveals a discovery.',
    showStoryText: false,
    showRoverTelemetry: true,
    showEnterCta: true,
    cameraProgress: 1,
  };
}

export function shouldBypassIntro(search: string): boolean {
  if (!search) return false;
  const params = new URLSearchParams(search);
  return params.get('autostart') === '1' || params.get('skipintro') === '1';
}

