import test from 'node:test';
import assert from 'node:assert/strict';
import { CHALLENGES, INITIAL_TEAMS } from '../data/hackathonData';
import {
  calculateCountdown,
  filterChallenges,
  filterTeams,
  formatSessionTime,
  toggleMissionKitItem,
  validateRegistration,
} from './hackathonLogic';

test('calculateCountdown returns exact days, hours, minutes, seconds before target', () => {
  const target = '2026-11-16T15:00:00Z';
  const now = Date.parse('2026-11-14T12:30:15Z');
  const result = calculateCountdown(target, now);

  assert.equal(result.expired, false);
  assert.equal(result.days, 2);
  assert.equal(result.hours, 2);
  assert.equal(result.minutes, 29);
  assert.equal(result.seconds, 45);
});

test('calculateCountdown returns expired=true when target has passed', () => {
  const target = '2026-11-16T15:00:00Z';
  const now = Date.parse('2026-11-16T15:00:01Z');
  const result = calculateCountdown(target, now);

  assert.equal(result.expired, true);
  assert.equal(result.days, 0);
  assert.equal(result.seconds, 0);
});

test('filterChallenges filters by track, difficulty, and keyword query', () => {
  const planets = filterChallenges(CHALLENGES, 'Planets & Moons', 'All', '');
  assert.equal(planets.length, 2);
  assert.equal(planets[0].id, 'abandoned-not-forgotten');

  const abandonedOnly = filterChallenges(
    CHALLENGES,
    'Planets & Moons',
    'Beginner',
    'discarded'
  );
  assert.equal(abandonedOnly.length, 1);
  assert.equal(abandonedOnly[0].id, 'abandoned-not-forgotten');

  const empty = filterChallenges(CHALLENGES, 'All', 'All', 'nonexistent-xyz');
  assert.equal(empty.length, 0);
});

test('filterTeams filters by track, open seats, and search query', () => {
  const seekingAstrophysics = filterTeams(
    INITIAL_TEAMS,
    'Astrophysics',
    true,
    'NIRSpec',
    CHALLENGES
  );
  assert.equal(seekingAstrophysics.length, 1);
  assert.equal(seekingAstrophysics[0].id, 'team-transit-lab');

  const fullTeamsExcluded = filterTeams(
    [
      ...INITIAL_TEAMS,
      {
        ...INITIAL_TEAMS[0],
        id: 'full-team',
        currentMembers: 5,
        maxMembers: 5,
      },
    ],
    'All',
    true,
    '',
    CHALLENGES
  );
  assert.equal(fullTeamsExcluded.some((t) => t.id === 'full-team'), false);
});

test('validateRegistration rejects invalid email, short name, and short pitch', () => {
  const bad = validateRegistration({
    name: 'AB',
    leadEmail: 'not-an-email',
    mode: 'Global Remote',
    challengeId: '',
    datasetIds: [],
    rolesNeeded: [],
    maxMembers: 7,
    pitch: 'Too short',
  });

  assert.equal(bad.valid, false);
  assert.ok(bad.errors.name);
  assert.ok(bad.errors.leadEmail);
  assert.ok(bad.errors.challengeId);
  assert.ok(bad.errors.maxMembers);
  assert.ok(bad.errors.pitch);
});

test('validateRegistration accepts valid team registration input', () => {
  const good = validateRegistration({
    name: 'Lunar Heritage Studio',
    leadEmail: 'maya.lin@spaceapps.org',
    mode: 'In-Person · Houston',
    challengeId: 'abandoned-not-forgotten',
    datasetIds: ['mro-hirise-sites'],
    rolesNeeded: ['3D WebGL', 'Storytelling / UX'],
    maxMembers: 4,
    pitch: 'Interactive 3D lunar & Martian rover storytelling museum for middle school classrooms.',
  });

  assert.equal(good.valid, true);
  assert.deepEqual(good.errors, {});
});

test('formatSessionTime formats UTC correctly', () => {
  assert.equal(formatSessionTime('2026-11-14T14:05:00Z', 'UTC'), '14:05 UTC');
});

test('toggleMissionKitItem adds and removes dataset IDs cleanly', () => {
  const added = toggleMissionKitItem(['lro-lunar-dem'], 'mro-hirise-sites');
  assert.deepEqual(added, ['lro-lunar-dem', 'mro-hirise-sites']);

  const removed = toggleMissionKitItem(added, 'lro-lunar-dem');
  assert.deepEqual(removed, ['mro-hirise-sites']);
});
