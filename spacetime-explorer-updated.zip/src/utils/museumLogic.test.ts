import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateQuizScore,
  filterArtifacts,
  filterTimeline,
  getIntroSceneState,
  getObjectOfTheDay,
  getPlanetaryGroundHeight,
  latLonToCartesian,
  matchAstraKnowledge,
  shouldBypassIntro,
} from './museumLogic';
import { SPACE_ARTIFACTS } from '../data/spaceEquipment';
import { buildSpacecraftModel } from '../components/three/threeUtils';
import type { QuizQuestion, SpaceArtifact, TimelineMilestone } from '../types/museum';

const sampleArtifacts: SpaceArtifact[] = [
  {
    id: 'apollo-11-descent',
    name: 'Apollo 11 Lunar Module Eagle Descent Stage',
    missionName: 'Apollo 11',
    missionYear: 1969,
    body: 'Moon',
    category: 'Ascent & Descent Stage',
    status: 'Intentionally Left Behind',
    statusNote: 'Remains at Tranquility Base',
    siteName: 'Mare Tranquillitatis',
    coordinates: { lat: 0.674, lon: 23.473, label: '0.67° N, 23.47° E' },
    launchDate: '1969-07-16',
    landingDate: '1969-07-20',
    endDate: '1969-07-21',
    massKg: 2134,
    powerSource: 'Silver-zinc batteries',
    imageUrl: '/test.jpg',
    imageAttribution: 'NASA',
    model3DType: 'lunar-module',
    purposeStudent: 'Launch pad on Moon',
    purposeScientific: 'Descent propulsion stage',
    scientificContribution: 'Supported first human landing',
    whyLeftBehind: 'Used as launch platform',
    thenVsNow: {
      thenCaption: '1969 surface photo',
      nowCaption: 'LRO orbital photo',
      orbitalVerification: 'Verified by LRO',
    },
    storyStages: [],
    components: [],
    references: [],
  },
  {
    id: 'perseverance',
    name: 'Perseverance Rover',
    missionName: 'Mars 2020',
    missionYear: 2021,
    body: 'Mars',
    category: 'Rover',
    status: 'Active Operational',
    statusNote: 'Actively operating in Jezero Crater',
    siteName: 'Jezero Crater',
    coordinates: { lat: 18.38, lon: 77.58, label: '18.38° N, 77.58° E' },
    launchDate: '2020-07-30',
    landingDate: '2021-02-18',
    endDate: 'Active',
    massKg: 1025,
    powerSource: 'MMRTG',
    imageUrl: '/test2.jpg',
    imageAttribution: 'NASA/JPL-Caltech',
    model3DType: 'msl-rover',
    purposeStudent: 'Search for ancient life signs',
    purposeScientific: 'Astrobiology & sample caching',
    scientificContribution: 'Cached Jezero delta cores',
    whyLeftBehind: 'Active mission on Mars',
    thenVsNow: {
      thenCaption: '2021 landing',
      nowCaption: 'Active traverse',
      orbitalVerification: 'Tracked by MRO HiRISE',
    },
    storyStages: [],
    components: [],
    references: [],
  },
];

test('filterArtifacts filters by body, category, status, and search query', () => {
  const marsOnly = filterArtifacts(sampleArtifacts, {
    query: '',
    body: 'Mars',
    category: 'All',
    status: 'All',
  });
  assert.equal(marsOnly.length, 1);
  assert.equal(marsOnly[0].id, 'perseverance');

  const queryMatch = filterArtifacts(sampleArtifacts, {
    query: '1969',
    body: 'All',
    category: 'All',
    status: 'All',
  });
  assert.equal(queryMatch.length, 1);
  assert.equal(queryMatch[0].id, 'apollo-11-descent');

  const noMatch = filterArtifacts(sampleArtifacts, {
    query: 'Voyager',
    body: 'All',
    category: 'All',
    status: 'All',
  });
  assert.equal(noMatch.length, 0);
});

test('filterTimeline filters by destination and sorts ascending by year', () => {
  const milestones: TimelineMilestone[] = [
    {
      id: 'm2',
      year: 2021,
      missionName: 'Mars 2020',
      destination: 'Mars',
      achievement: 'Perseverance landing',
      equipment: 'Perseverance',
      status: 'Active Operational',
      referenceUrl: 'https://science.nasa.gov/mars/',
    },
    {
      id: 'm1',
      year: 1969,
      missionName: 'Apollo 11',
      destination: 'Moon',
      achievement: 'First crewed lunar landing',
      equipment: 'Eagle LM',
      status: 'Intentionally Left Behind',
      referenceUrl: 'https://science.nasa.gov/moon/',
    },
  ];
  const sortedAll = filterTimeline(milestones, 'All');
  assert.deepEqual(
    sortedAll.map((m) => m.year),
    [1969, 2021],
  );
  const moonOnly = filterTimeline(milestones, 'Moon');
  assert.equal(moonOnly.length, 1);
  assert.equal(moonOnly[0].missionName, 'Apollo 11');
});

test('calculateQuizScore computes exact counts and percentage', () => {
  const questions: QuizQuestion[] = [
    {
      id: 'q1',
      question: 'Q1',
      options: ['A', 'B'],
      correctIndex: 0,
      explanation: 'Exp 1',
      sourceLabel: 'NASA',
      sourceUrl: 'https://nasa.gov',
    },
    {
      id: 'q2',
      question: 'Q2',
      options: ['A', 'B'],
      correctIndex: 1,
      explanation: 'Exp 2',
      sourceLabel: 'NASA',
      sourceUrl: 'https://nasa.gov',
    },
  ];
  const score = calculateQuizScore(questions, { q1: 0, q2: 0 });
  assert.deepEqual(score, { correct: 1, total: 2, percentage: 50 });
});

test('latLonToCartesian places points on sphere radius', () => {
  const p = latLonToCartesian(0, 0, 2);
  const magnitude = Math.sqrt(p.x * p.x + p.y * p.y + p.z * p.z);
  assert.ok(Math.abs(magnitude - 2) < 1e-6);
});

test('getObjectOfTheDay returns deterministic artifact for given date', () => {
  const date = new Date('2026-11-14T12:00:00Z');
  const first = getObjectOfTheDay(sampleArtifacts, date);
  const second = getObjectOfTheDay(sampleArtifacts, date);
  assert.ok(first !== null);
  assert.equal(first?.id, second?.id);
});

test('matchAstraKnowledge distinguishes active vs completed missions accurately', () => {
  const activeReply = matchAstraKnowledge('Which equipment is still operational?');
  assert.ok(activeReply.answer.includes('Curiosity'));
  assert.ok(activeReply.answer.includes('Perseverance'));
  assert.ok(activeReply.sources.length >= 1);
});

test('every artifact subsystem component maps to a 3D mesh in buildSpacecraftModel', () => {
  for (const artifact of SPACE_ARTIFACTS) {
    const { partMeshes } = buildSpacecraftModel(artifact.model3DType);
    for (const comp of artifact.components) {
      const meshes = partMeshes.get(comp.id);
      assert.ok(
        meshes && meshes.length > 0,
        `Expected 3D meshes for ${artifact.id} -> ${comp.id} (${artifact.model3DType})`,
      );
    }
  }
});

test('getPlanetaryGroundHeight keeps center landing pad level and sculpts distant terrain', () => {
  assert.equal(getPlanetaryGroundHeight(0, 0, 'Mars'), 0);
  assert.equal(getPlanetaryGroundHeight(0, 0, 'Moon'), 0);
  assert.ok(getPlanetaryGroundHeight(-10, -28, 'Mars') > 1.5);
  assert.ok(getPlanetaryGroundHeight(-7.5, -8.5, 'Moon') < -0.2);
});

test('getIntroSceneState transitions cleanly across all 5 cinematic scenes', () => {
  const s1 = getIntroSceneState(1.0);
  assert.equal(s1.sceneIndex, 1);
  assert.equal(s1.showStoryText, false);

  const s2 = getIntroSceneState(4.2);
  assert.equal(s2.sceneIndex, 2);
  assert.equal(s2.showStoryText, true);
  assert.equal(s2.headlineLine1, 'NOT ALL EXPLORERS CAME HOME.');
  assert.equal(s2.headlineLine2, 'BUT NONE OF THEM EVER LEFT.');

  const s3 = getIntroSceneState(6.5);
  assert.equal(s3.sceneIndex, 3);

  const s4 = getIntroSceneState(9.0);
  assert.equal(s4.sceneIndex, 4);
  assert.equal(s4.showRoverTelemetry, true);

  const s5 = getIntroSceneState(12.0);
  assert.equal(s5.sceneIndex, 5);
  assert.equal(s5.showEnterCta, true);
  assert.equal(s5.cameraProgress, 1);
});

test('shouldBypassIntro detects autostart and skipintro query flags', () => {
  assert.equal(shouldBypassIntro('?autostart=1'), true);
  assert.equal(shouldBypassIntro('?skipintro=1'), true);
  assert.equal(shouldBypassIntro(''), false);
  assert.equal(shouldBypassIntro('?mode=demo'), false);
});

