import {
  Challenge,
  CountdownParts,
  DifficultyLevel,
  HackathonTeam,
  RegistrationInput,
  TrackId,
  ValidationResult,
} from '../types/hackathon';

export const HACKATHON_SPRINT_END_UTC = '2026-11-16T15:00:00Z';

export function calculateCountdown(targetIso: string, nowMs: number): CountdownParts {
  const targetMs = Date.parse(targetIso);
  if (Number.isNaN(targetMs)) {
    return { days: 0, hours: 0, minutes: 0, seconds: 0, expired: true };
  }
  const diffMs = targetMs - nowMs;
  if (diffMs <= 0) {
    return { days: 0, hours: 0, minutes: 0, seconds: 0, expired: true };
  }

  const totalSeconds = Math.floor(diffMs / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  return { days, hours, minutes, seconds, expired: false };
}

export function filterChallenges(
  challenges: Challenge[],
  trackFilter: TrackId | 'All',
  difficultyFilter: DifficultyLevel | 'All',
  query: string
): Challenge[] {
  const normalizedQuery = query.trim().toLowerCase();

  return challenges.filter((challenge) => {
    if (trackFilter !== 'All' && challenge.track !== trackFilter) {
      return false;
    }
    if (difficultyFilter !== 'All' && challenge.difficulty !== difficultyFilter) {
      return false;
    }
    if (normalizedQuery.length > 0) {
      const haystack = [
        challenge.title,
        challenge.summary,
        challenge.center,
        challenge.track,
        challenge.problemStatement,
      ]
        .join(' ')
        .toLowerCase();
      return haystack.includes(normalizedQuery);
    }
    return true;
  });
}

export function filterTeams(
  teams: HackathonTeam[],
  trackFilter: TrackId | 'All',
  seekingOnly: boolean,
  query: string,
  challenges: Challenge[]
): HackathonTeam[] {
  const normalizedQuery = query.trim().toLowerCase();
  const challengeTrackMap = new Map<string, TrackId>(
    challenges.map((c) => [c.id, c.track])
  );

  return teams.filter((team) => {
    const teamTrack = challengeTrackMap.get(team.challengeId);
    if (trackFilter !== 'All' && teamTrack !== trackFilter) {
      return false;
    }
    if (seekingOnly && team.currentMembers >= team.maxMembers) {
      return false;
    }
    if (normalizedQuery.length > 0) {
      const haystack = [
        team.name,
        team.pitch,
        team.mode,
        ...team.rolesNeeded,
      ]
        .join(' ')
        .toLowerCase();
      return haystack.includes(normalizedQuery);
    }
    return true;
  });
}

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function validateRegistration(input: RegistrationInput): ValidationResult {
  const errors: ValidationResult['errors'] = {};

  const trimmedName = input.name.trim();
  if (trimmedName.length < 3) {
    errors.name = 'Team name must be at least 3 characters.';
  } else if (trimmedName.length > 48) {
    errors.name = 'Team name must be 48 characters or fewer.';
  }

  const trimmedEmail = input.leadEmail.trim();
  if (!EMAIL_PATTERN.test(trimmedEmail)) {
    errors.leadEmail = 'Enter a valid team lead email address.';
  }

  if (!input.challengeId) {
    errors.challengeId = 'Select a primary hackathon challenge.';
  }

  if (!Number.isInteger(input.maxMembers) || input.maxMembers < 1 || input.maxMembers > 6) {
    errors.maxMembers = 'Team capacity must be between 1 and 6 members.';
  }

  if (input.pitch.trim().length < 15) {
    errors.pitch = 'Provide a short mission pitch (at least 15 characters).';
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}

export function formatSessionTime(
  utcIso: string,
  timezoneMode: 'UTC' | 'LOCAL'
): string {
  const date = new Date(utcIso);
  if (Number.isNaN(date.getTime())) {
    return '--:--';
  }

  if (timezoneMode === 'UTC') {
    const hh = String(date.getUTCHours()).padStart(2, '0');
    const mm = String(date.getUTCMinutes()).padStart(2, '0');
    return `${hh}:${mm} UTC`;
  }

  const hh = String(date.getHours()).padStart(2, '0');
  const mm = String(date.getMinutes()).padStart(2, '0');
  return `${hh}:${mm} Local`;
}

export function toggleMissionKitItem(kitIds: string[], datasetId: string): string[] {
  if (kitIds.includes(datasetId)) {
    return kitIds.filter((id) => id !== datasetId);
  }
  return [...kitIds, datasetId];
}
