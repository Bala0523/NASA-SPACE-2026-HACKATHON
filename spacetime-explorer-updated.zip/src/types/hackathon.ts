export type TrackId =
  | 'Planets & Moons'
  | 'Earth Observation'
  | 'Astrophysics'
  | 'Heliophysics';

export type DifficultyLevel = 'Beginner' | 'Intermediate' | 'Advanced';

export type CameraPreset = 'overview' | 'hardware' | 'surface';

export interface ArtifactSpotlight {
  id: string;
  name: string;
  body: 'Moon' | 'Mars';
  landingSite: string;
  coordinates: string;
  activeYears: string;
  massKg: number;
  scientificLegacy: string;
  storyAngle: string;
}

export interface Challenge {
  id: string;
  index: string;
  title: string;
  track: TrackId;
  difficulty: DifficultyLevel;
  center: string;
  summary: string;
  problemStatement: string;
  deliverables: string[];
  evaluationCriteria: string[];
  datasetIds: string[];
  imageUrl?: string;
  imageAlt?: string;
  featured?: boolean;
}

export interface NasaDataset {
  id: string;
  name: string;
  sourceCenter: string;
  category: TrackId;
  format: string;
  resolution: string;
  cadence: string;
  endpoint: string;
  description: string;
  samplePayload: Record<string, unknown>;
}

export interface ScheduleSession {
  id: string;
  day: 1 | 2 | 3;
  utcIso: string;
  durationMins: number;
  title: string;
  speaker: string;
  sessionType: 'Keynote' | 'Workshop' | 'Mentorship' | 'Milestone';
  description: string;
}

export interface HackathonTeam {
  id: string;
  name: string;
  leadEmail: string;
  mode: 'In-Person · Houston' | 'Global Remote';
  challengeId: string;
  datasetIds: string[];
  rolesNeeded: string[];
  currentMembers: number;
  maxMembers: number;
  pitch: string;
  joinedByUser?: boolean;
}

export interface RegistrationInput {
  name: string;
  leadEmail: string;
  mode: 'In-Person · Houston' | 'Global Remote';
  challengeId: string;
  datasetIds: string[];
  rolesNeeded: string[];
  maxMembers: number;
  pitch: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: Partial<Record<keyof RegistrationInput, string>>;
}

export interface CountdownParts {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  expired: boolean;
}
