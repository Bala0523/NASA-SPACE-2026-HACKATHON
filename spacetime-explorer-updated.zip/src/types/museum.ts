export type BodyTarget = 'Moon' | 'Mars';

export type EquipmentCategory =
  | 'Lander'
  | 'Rover'
  | 'Scientific Instrument'
  | 'Ascent & Descent Stage';

export type OperationalStatus =
  | 'Active Operational'
  | 'Mission Completed'
  | 'Intentionally Left Behind'
  | 'Intentionally Discarded'
  | 'Non-Operational';

export type LearningMode = 'student' | 'scientific';

export type Model3DType =
  | 'lunar-module'
  | 'lunar-rover'
  | 'mer-rover'
  | 'msl-rover'
  | 'insight-lander';

export interface StoryStage {
  stageNumber: 1 | 2 | 3 | 4 | 5;
  title: string;
  subtitle: string;
  studentText: string;
  scientificText: string;
}

export interface EquipmentComponent {
  id: string;
  name: string;
  role: string;
  studentExplanation: string;
  scientificExplanation: string;
}

export interface NasaReference {
  label: string;
  url: string;
}

export interface SpaceArtifact {
  id: string;
  name: string;
  missionName: string;
  missionYear: number;
  body: BodyTarget;
  category: EquipmentCategory;
  status: OperationalStatus;
  statusNote: string;
  siteName: string;
  coordinates: {
    lat: number;
    lon: number;
    label: string;
  };
  launchDate: string;
  landingDate: string;
  endDate: string;
  massKg: number;
  powerSource: string;
  distanceTraveledKm?: number;
  imageUrl: string;
  imageAttribution: string;
  model3DType: Model3DType;
  purposeStudent: string;
  purposeScientific: string;
  scientificContribution: string;
  whyLeftBehind: string;
  thenVsNow: {
    thenCaption: string;
    nowCaption: string;
    orbitalVerification: string;
  };
  storyStages: StoryStage[];
  components: EquipmentComponent[];
  references: NasaReference[];
}

export interface TimelineMilestone {
  id: string;
  year: number;
  missionName: string;
  destination: BodyTarget;
  achievement: string;
  equipment: string;
  status: OperationalStatus;
  referenceUrl: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  sourceLabel: string;
  sourceUrl: string;
}

export interface ArtifactFilterCriteria {
  query: string;
  body: 'All' | BodyTarget;
  category: 'All' | EquipmentCategory;
  status: 'All' | OperationalStatus;
}

export interface AstraSource {
  title: string;
  url: string;
}

export interface AstraMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  sources?: AstraSource[];
  mode?: 'gemini-live' | 'verified-knowledge-base';
}

export interface NasaMediaItem {
  nasaId: string;
  title: string;
  description: string;
  dateCreated: string;
  center: string;
  imageUrl: string;
  nasaUrl: string;
}
