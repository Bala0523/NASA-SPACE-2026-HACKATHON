/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useMemo, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { AboutAndFooter } from './components/AboutAndFooter';
import { AstraAssistantPanel } from './components/AstraAssistantPanel';
import { CinematicIntro3D } from './components/CinematicIntro3D';
import { DiscoveryAndComparisonSection } from './components/DiscoveryAndComparisonSection';
import { HeroSection } from './components/HeroSection';
import { Navbar } from './components/Navbar';
import { PlanetaryExplorerSection } from './components/PlanetaryExplorerSection';
import { QuizSection } from './components/QuizSection';
import { StorytellingSection } from './components/StorytellingSection';
import { TimelineAndNasaDataSection } from './components/TimelineAndNasaDataSection';
import { EquipmentMuseum3D } from './components/three/EquipmentMuseum3D';
import {
  QUIZ_QUESTIONS,
  SPACE_ARTIFACTS,
  TIMELINE_MILESTONES,
} from './data/spaceEquipment';
import type { LearningMode, SpaceArtifact } from './types/museum';
import { shouldBypassIntro } from './utils/museumLogic';

gsap.registerPlugin(ScrollTrigger);

const DOCUMENTARY_CHAPTERS = [
  { id: 'top', num: '00', label: 'Surface Arrival' },
  { id: 'moon-explorer', num: '01', label: 'Moon Relics' },
  { id: 'mars-explorer', num: '02', label: 'Mars Pioneers' },
  { id: 'equipment-museum', num: '03', label: '3D Museum' },
  { id: 'mission-storytelling', num: '04', label: 'Mission Stories' },
  { id: 'discovery-archive', num: '05', label: 'Archive' },
  { id: 'timeline-and-data', num: '06', label: 'NASA Open Data' },
  { id: 'space-quiz', num: '07', label: 'Knowledge Quiz' },
  { id: 'astra-guide', num: '08', label: 'ASTRA AI' },
];

export default function App() {
  const moonArtifacts = useMemo(
    () => SPACE_ARTIFACTS.filter((a) => a.body === 'Moon'),
    [],
  );
  const marsArtifacts = useMemo(
    () => SPACE_ARTIFACTS.filter((a) => a.body === 'Mars'),
    [],
  );

  const [showIntro, setShowIntro] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return !shouldBypassIntro(window.location.search);
  });

  const [activeChapter, setActiveChapter] = useState<string>('top');
  const [learningMode, setLearningMode] = useState<LearningMode>('student');
  const [selectedMoonId, setSelectedMoonId] = useState<string>(
    moonArtifacts[0]?.id ?? 'apollo-11-eagle-descent',
  );
  const [selectedMarsId, setSelectedMarsId] = useState<string>(
    marsArtifacts[2]?.id ?? marsArtifacts[0]?.id ?? 'opportunity-mer-b',
  );
  const [selectedMuseumId, setSelectedMuseumId] = useState<string>(
    SPACE_ARTIFACTS[0]?.id ?? 'apollo-11-eagle-descent',
  );
  const [selectedStoryId, setSelectedStoryId] = useState<string>(
    SPACE_ARTIFACTS[0]?.id ?? 'apollo-11-eagle-descent',
  );
  const [astraDrawerOpen, setAstraDrawerOpen] = useState(false);

  const mainRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (showIntro || !mainRef.current) return;

    const ctx = gsap.context(() => {
      DOCUMENTARY_CHAPTERS.forEach((chapter) => {
        const el = document.getElementById(chapter.id);
        if (!el) return;
        ScrollTrigger.create({
          trigger: el,
          start: 'top 52%',
          end: 'bottom 48%',
          onEnter: () => setActiveChapter(chapter.id),
          onEnterBack: () => setActiveChapter(chapter.id),
        });
      });

      const reduced = window.matchMedia(
        '(prefers-reduced-motion: reduce)',
      ).matches;
      if (!reduced) {
        gsap.utils.toArray<HTMLElement>('.cinematic-chapter-reveal').forEach((node) => {
          gsap.fromTo(
            node,
            { y: 18, opacity: 0.92 },
            {
              y: 0,
              opacity: 1,
              duration: 0.55,
              ease: 'power2.out',
              clearProps: 'transform,opacity',
              scrollTrigger: {
                trigger: node,
                start: 'top 86%',
                once: true,
              },
            },
          );
        });
      }
    }, mainRef);

    return () => ctx.revert();
  }, [showIntro]);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleJumpToStory = (id: string) => {
    setSelectedStoryId(id);
    scrollToSection('mission-storytelling');
  };

  const handleJumpToMuseum = (id: string) => {
    setSelectedMuseumId(id);
    scrollToSection('equipment-museum');
  };

  const handleInspectArtifact = (artifact: SpaceArtifact) => {
    if (artifact.body === 'Moon') {
      setSelectedMoonId(artifact.id);
      scrollToSection('moon-explorer');
    } else {
      setSelectedMarsId(artifact.id);
      scrollToSection('mars-explorer');
    }
  };

  return (
    <div className="min-h-screen bg-[#080B12] text-[#F5F7FA]">
      {showIntro && <CinematicIntro3D onComplete={() => setShowIntro(false)} />}

      <Navbar
        onOpenAstra={() => setAstraDrawerOpen(true)}
        activeChapter={activeChapter}
      />

      {/* Desktop Holographic Documentary Scroll Chapter Telemetry Rail */}
      <aside
        aria-label="Documentary chapter telemetry"
        className="hidden 2xl:flex fixed right-5 top-1/2 -translate-y-1/2 z-30 flex-col gap-1.5 p-2 rounded-xl holo-panel"
      >
        {DOCUMENTARY_CHAPTERS.map((chap) => {
          const isCurrent = activeChapter === chap.id;
          return (
            <button
              key={chap.id}
              type="button"
              onClick={() => scrollToSection(chap.id)}
              className={`px-2.5 py-1.5 rounded text-left text-[11px] font-mono transition-colors cursor-pointer whitespace-nowrap flex items-center gap-2 ${
                isCurrent
                  ? 'bg-[#38DFFF]/15 text-[#8BEAFF] border border-[#38DFFF]/50'
                  : 'text-[#737F91] hover:text-[#F5F7FA] border border-transparent'
              }`}
            >
              <span className="text-[#38DFFF]">{chap.num}</span>
              <span>{chap.label}</span>
            </button>
          );
        })}
      </aside>

      <main ref={mainRef} className="overflow-x-clip">
        <HeroSection
          learningMode={learningMode}
          onChangeLearningMode={setLearningMode}
          onNavigateSection={scrollToSection}
          onReplayIntro={() => setShowIntro(true)}
        />

        <div className="cinematic-chapter-reveal">
          <PlanetaryExplorerSection
            sectionId="moon-explorer"
            sectionIndex="01"
            body="Moon"
            title="Footprints & Hardware Across the Lunar Surface"
            subtitle="Distinguish between descent stages and science stations intentionally left on the Moon versus expended orbital ascent stages—verified with Apollo coordinates and LRO imagery."
            artifacts={moonArtifacts}
            selectedId={selectedMoonId}
            onSelectId={setSelectedMoonId}
            learningMode={learningMode}
            onJumpToStory={handleJumpToStory}
            onJumpToMuseum={handleJumpToMuseum}
          />
        </div>

        <div className="cinematic-chapter-reveal">
          <PlanetaryExplorerSection
            sectionId="mars-explorer"
            sectionIndex="02"
            body="Mars"
            title="Pioneers & Active Laboratories on the Red Planet"
            subtitle="Explore Mars landing sites from Sojourner to Perseverance. Completed missions like Spirit, Opportunity, and InSight are clearly distinguished from actively operating rovers."
            artifacts={marsArtifacts}
            selectedId={selectedMarsId}
            onSelectId={setSelectedMarsId}
            learningMode={learningMode}
            onJumpToStory={handleJumpToStory}
            onJumpToMuseum={handleJumpToMuseum}
          />
        </div>

        <div className="cinematic-chapter-reveal">
          <EquipmentMuseum3D
            artifacts={SPACE_ARTIFACTS}
            selectedArtifactId={selectedMuseumId}
            onSelectArtifactId={setSelectedMuseumId}
            learningMode={learningMode}
          />
        </div>

        <div className="cinematic-chapter-reveal">
          <StorytellingSection
            artifacts={SPACE_ARTIFACTS}
            selectedStoryId={selectedStoryId}
            onSelectStoryId={setSelectedStoryId}
            learningMode={learningMode}
            onChangeLearningMode={setLearningMode}
          />
        </div>

        <div className="cinematic-chapter-reveal">
          <DiscoveryAndComparisonSection
            artifacts={SPACE_ARTIFACTS}
            learningMode={learningMode}
            onInspectArtifact={handleInspectArtifact}
            onJumpToStory={handleJumpToStory}
            onJumpToMuseum={handleJumpToMuseum}
          />
        </div>

        <div className="cinematic-chapter-reveal">
          <TimelineAndNasaDataSection milestones={TIMELINE_MILESTONES} />
        </div>

        <div className="cinematic-chapter-reveal">
          <QuizSection questions={QUIZ_QUESTIONS} />
        </div>

        <AstraAssistantPanel
          learningMode={learningMode}
          drawerOpen={astraDrawerOpen}
          onOpenDrawer={() => setAstraDrawerOpen(true)}
          onCloseDrawer={() => setAstraDrawerOpen(false)}
        />

        <AboutAndFooter />
      </main>
    </div>
  );
}
