import {
  ArtifactSpotlight,
  Challenge,
  HackathonTeam,
  NasaDataset,
  ScheduleSession,
} from '../types/hackathon';

export const ARTIFACT_SPOTLIGHTS: ArtifactSpotlight[] = [
  {
    id: 'opportunity',
    name: 'MER-B Opportunity Rover',
    body: 'Mars',
    landingSite: 'Meridiani Planum · Perseverance Valley',
    coordinates: '1.9462° S, 354.4734° E',
    activeYears: '2004 – 2018 (5,111 Sols)',
    massKg: 185,
    scientificLegacy:
      'Confirmed past liquid water activity on Mars through hematite spherules and clay mineral spectroscopy across a record 45.16 km traverse.',
    storyAngle:
      'Tell the 15-year endurance diary of a 90-day rover that outlived expectations by 55× before going silent in a planet-wide dust storm.',
  },
  {
    id: 'apollo-11-eagle',
    name: 'Apollo 11 LM-5 Descent Stage',
    body: 'Moon',
    landingSite: 'Mare Tranquillitatis (Tranquility Base)',
    coordinates: '0.67408° N, 23.47297° E',
    activeYears: 'July 20, 1969 (21h 36m surface EVA)',
    massKg: 2134,
    scientificLegacy:
      'Anchored the first crewed lunar landing and left behind the Lunar Laser Ranging Retroreflector, still returning Earth-Moon distance measurements today.',
    storyAngle:
      'Show students how an abandoned aluminum spider frame still reflects laser pulses from Earth 57 years later to measure the Moon drifting away at 3.8 cm/year.',
  },
  {
    id: 'insight',
    name: 'InSight Geophysical Lander',
    body: 'Mars',
    landingSite: 'Elysium Planitia',
    coordinates: '4.5024° N, 135.6234° E',
    activeYears: '2018 – 2022 (1,440 Sols)',
    massKg: 358,
    scientificLegacy:
      'Recorded over 1,300 marsquakes with its ultra-sensitive SEIS seismometer, revealing the thickness of the Martian crust and liquid iron core radius.',
    storyAngle:
      'Frame InSight as a planetary stethoscope listening to Mars’ heartbeat until fine Martian dust dimmed its twin solar fans.',
  },
  {
    id: 'surveyor-3',
    name: 'Surveyor 3 Robotic Lander',
    body: 'Moon',
    landingSite: 'Oceanus Procellarum · Surveyor Crater',
    coordinates: '3.0163° S, 336.5821° E',
    activeYears: 'April – May 1967 (revisited Nov 1969)',
    massKg: 302,
    scientificLegacy:
      'Tested lunar regolith bearing strength ahead of Apollo; later sampled by Apollo 12 astronauts Pete Conrad and Alan Bean to study 31 months of lunar space weathering.',
    storyAngle:
      'Explore the only off-world spacecraft ever visited in person by astronauts from a follow-up mission two and a half years after landing.',
  },
];

export const CHALLENGES: Challenge[] = [
  {
    id: 'abandoned-not-forgotten',
    index: '01',
    title: 'Abandoned but not Forgotten: Discarded Equipment on the Moon and Mars',
    track: 'Planets & Moons',
    difficulty: 'Beginner',
    center: 'NASA Headquarters & JPL',
    summary:
      'Transform retired rovers, descent stages, and stationary probes across the Moon and Mars into interactive stories for school-age explorers.',
    problemStatement:
      'Since the 1960s, humanity has left dozens of rovers, landers, descent stages, and science instruments across the Moon and Mars. While space historians archive these sites, school-age learners typically only hear about active missions and dismiss retired hardware as space junk. Build an interactive storytelling experience, virtual museum, or narrative map that introduces students to these artifacts, their exact resting coordinates, and the scientific breakthroughs they made possible.',
    deliverables: [
      'Interactive 2D/3D planetary map or illustrated mission timeline of at least 6 off-world artifacts',
      'Age-appropriate narrative voice (first-person rover log, guided audio/visual cards, or classroom challenge)',
      'Verified NASA planetary coordinates, mission duration, and key scientific discovery per artifact',
    ],
    evaluationCriteria: [
      'Educational clarity and emotional resonance for ages 9–15',
      'Scientific accuracy using NASA Lunar/Mars orbital imagery and mission archives',
      'Originality of interactive storytelling format and accessibility',
    ],
    datasetIds: ['lro-lunar-dem', 'mro-hirise-sites', 'pds-mission-catalog'],
    imageUrl: '/src/assets/images/track_lunar_south_pole_1794655339076.jpg',
    imageAlt: 'Autonomous lunar rover exploring shadowed crater rims near the Moon South Pole',
    featured: true,
  },
  {
    id: 'earth-trend-detective',
    index: '02',
    title: 'Be An Earth System Trend Detective!',
    track: 'Earth Observation',
    difficulty: 'Advanced',
    center: 'Goddard Space Flight Center',
    summary:
      'Correlate multi-decade precipitation, sea-surface temperature, and vegetation anomalies to uncover hidden regional climate tipping signals.',
    problemStatement:
      'Earth functions as a tightly coupled system where changes in ocean heat content reverberate across continental drought patterns and wildfire seasons months later. Challenge teams must analyze multi-decadal NASA Earthdata time series to surface statistically verified teleconnections and present clear anomaly detection workflows for civic planners.',
    deliverables: [
      'Interactive anomaly dashboard linking at least two independent NASA Earthdata variables',
      'Transparent methodology detailing baseline window, trend slope, and confidence intervals',
      'Exportable regional briefing report for non-specialist decision makers',
    ],
    evaluationCriteria: [
      'Statistical rigor and avoidance of spurious correlation',
      'Visual legibility of multi-variate time-series comparisons',
      'Actionable civic or environmental relevance',
    ],
    datasetIds: ['modis-thermal', 'swot-water-level'],
    imageUrl: '/src/assets/images/track_earth_climate_1794655339702.jpg',
    imageAlt: 'Nadir satellite view of coastal river delta and ocean eddy dynamics',
  },
  {
    id: 'dancing-with-sars',
    index: '03',
    title: 'Dancing with the SARs',
    track: 'Earth Observation',
    difficulty: 'Intermediate',
    center: 'Jet Propulsion Laboratory (JPL)',
    summary:
      'Use Synthetic Aperture Radar backscatter time series to map millimeter-scale ground deformation, coastal wetlands, or urban subsidence.',
    problemStatement:
      'Unlike optical satellites, Synthetic Aperture Radar (SAR) penetrates cloud cover and darkness to measure surface structure and millimeter-level ground motion. Using NISAR-format and Sentinel/ALOS SAR datasets, build a visual story map or automated change-detection tool that reveals natural hazards or human land-use shifts invisible to standard cameras.',
    deliverables: [
      'Interactive interferometric or backscatter change-detection viewer',
      'Physical hypothesis explaining observed surface motion or moisture shifts',
      'Clear color-blind-safe legend with calibrated displacement units (mm/yr or dB)',
    ],
    evaluationCriteria: [
      'Clarity of SAR signal interpretation for general audiences',
      'Accuracy of physical driver hypothesis',
      'Responsiveness and spatial precision of map controls',
    ],
    datasetIds: ['nisar-sar-grid', 'swot-water-level'],
  },
  {
    id: 'jwst-spectral-decoder',
    index: '04',
    title: 'Exoplanet Atmospheric Spectra Decoder',
    track: 'Astrophysics',
    difficulty: 'Intermediate',
    center: 'Space Telescope Science Institute & Ames',
    summary:
      'Build an interactive spectroscopy lab that lets researchers and students match JWST infrared transmission dips to water, methane, and CO2.',
    problemStatement:
      'When an exoplanet transits its host star, starlight filters through its upper atmosphere, leaving faint absorption fingerprints across 0.6–5.0 micrometer infrared bands. Create an accessible visual analyzer that overlays molecular absorption templates onto JWST NIRSpec transmission spectra and quantifies detection confidence.',
    deliverables: [
      'Interactive wavelength-vs-transit-depth plotter with molecular reference overlays',
      'Noise-floor slider demonstrating signal-to-noise challenges on rocky worlds',
      'Shareable target comparison card across at least 4 confirmed exoplanets',
    ],
    evaluationCriteria: [
      'Spectroscopic fidelity in micrometer and ppm units',
      'Intuitiveness of curve-fitting and reference matching UI',
      'Scientific communication quality',
    ],
    datasetIds: ['jwst-exoplanet-spectra'],
    imageUrl: '/src/assets/images/track_deep_space_telescope_1794655340419.jpg',
    imageAlt: 'Infrared deep-space telescope view of star-forming cosmic nebula pillars',
  },
  {
    id: 'artemis-traverse-planner',
    index: '05',
    title: 'Artemis South Pole Illumination & Traverse Planner',
    track: 'Planets & Moons',
    difficulty: 'Advanced',
    center: 'Johnson Space Center',
    summary:
      'Compute solar-aware rover routes around Shackleton Crater that balance slope limits, Earth line-of-sight, and permanently shadowed regions.',
    problemStatement:
      'At the Lunar South Pole, the Sun skims the horizon, casting kilometers-long shadows across crater rims while leaving adjacent peaks sunlit for over 80% of the lunar day. Using Lunar Reconnaissance Orbiter LOLA elevation grids, design a route-planning optimizer that minimizes shadow exposure and stays within 15-degree rover slope tolerances.',
    deliverables: [
      'Interactive elevation & slope heatmap around a candidate Artemis landing region',
      'Pathfinding engine respecting maximum slope and minimum solar illumination thresholds',
      'Telemetry summary outputting total distance, elevation gain, and comms windows',
    ],
    evaluationCriteria: [
      'Correctness of terrain slope and horizon-masking constraints',
      'Clarity of route trade-off telemetry',
      'Performance on real digital elevation grids',
    ],
    datasetIds: ['lro-lunar-dem'],
  },
  {
    id: 'solar-storm-grid-shield',
    index: '06',
    title: 'Coronal Mass Ejection Impact Forecaster',
    track: 'Heliophysics',
    difficulty: 'Intermediate',
    center: 'Goddard Heliophysics Division',
    summary:
      'Translate Solar Dynamics Observatory EUV imagery and L1 solar wind telemetry into actionable aurora and satellite-drag alerts.',
    problemStatement:
      'High-speed coronal mass ejections travel from the Sun to Earth in 18 to 72 hours, threatening low-Earth-orbit satellites, polar aviation comms, and high-latitude power grids. Combine SDO extreme-ultraviolet flare coordinates with DSCOVR L1 magnetic field Bz measurements to visualize geomagnetic storm arrival windows and Kp-index risk.',
    deliverables: [
      'Sun-to-Earth propagation timeline with adjustable solar wind speed (km/s)',
      'Real-time or replayable Bz / proton density telemetry visualizer',
      'Plain-language alert threshold card for satellite operators and aurora observers',
    ],
    evaluationCriteria: [
      'Physical accuracy of propagation transit time and IMF Bz southward coupling',
      'Clarity of alert severity without color-only signaling',
      'Responsive time-scrubbing experience',
    ],
    datasetIds: ['sdo-euv-solar'],
  },
];

export const NASA_DATASETS: NasaDataset[] = [
  {
    id: 'lro-lunar-dem',
    name: 'LRO LOLA South Pole Elevation & Illumination Grid',
    sourceCenter: 'PDS Geosciences Node · GSFC',
    category: 'Planets & Moons',
    format: 'GeoTIFF / JSON',
    resolution: '5 m / pixel',
    cadence: 'Static + Solar Ephemeris',
    endpoint: 'https://api.nasa.gov/planetary/lro/lola/south-pole-v2',
    description:
      'High-precision laser altimetry elevation grids covering 80°S–90°S, including Apollo/Surveyor heritage coordinates and Shackleton Crater illumination profiles.',
    samplePayload: {
      mission: 'Lunar Reconnaissance Orbiter (LRO)',
      instrument: 'LOLA Laser Altimeter',
      region: 'Shackleton_Rim_East',
      grid_resolution_m: 5.0,
      sample_point: {
        lat_deg: -89.542,
        lon_deg: 129.781,
        elevation_m: 1412.4,
        slope_deg: 7.8,
        solar_visibility_pct: 84.2,
      },
    },
  },
  {
    id: 'mro-hirise-sites',
    name: 'MRO HiRISE & Viking/MER Heritage Site Catalog',
    sourceCenter: 'University of Arizona / JPL PDS',
    category: 'Planets & Moons',
    format: 'REST JSON / JP2',
    resolution: '0.25 m / pixel',
    cadence: 'Archival + Ongoing',
    endpoint: 'https://api.nasa.gov/mars/hirise/heritage-hardware',
    description:
      'Sub-meter orbital observations of retired Mars hardware—including Opportunity, Spirit, Viking 1 & 2, Phoenix, and InSight—with rover traverse tracks.',
    samplePayload: {
      artifact_id: 'MER-B-OPPORTUNITY',
      landing_sol: 0,
      final_sol: 5111,
      odometer_km: 45.16,
      site: 'Perseverance_Valley',
      coordinates: { lat: -1.9462, lon: 354.4734 },
      status: 'Mission Complete · Preserved Hardware',
    },
  },
  {
    id: 'pds-mission-catalog',
    name: 'NASA Historic Off-World Hardware Registry',
    sourceCenter: 'NASA History & Planetary Data System',
    category: 'Planets & Moons',
    format: 'JSON-LD',
    resolution: 'Object-level metadata',
    cadence: 'Curated 1966–2026',
    endpoint: 'https://api.nasa.gov/pds/artifacts/lunar-mars-index',
    description:
      'Structured registry of 68 landed descent stages, rovers, seismometers, and laser retroreflectors on the Moon and Mars with educational story hooks.',
    samplePayload: {
      artifact: 'Apollo 11 LM-5 Descent Stage',
      body: 'Moon',
      deployed_utc: '1969-07-20T20:17:40Z',
      dry_mass_kg: 2134,
      active_passive_instruments: ['LRRR Retroreflector', 'PSEP Seismometer'],
      story_grade_band: 'Grades 4-9',
    },
  },
  {
    id: 'nisar-sar-grid',
    name: 'NISAR / Sentinel Synthetic Aperture Radar Tiles',
    sourceCenter: 'NASA JPL · Earthdata Cloud',
    category: 'Earth Observation',
    format: 'HDF5 / GeoJSON',
    resolution: '10 m · L-Band',
    cadence: '12-day repeat cycle',
    endpoint: 'https://cmr.earthdata.nasa.gov/search/granules.json?short_name=NISAR_L2',
    description:
      'Dual-frequency radar backscatter and interferometric phase displacement layers for tracking wetland flooding, glacier velocity, and ground subsidence.',
    samplePayload: {
      product: 'NISAR_L2_GCOV',
      polarization: 'HH+HV',
      pass_direction: 'Ascending',
      mean_coherence: 0.874,
      los_displacement_mm: -14.2,
      cloud_cover_impact: 'None (All-weather L-band)',
    },
  },
  {
    id: 'modis-thermal',
    name: 'MODIS / VIIRS Global Climate & Thermal Anomalies',
    sourceCenter: 'GSFC LANCE / Earthdata',
    category: 'Earth Observation',
    format: 'CSV / GeoJSON',
    resolution: '375 m – 1 km',
    cadence: '3-hour near-real-time',
    endpoint: 'https://firms.modaps.eosdis.nasa.gov/api/area/csv',
    description:
      'Multi-decade surface temperature anomalies, radiative power detections, and regional precipitation departures for long-horizon trend analysis.',
    samplePayload: {
      instrument: 'VIIRS_SNPP',
      latitude: 38.5421,
      longitude: -122.4819,
      brightness_kelvin: 342.6,
      frp_mw: 48.3,
      confidence: 'nominal',
    },
  },
  {
    id: 'swot-water-level',
    name: 'SWOT Surface Water & Ocean Topography',
    sourceCenter: 'JPL PO.DAAC',
    category: 'Earth Observation',
    format: 'NetCDF / JSON',
    resolution: '100 m river/lake width',
    cadence: '21-day global cycle',
    endpoint: 'https://podaac.jpl.nasa.gov/api/swot/l2_hr_riversp',
    description:
      'Ka-band radar interferometer water-surface elevation measurements for rivers, lakes, reservoirs, and coastal ocean eddies.',
    samplePayload: {
      reach_id: '74269100041',
      water_surface_elev_m: 112.48,
      slope_mm_per_km: 184.2,
      estimated_discharge_m3_s: 1420.5,
      uncertainty_m: 0.09,
    },
  },
  {
    id: 'jwst-exoplanet-spectra',
    name: 'JWST NIRSpec Exoplanet Transmission Spectra',
    sourceCenter: 'MAST Archive · STScI',
    category: 'Astrophysics',
    format: 'FITS / JSON',
    resolution: 'R ~ 100–2700 (0.6–5.3 µm)',
    cadence: 'Per transit observation',
    endpoint: 'https://exoplanetarchive.ipac.caltech.edu/TAP/sync?query=jwst_spectra',
    description:
      'Calibrated infrared transit depth curves showing molecular absorption bands for H2O, CH4, CO2, and SO2 in gas giant and sub-Neptune atmospheres.',
    samplePayload: {
      target_planet: 'WASP-39 b',
      instrument: 'NIRSpec PRISM',
      wavelength_um: 4.35,
      transit_depth_ppm: 21480,
      uncertainty_ppm: 115,
      dominant_absorber: 'CO2 (4.3 µm band)',
    },
  },
  {
    id: 'sdo-euv-solar',
    name: 'SDO AIA Extreme-UV & DSCOVR L1 Solar Wind',
    sourceCenter: 'GSFC Space Weather Lab',
    category: 'Heliophysics',
    format: 'JSON / FITS',
    resolution: '1-minute cadence',
    cadence: 'Real-time L1 stream',
    endpoint: 'https://api.nasa.gov/DONKI/CMEAnalysis',
    description:
      'Solar coronal mass ejection kinematics paired with L1 interplanetary magnetic field Bz and solar wind velocity measurements.',
    samplePayload: {
      event_id: '2026-11-12T08:24:00-CME-001',
      half_angle_deg: 34,
      speed_km_s: 1180,
      imf_bz_nt: -14.6,
      predicted_kp_index: 6.7,
      earth_arrival_window_hours: 34.5,
    },
  },
];

export const SCHEDULE_SESSIONS: ScheduleSession[] = [
  {
    id: 's1',
    day: 1,
    utcIso: '2026-11-14T14:00:00Z',
    durationMins: 45,
    title: 'Opening Mission Briefing: The Next Frontier',
    speaker: 'Dr. Elena Vance · NASA Science Mission Directorate',
    sessionType: 'Keynote',
    description:
      'Official kickoff, overview of the 2026 global theme, and rules for open-science dataset citations.',
  },
  {
    id: 's2',
    day: 1,
    utcIso: '2026-11-14T15:30:00Z',
    durationMins: 60,
    title: 'Challenge Deep-Dive: Abandoned Equipment on Moon & Mars',
    speaker: 'Marcus Thorne · JPL Planetary Archives',
    sessionType: 'Workshop',
    description:
      'How to extract verified landing coordinates, rover traverses, and HiRISE imagery for classroom-ready storytelling.',
  },
  {
    id: 's3',
    day: 1,
    utcIso: '2026-11-14T18:00:00Z',
    durationMins: 90,
    title: 'Team Formation & Track Calibration Clinic',
    speaker: 'Space Apps Local Leads · Houston & Remote',
    sessionType: 'Milestone',
    description:
      'Match solo engineers, designers, and science writers with teams seeking specific skills before lock-in.',
  },
  {
    id: 's4',
    day: 2,
    utcIso: '2026-11-15T01:00:00Z',
    durationMins: 60,
    title: 'Working with SAR Backscatter & Earthdata Cloud APIs',
    speaker: 'Priya Nair · Goddard Earth Sciences',
    sessionType: 'Workshop',
    description:
      'Hands-on walkthrough for querying NISAR, MODIS, and SWOT granules without downloading terabytes locally.',
  },
  {
    id: 's5',
    day: 2,
    utcIso: '2026-11-15T16:00:00Z',
    durationMins: 120,
    title: 'NASA Subject Matter Expert Office Hours',
    speaker: '24 Mentors across JPL, GSFC, Ames, and JSC',
    sessionType: 'Mentorship',
    description:
      '15-minute live technical critiques on telemetry units, orbital math, and narrative clarity.',
  },
  {
    id: 's6',
    day: 2,
    utcIso: '2026-11-15T22:00:00Z',
    durationMins: 30,
    title: 'Mid-Sprint Architecture & Demo Checkpoint',
    speaker: 'Technical Review Committee',
    sessionType: 'Milestone',
    description:
      'Verify repository licensing (Apache-2.0 / MIT), dataset attribution, and 30-second prototype capture.',
  },
  {
    id: 's7',
    day: 3,
    utcIso: '2026-11-16T15:00:00Z',
    durationMins: 45,
    title: 'Project Freeze & Submission Deadline',
    speaker: 'Global Judging Operations',
    sessionType: 'Milestone',
    description:
      'Final commit lock, 3-minute demonstration video upload, and NASA dataset citation verification.',
  },
  {
    id: 's8',
    day: 3,
    utcIso: '2026-11-16T17:30:00Z',
    durationMins: 90,
    title: 'Top Finalist Lightning Demos & Global Nominee Awards',
    speaker: 'NASA Open Innovation Jury',
    sessionType: 'Keynote',
    description:
      'Live 4-minute demonstrations from top regional teams and announcement of Global Nominees.',
  },
];

export const INITIAL_TEAMS: HackathonTeam[] = [
  {
    id: 'team-meridian',
    name: 'Meridian Chroniclers',
    leadEmail: 'aria.chen@orbital-lab.org',
    mode: 'Global Remote',
    challengeId: 'abandoned-not-forgotten',
    datasetIds: ['mro-hirise-sites', 'pds-mission-catalog'],
    rolesNeeded: ['Storytelling / UX', '3D WebGL'],
    currentMembers: 3,
    maxMembers: 5,
    pitch:
      'Building an interactive 3D Mars & Moon field guide where students pilot a virtual camera to Opportunity and Apollo 11.',
  },
  {
    id: 'team-shackleton',
    name: 'Shackleton Navigators',
    leadEmail: 'd.okonkwo@jsc-fellows.edu',
    mode: 'In-Person · Houston',
    challengeId: 'artemis-traverse-planner',
    datasetIds: ['lro-lunar-dem'],
    rolesNeeded: ['Orbital / Pathfinding', 'Frontend Viz'],
    currentMembers: 4,
    maxMembers: 6,
    pitch:
      'A-star lunar slope & solar horizon solver running directly on 5m LOLA elevation tiles.',
  },
  {
    id: 'team-sar-pulse',
    name: 'Delta Coherence',
    leadEmail: 'l.kovacs@earthwatch.io',
    mode: 'Global Remote',
    challengeId: 'dancing-with-sars',
    datasetIds: ['nisar-sar-grid', 'swot-water-level'],
    rolesNeeded: ['ML / Remote Sensing'],
    currentMembers: 4,
    maxMembers: 5,
    pitch:
      'Mapping coastal wetland inundation beneath storm clouds using L-band SAR coherence deltas.',
  },
  {
    id: 'team-transit-lab',
    name: 'IR Transit Lab',
    leadEmail: 's.patel@astrophys.net',
    mode: 'Global Remote',
    challengeId: 'jwst-spectral-decoder',
    datasetIds: ['jwst-exoplanet-spectra'],
    rolesNeeded: ['Astrophysics', 'Data Viz'],
    currentMembers: 2,
    maxMembers: 4,
    pitch:
      'Interactive NIRSpec absorption template matcher comparing WASP-39 b and K2-18 b in browser.',
  },
];

export const AVAILABLE_ROLES = [
  'Full-Stack',
  '3D WebGL',
  'ML / Remote Sensing',
  'Data Viz',
  'Storytelling / UX',
  'Orbital / Pathfinding',
];
