import type {
  NasaMediaItem,
  QuizQuestion,
  SpaceArtifact,
  TimelineMilestone,
} from '../types/museum';

export const VERIFIED_HERO_METRICS = [
  {
    value: '6',
    label: 'Crewed Apollo Lunar Landings',
    detail: 'Apollo 11, 12, 14, 15, 16 & 17 (1969–1972)',
  },
  {
    value: '5',
    label: 'NASA Mars Rovers Landed',
    detail: 'Sojourner, Spirit, Opportunity, Curiosity & Perseverance',
  },
  {
    value: '10',
    label: 'Documented Surface Artifacts',
    detail: 'Moon & Mars landers, rovers, and experiment stations',
  },
  {
    value: '2',
    label: 'Active Mars Surface Rovers',
    detail: 'Curiosity (Gale) & Perseverance (Jezero)',
  },
] as const;

export const SPACE_ARTIFACTS: SpaceArtifact[] = [
  {
    id: 'apollo-11-eagle-descent',
    name: 'Apollo 11 Lunar Module "Eagle" Descent Stage',
    missionName: 'Apollo 11',
    missionYear: 1969,
    body: 'Moon',
    category: 'Ascent & Descent Stage',
    status: 'Intentionally Left Behind',
    statusNote: 'Intentionally left behind as the launch pad for the Ascent Stage.',
    siteName: 'Mare Tranquillitatis (Tranquility Base)',
    coordinates: {
      lat: 0.67409,
      lon: 23.47297,
      label: '0.67409° N, 23.47297° E',
    },
    launchDate: 'July 16, 1969',
    landingDate: 'July 20, 1969',
    endDate: 'July 21, 1969 (Ascent Liftoff)',
    massKg: 2134,
    powerSource: 'Silver-zinc primary batteries',
    imageUrl: '/src/assets/images/apollo_lunar_module_museum_1794656365730.jpg',
    imageAttribution: 'NASA / Apollo 11 Mission Archive',
    model3DType: 'lunar-module',
    purposeStudent:
      'Served as the four-legged landing base and rocket launch pad that carried Neil Armstrong and Buzz Aldrin down to the Moon and launched them back toward orbit.',
    purposeScientific:
      'Provided throttled hypergolic descent propulsion (DPS), landing gear attenuation, stowage bays for EASEP experiments, and a stable structural launch platform for the Ascent Stage.',
    scientificContribution:
      'Enabled the first crewed lunar surface sampling (21.55 kg of lunar basalt returned) and deployment of the Passive Seismic Experiment Package and Lunar Laser Ranging Retroreflector.',
    whyLeftBehind:
      'Strict delta-v and mass margins meant the Ascent Stage could only lift the crew and lunar samples if the heavy descent engine, propellant tanks, and landing legs stayed behind as a launch platform.',
    thenVsNow: {
      thenCaption: 'July 20, 1969 — Photographed on the dusty Sea of Tranquility by Neil Armstrong.',
      nowCaption: 'Confirmed intact at Tranquility Base by NASA Lunar Reconnaissance Orbiter (LRO) narrow-angle imagery.',
      orbitalVerification: 'Imaged by LROC from 25–50 km altitude showing descent stage shadow and footpad tracks.',
    },
    storyStages: [
      {
        stageNumber: 1,
        title: 'The Beginning',
        subtitle: 'Designing a spacecraft solely for vacuum flight',
        studentText:
          'Unlike sleek airplanes, Eagle never had to fly through Earth’s air. Engineers built it to be as light as possible, wrapping its lower half in thin gold thermal foil to block fierce lunar heat.',
        scientificText:
          'Grumman Aerospace engineered the LM-5 Descent Stage using an octagonal aluminum alloy cruciform frame shielded by multi-layer aluminized Kapton insulation and a variable-thrust (4.7–45 kN) Descent Propulsion System.',
      },
      {
        stageNumber: 2,
        title: 'The Journey',
        subtitle: 'Saturn V launch and Lunar Orbit Rendezvous',
        studentText:
          'A giant Saturn V rocket launched Eagle and Columbia from Florida. Three days later, Eagle undocked in lunar orbit and fired its engine for 12 minutes to touch down with seconds of fuel remaining.',
        scientificText:
          'Following translunar injection and lunar orbit insertion, LM-5 separated from CSM-107 Columbia on July 20, executing powered descent initiation (PDI) and manual hazard avoidance over West Crater.',
      },
      {
        stageNumber: 3,
        title: 'The Mission',
        subtitle: '21 hours and 36 minutes at Tranquility Base',
        studentText:
          'Astronauts stepped down Eagle’s 9-rung ladder, collected rocks, raised a solar-wind foil collector, and set up laser mirrors and moonquake sensors near the lander.',
        scientificText:
          'During a single 2h 31m EVA, the crew deployed the Early Apollo Scientific Experiments Package (EASEP), collected 21.55 kg of Mare Tranquillitatis basalt, and documented local regolith mechanics.',
      },
      {
        stageNumber: 4,
        title: 'The Discoveries',
        subtitle: 'Proving the Moon’s fiery volcanic past',
        studentText:
          'The rocks brought back showed that the dark flat lunar plains were ancient hardened lava flows rich in titanium, helping scientists measure the exact age of the Moon.',
        scientificText:
          'Radiometric dating of Tranquility Base basalts established mare volcanism at ~3.7 billion years old, while the laser retroreflector revealed Earth-Moon orbital recession (~3.8 cm/year).',
      },
      {
        stageNumber: 5,
        title: 'The Legacy',
        subtitle: 'A permanent monument on another world',
        studentText:
          'When Armstrong and Aldrin blasted off in the upper cabin, Eagle’s gold lower half stayed behind forever. NASA satellites orbiting the Moon today still photograph it sitting silently in the dust.',
        scientificText:
          'Recognized under U.S. One Small Step Heritage guidelines and international lunar preservation efforts, the LM-5 Descent Stage remains an undisturbed benchmark for regolith space-weathering studies.',
      },
    ],
    components: [
      {
        id: 'kapton-descent',
        name: 'Gold Kapton Descent Stage',
        role: 'Thermal shielding & structural core',
        studentExplanation: 'Thin gold-colored foil blankets protect fuel tanks from extreme sunlight and freezing lunar shadows.',
        scientificExplanation: 'Multi-layer aluminized polyimide (Kapton) insulation minimizes radiative heat transfer across the octagonal aluminum cruciform frame.',
      },
      {
        id: 'landing-gear',
        name: 'Crushable Honeycomb Landing Legs',
        role: 'Impact attenuation & launch stability',
        studentExplanation: 'Four wide saucer-like footpads keep the spacecraft from sinking into soft lunar dust.',
        scientificExplanation: 'Aluminum honeycomb shock-absorbing struts dissipate touchdown kinetic energy and preserve a level launch datum.',
      },
      {
        id: 'ascent-cabin',
        name: 'Crew Ascent Cabin & Windows',
        role: 'Pressurized crew habitat & return vehicle',
        studentExplanation: 'The upper cabin held both astronauts and blasted off from the lower stage to reunite with Columbia.',
        scientificExplanation: 'Pressurized 235 kPa pure-oxygen crew compartment with canted triangular windows for downward landing visibility.',
      },
      {
        id: 's-band-dish',
        name: 'S-Band Steerable Antenna',
        role: 'Earth telemetry & television link',
        studentExplanation: 'This small dish beamed astronaut voices and live black-and-white TV pictures back to Earth.',
        scientificExplanation: '2.2 GHz steerable parabolic dish transmitting voice, biomedical telemetry, and SSTV video to NASA Deep Space Network stations.',
      },
    ],
    references: [
      { label: 'NASA NSSDC — Apollo 11 Lunar Module (Eagle)', url: 'https://nssdc.gsfc.nasa.gov/nmc/spacecraft/display.action?id=1969-059C' },
      { label: 'NASA Science — Apollo 11 Overview', url: 'https://science.nasa.gov/mission/apollo-11/' },
    ],
  },
  {
    id: 'apollo-15-lrv',
    name: 'Apollo 15 Lunar Roving Vehicle (LRV-1)',
    missionName: 'Apollo 15',
    missionYear: 1971,
    body: 'Moon',
    category: 'Rover',
    status: 'Intentionally Left Behind',
    statusNote: 'Intentionally parked at Hadley-Apennine after completing three geological traverses.',
    siteName: 'Hadley-Apennine',
    coordinates: {
      lat: 26.1322,
      lon: 3.6339,
      label: '26.1322° N, 3.6339° E',
    },
    launchDate: 'July 26, 1971',
    landingDate: 'July 30, 1971',
    endDate: 'August 2, 1971',
    massKg: 210,
    powerSource: 'Two 36-volt silver-zinc potassium hydroxide batteries',
    distanceTraveledKm: 27.9,
    imageUrl: '/src/assets/images/lunar_roving_vehicle_1794656366444.jpg',
    imageAttribution: 'NASA / Apollo 15 Surface Photography',
    model3DType: 'lunar-rover',
    purposeStudent:
      'An electric, foldable moon buggy that let astronauts drive miles away from their lander to explore steep canyon rims and mountains.',
    purposeScientific:
      'Extended astronaut surface traverse range from walking limits (<2 km) to 27.9 km across Mare Imbrium, Hadley Rille, and the Apennine foothills.',
    scientificContribution:
      'Enabled discovery of the 4.1-billion-year-old "Genesis Rock" anorthosite sample and deep stratigraphic sampling of Hadley Rille.',
    whyLeftBehind:
      'Packed folded inside the Falcon Lunar Module descent bay, the rover had no return capability. Astronauts parked it ~90 m from the lander so its Earth-controlled TV camera could broadcast liftoff.',
    thenVsNow: {
      thenCaption: 'August 1971 — Parked facing Lunar Module Falcon at Hadley-Apennine.',
      nowCaption: 'Confirmed stationary in LRO orbital imaging alongside rover wheel tracks.',
      orbitalVerification: 'LRO tracks reveal double wheel ruts curving back to the final parking spot.',
    },
    storyStages: [
      {
        stageNumber: 1,
        title: 'The Beginning',
        subtitle: 'Building a car that weighs 210 kg and folds like origami',
        studentText:
          'Walking in bulky spacesuits was exhausting, so NASA asked Boeing and Delco to build a super-light electric car that could fold flat against the side of the Lunar Module.',
        scientificText:
          'Developed in just 17 months, LRV-1 had an empty mass of 210 kg (only ~35 kg in lunar 1/6 gravity) yet carried 490 kg of crew, tools, and lunar rock samples.',
      },
      {
        stageNumber: 2,
        title: 'The Journey',
        subtitle: 'Unfolding on the edge of a lunar canyon',
        studentText:
          'Once Commander Dave Scott and Jim Irwin landed beside Mount Hadley, they pulled release cables that unfolded the rover’s wheels onto the Moon.',
        scientificText:
          'Stowed in Quadrant 1 of LM-10 Falcon, LRV-1 deployed via pulley-and-torsion-bar kinematics onto the mare surface north of Hadley Rille.',
      },
      {
        stageNumber: 3,
        title: 'The Mission',
        subtitle: 'Three geologic field trips across 27.9 kilometers',
        studentText:
          'Using wire-mesh tires that couldn’t pop, astronauts drove up dusty slopes at 13 km/h, guided by a sun-shadow compass and dead-reckoning computer.',
        scientificText:
          'Four independent 0.25-hp hub motors and dual Ackermann steering drove 27.9 km over three EVAs, carrying 77 kg of documented highland and rille samples.',
      },
      {
        stageNumber: 4,
        title: 'The Discoveries',
        subtitle: 'Finding a piece of the Moon’s original crust',
        studentText:
          'Near Spur Crater, the crew spotted a gleaming white rock—the famous Genesis Rock—proving the young Moon was once covered by a global ocean of molten magma.',
        scientificText:
          'Sample 15415 (crystalline ferroan anorthosite) confirmed the Lunar Magma Ocean differentiation hypothesis for early planetary crust formation.',
      },
      {
        stageNumber: 5,
        title: 'The Legacy',
        subtitle: 'The Moon’s first Earth-controlled cameraman',
        studentText:
          'Before blasting off, astronauts aimed LRV-1’s camera at Falcon. Mission Control in Houston steered the camera by radio to watch the rocket lift off—and left LRV-1 parked in history.',
        scientificText:
          'All three Apollo Lunar Roving Vehicles (Apollo 15, 16, 17) remain at their final parking coordinates as pioneers of off-world electric mobility.',
      },
    ],
    components: [
      {
        id: 'wire-wheels',
        name: 'Zinc-Coated Piano-Wire Mesh Wheels',
        role: 'Traction without pneumatic air',
        studentExplanation: 'Springy woven metal mesh wheels couldn’t blow out in vacuum and gripped loose lunar dust.',
        scientificExplanation: 'Woven 81 cm spring-steel mesh tires with titanium chevron treads and internal bump stops.',
      },
      {
        id: 'high-gain-dish',
        name: 'Umbrella High-Gain Dish',
        role: 'Direct-to-Earth video transmission',
        studentExplanation: 'Opened like a gold mesh umbrella to send color video straight from the Moon to Earth.',
        scientificExplanation: 'Deployable 97 cm S-band parabolic reflector providing real-time color television from remote traverse stops.',
      },
      {
        id: 'lcrv-camera',
        name: 'Ground-Commanded TV Camera',
        role: 'Remote geological documentation',
        studentExplanation: 'Scientists on Earth could pan and tilt this camera to see rocks alongside the astronauts.',
        scientificExplanation: 'RCA color field-sequential camera actuated remotely from Houston MOCR via S-band uplink.',
      },
      {
        id: 'nav-console',
        name: 'Dead-Reckoning Navigation Console',
        role: 'Directional gyro & odometer',
        studentExplanation: 'Without GPS on the Moon, this dial tracked wheel turns and direction so crews could always find home.',
        scientificExplanation: 'Gyroscopic directional indicator and wheel-pulse integrator computing bearing and range to the Lunar Module.',
      },
    ],
    references: [
      { label: 'NASA NSSDC — Apollo 15 Lunar Roving Vehicle', url: 'https://nssdc.gsfc.nasa.gov/nmc/spacecraft/display.action?id=1971-063D' },
      { label: 'NASA Science — Apollo 15', url: 'https://science.nasa.gov/mission/apollo-15/' },
    ],
  },
  {
    id: 'apollo-12-alsep',
    name: 'Apollo 12 ALSEP Science Station',
    missionName: 'Apollo 12',
    missionYear: 1969,
    body: 'Moon',
    category: 'Scientific Instrument',
    status: 'Intentionally Left Behind',
    statusNote: 'Intentionally left behind for long-term monitoring; telemetry powered down Sept 30, 1977.',
    siteName: 'Oceanus Procellarum (Ocean of Storms)',
    coordinates: {
      lat: -3.0124,
      lon: -23.4216,
      label: '3.0124° S, 23.4216° W',
    },
    launchDate: 'November 14, 1969',
    landingDate: 'November 19, 1969',
    endDate: 'September 30, 1977 (Decommissioned)',
    massKg: 147,
    powerSource: 'SNAP-27 Plutonium-238 RTG (~73 W)',
    imageUrl: '/src/assets/images/track_lunar_south_pole_1794655339076.jpg',
    imageAttribution: 'NASA / Lunar Surface Science Archive',
    model3DType: 'lunar-module',
    purposeStudent:
      'A nuclear-powered robot weather-and-quake station left on the Moon to listen for moonquakes and solar storms for years after astronauts went home.',
    purposeScientific:
      'Autonomous geophysical observatory measuring lunar seismicity, surface magnetic fields, solar-wind ion flux, and suprathermal lunar ions.',
    scientificContribution:
      'Built the first long-duration lunar seismic network, proving the Moon has a solid crust, mantle, and small dense core and experiences tidal moonquakes.',
    whyLeftBehind:
      'Designed specifically as a permanent unattended observatory powered by a plutonium-238 RTG so it could run for years without astronauts.',
    thenVsNow: {
      thenCaption: 'November 1969 — Central station and SNAP-27 RTG deployed on Ocean of Storms.',
      nowCaption: 'Stationary on the lunar surface; telemetry turned off by NASA in 1977 due to budget & signal decay.',
      orbitalVerification: 'Observed by LRO alongside astronaut footpaths toward Surveyor Crater.',
    },
    storyStages: [
      {
        stageNumber: 1,
        title: 'The Beginning',
        subtitle: 'Science that continues long after footprints fade',
        studentText:
          'Astronauts could only stay on the Moon for a couple of days, so NASA designed a suitcase-sized nuclear battery station to keep studying the Moon for years.',
        scientificText:
          'The Apollo Lunar Surface Experiments Package (ALSEP) standardized a central telemetry station powered by a SNAP-27 radioisotope thermoelectric generator.',
      },
      {
        stageNumber: 2,
        title: 'The Journey',
        subtitle: 'Surviving two lightning strikes at launch',
        studentText:
          'Thirty-six seconds after Apollo 12 launched through storm clouds, lightning struck the rocket twice! Quick action saved the flight, carrying ALSEP safely to the Moon.',
        scientificText:
          'Despite dual lightning-induced electrical transients during Saturn V ascent, LM-6 Intrepid achieved a pinpoint landing 163 meters from Surveyor 3.',
      },
      {
        stageNumber: 3,
        title: 'The Mission',
        subtitle: 'Eight years of continuous lunar telemetry',
        studentText:
          'Pete Conrad and Alan Bean carried the instruments 130 meters away from their lander, plugged in the warm nuclear core, and aimed the antenna toward Earth.',
        scientificText:
          'Apollo 12 ALSEP operated from November 1969 until September 30, 1977, networking with Apollo 14, 15, and 16 stations.',
      },
      {
        stageNumber: 4,
        title: 'The Discoveries',
        subtitle: 'The Moon rings like a bell',
        studentText:
          'When an empty rocket stage hit the Moon, Apollo 12’s seismometer shook for nearly an hour! It showed the Moon’s dry, fractured crust transmits vibrations very differently from Earth.',
        scientificText:
          'Multi-station seismic inversion revealed a ~60 km lunar crust, deep moonquake nests triggered by Earth tidal stress, and local crustal magnetic anomalies.',
      },
      {
        stageNumber: 5,
        title: 'The Legacy',
        subtitle: 'Foundation for modern Artemis lunar networks',
        studentText:
          'Today ALSEP sits quietly in the Ocean of Storms, but its decades-old tapes are still being re-analyzed by modern computers to plan safe future lunar bases.',
        scientificText:
          'Digitized ALSEP seismic waveforms continue to inform modern lunar interior models and upcoming Artemis Lunar Geophysical Network deployments.',
      },
    ],
    components: [
      {
        id: 'snap27',
        name: 'SNAP-27 Radioisotope Generator',
        role: 'Long-duration thermal-electric power',
        studentExplanation: 'Used natural warmth from plutonium fuel to generate electricity day and night without solar panels.',
        scientificExplanation: 'Thermopile array converting ~1,480 W thermal decay of Pu-238 into ~73 W electrical power across 14-day lunar nights.',
      },
      {
        id: 'pse',
        name: 'Passive Seismic Experiment',
        role: 'Moonquake & impact detection',
        studentExplanation: 'Ultra-sensitive motion sensors felt tiny vibrations from meteoroids and tidal pulls.',
        scientificExplanation: 'Three-axis long-period and single-axis short-period seismometers sensitive to sub-nanometer ground displacements.',
      },
      {
        id: 'lsm',
        name: 'Lunar Surface Magnetometer',
        role: 'Crustal magnetic mapping',
        studentExplanation: 'Measured faint magnetism frozen inside ancient lunar rocks.',
        scientificExplanation: 'Three orthogonal fluxgate sensors measuring local remanent fields (~38 nT at Apollo 12 site).',
      },
      {
        id: 'central-station',
        name: 'ALSEP Central Telemetry Unit',
        role: 'Command & data downlink',
        studentExplanation: 'Collected measurements from every instrument and beamed them back to NASA receivers.',
        scientificExplanation: 'S-band helical antenna and multiplexer transmitting 1,060 bps continuous scientific telemetry.',
      },
    ],
    references: [
      { label: 'NASA NSSDC — Apollo 12 ALSEP', url: 'https://nssdc.gsfc.nasa.gov/nmc/experiment/display.action?id=1969-099C-01' },
      { label: 'NASA Science — Apollo 12', url: 'https://science.nasa.gov/mission/apollo-12/' },
    ],
  },
  {
    id: 'apollo-11-eagle-ascent',
    name: 'Apollo 11 Lunar Module "Eagle" Ascent Stage',
    missionName: 'Apollo 11',
    missionYear: 1969,
    body: 'Moon',
    category: 'Ascent & Descent Stage',
    status: 'Intentionally Discarded',
    statusNote: 'Intentionally jettisoned in lunar orbit after crew returned to Columbia; impacted Moon at an unconfirmed site.',
    siteName: 'Lunar Orbit / Unconfirmed Lunar Impact',
    coordinates: {
      lat: 1.5,
      lon: 28.0,
      label: 'Orbital Jettison (Impact Site Unconfirmed)',
    },
    launchDate: 'July 16, 1969',
    landingDate: 'July 20, 1969',
    endDate: 'July 21, 1969 (Jettisoned)',
    massKg: 2180,
    powerSource: 'Ascent stage silver-zinc batteries',
    imageUrl: '/src/assets/images/hero_orbital_horizon_1794655338444.jpg',
    imageAttribution: 'NASA / Apollo 11 Lunar Orbit Archive',
    model3DType: 'lunar-module',
    purposeStudent:
      'The upper spacecraft cabin that carried Neil Armstrong and Buzz Aldrin off the Moon to reunite with Michael Collins in lunar orbit.',
    purposeScientific:
      'Pressurized lunar-orbit-rendezvous ascent vehicle powered by a 15.6 kN hypergolic Ascent Propulsion System.',
    scientificContribution:
      'Safely returned the first humans and 21.55 kg of lunar samples from another celestial body to Earth-return trajectory.',
    whyLeftBehind:
      'Once the crew and sample boxes transferred into Command Module Columbia, Eagle’s ascent cabin had no heat shield to survive Earth reentry—so it was sealed and discarded in lunar orbit.',
    thenVsNow: {
      thenCaption: 'July 21, 1969 — Photographed by Michael Collins as Eagle approached Columbia in lunar orbit.',
      nowCaption: 'Orbit decayed over subsequent weeks/months; exact lunar impact crater remains unlocated.',
      orbitalVerification: 'Orbital stability modeling suggests eventual lunar surface impact; later Apollo ascent stages were deliberately crashed for seismic tests.',
    },
    storyStages: [
      {
        stageNumber: 1,
        title: 'The Beginning',
        subtitle: 'One engine that could never fail',
        studentText:
          'Unlike the rocket that landed, the Ascent Engine had only one chance to fire—if it failed, the astronauts could not leave the Moon. Engineers made it ultra-simple with zero moving parts in the fuel valves.',
        scientificText:
          'The Bell/Rocketdyne Ascent Propulsion System used hypergolic Aerozine 50 and nitrogen tetroxide that ignited spontaneously on contact.',
      },
      {
        stageNumber: 2,
        title: 'The Journey',
        subtitle: 'Lifting off from Tranquility Base',
        studentText:
          'A broken circuit breaker switch nearly trapped them, until Buzz Aldrin pushed it back in with a felt-tip pen. At 1:54 PM EDT, Eagle blasted upward cleanly.',
        scientificText:
          'Pyrotechnic guillotines severed electrical and fluid umbilicals to the Descent Stage milliseconds before the 435-second ascent burn to lunar orbit.',
      },
      {
        stageNumber: 3,
        title: 'The Mission',
        subtitle: 'Rendezvous and transfer in lunar orbit',
        studentText:
          'Eagle chased Columbia around the Moon, docked cleanly, and Armstrong and Aldrin floated their Moon rock boxes safely into the homebound capsule.',
        scientificText:
          'LM-5 completed coelliptic rendezvous and hard docking with CSM-107 on July 21, transferring crew, Hasselblad film, and ALSRC sample containers.',
      },
      {
        stageNumber: 4,
        title: 'The Discoveries',
        subtitle: 'Why later missions turned discarded stages into science tools',
        studentText:
          'Eagle was simply left drifting in lunar orbit, which taught NASA a clever idea: on Apollo 12 through 17, engineers intentionally aimed empty ascent stages at the Moon to create artificial moonquakes for ALSEP sensors.',
        scientificText:
          'Controlled impacts of Apollo 12–17 ascent stages generated known-energy seismic sources, calibrating lunar mantle wave velocities.',
      },
      {
        stageNumber: 5,
        title: 'The Legacy',
        subtitle: 'A true example of discarded mission hardware',
        studentText:
          'Unlike Eagle’s lower stage—left neatly as a launch pad—the upper cabin was truly discarded once its job was done, illustrating how early spaceflight traded hardware for survival.',
        scientificText:
          'Illustrates the operational distinction between surface-emplaced hardware and expended orbital stages in Apollo’s Lunar Orbit Rendezvous architecture.',
      },
    ],
    components: [
      {
        id: 'ascent-engine',
        name: 'Hypergolic Ascent Engine',
        role: 'Single-burn lunar liftoff',
        studentExplanation: 'Mixed two chemicals that burst into flame automatically on contact—no spark plug required.',
        scientificExplanation: 'Fixed-thrust 15.6 kN hypergolic pressure-fed engine designed for maximum ignition reliability.',
      },
      {
        id: 'docking-tunnel',
        name: 'Overhead Docking Tunnel',
        role: 'Crew & sample transfer',
        studentExplanation: 'The top hatch connected directly to Columbia so astronauts could float across without going outside.',
        scientificExplanation: '81 cm pressurized transfer tunnel housing the drogue docking interface.',
      },
    ],
    references: [
      { label: 'NASA Apollo 11 Flight Journal', url: 'https://www.nasa.gov/history/afj/ap11fj/' },
    ],
  },
  {
    id: 'surveyor-3',
    name: 'Surveyor 3 Robotic Lander',
    missionName: 'Surveyor 3 (Visited by Apollo 12)',
    missionYear: 1967,
    body: 'Moon',
    category: 'Lander',
    status: 'Mission Completed',
    statusNote: 'Completed robotic mission in May 1967; physically inspected and sampled by Apollo 12 astronauts in November 1969.',
    siteName: 'Oceanus Procellarum (Surveyor Crater)',
    coordinates: {
      lat: -3.015,
      lon: -23.418,
      label: '3.015° S, 23.418° W',
    },
    launchDate: 'April 17, 1967',
    landingDate: 'April 20, 1967',
    endDate: 'May 4, 1967 (Visited Nov 19, 1969)',
    massKg: 302,
    powerSource: 'Solar array + rechargeable silver-zinc battery',
    imageUrl: '/src/assets/images/track_lunar_south_pole_1794655339076.jpg',
    imageAttribution: 'NASA / Apollo 12 & Surveyor Archive',
    model3DType: 'insight-lander',
    purposeStudent:
      'A three-legged robot scout that bounced three times before landing on a crater slope in 1967, digging the first trenches in lunar soil to prove astronauts wouldn’t sink.',
    purposeScientific:
      'Pre-Apollo surface verification lander equipped with a soil mechanics surface sampler scoop and television camera.',
    scientificContribution:
      'Confirmed lunar regolith had sufficient bearing strength (~34 kPa) for Apollo Lunar Module landings; later provided a 31-month space-exposure materials experiment when Apollo 12 retrieved its camera.',
    whyLeftBehind:
      'Robotic scout designed as a one-way surface mission; Apollo 12 later returned its TV camera and scoop to Earth while leaving the main lander frame inside Surveyor Crater.',
    thenVsNow: {
      thenCaption: 'November 1969 — Apollo 12 astronaut Pete Conrad standing beside Surveyor 3 inside Surveyor Crater.',
      nowCaption: 'Surveyor 3 frame remains inside Surveyor Crater with Apollo 12’s Intrepid descent stage 163 m away.',
      orbitalVerification: 'LRO imagery clearly resolves Surveyor 3’s shadow inside the crater bowl.',
    },
    storyStages: [
      {
        stageNumber: 1,
        title: 'The Beginning',
        subtitle: 'Testing the Moon before sending humans',
        studentText:
          'Before Apollo, some scientists worried lunar dust might be deep enough to swallow a spaceship. NASA sent robotic Surveyor scouts to test the ground first.',
        scientificText:
          'Managed by JPL and built by Hughes Aircraft, Surveyor 3 tested lunar regolith cohesion, slope stability, and radar-guided soft landing.',
      },
      {
        stageNumber: 2,
        title: 'The Journey',
        subtitle: 'A surprising double bounce on touchdown',
        studentText:
          'Confused radar reflections kept Surveyor 3’s vernier engines firing slightly too long, causing the lander to hop 10 meters high twice before settling gently inside a crater!',
        scientificText:
          'Uncommanded engine thrust during touchdown produced two rebound hops before final rest on a 14-degree inner crater slope.',
      },
      {
        stageNumber: 3,
        title: 'The Mission',
        subtitle: 'Digging trenches and welcoming human visitors',
        studentText:
          'Surveyor 3 dug four small trenches and sent 6,315 pictures in 1967. Two and a half years later, Apollo 12 astronauts walked right up to it and brought its camera home!',
        scientificText:
          'Captured 6,315 TV frames during its first lunar day; in November 1969 Apollo 12 retrieved 10 kg of Surveyor parts for terrestrial materials analysis.',
      },
      {
        stageNumber: 4,
        title: 'The Discoveries',
        subtitle: 'How space changes metal, glass, and paint',
        studentText:
          'Studying Surveyor’s returned camera back on Earth revealed how intense sunlight, micrometeoroids, and lunar dust pit and darken spacecraft surfaces over time.',
        scientificText:
          'Post-retrieval analysis quantified solar-UV paint degradation, micrometeoroid impact flux, and electrostatic lunar dust adhesion.',
      },
      {
        stageNumber: 5,
        title: 'The Legacy',
        subtitle: 'The first off-world hardware ever revisited',
        studentText:
          'Surveyor 3’s camera sits in the Smithsonian National Air and Space Museum today, while the rest of the lander remains in its crater as a monument to teamwork between robots and astronauts.',
        scientificText:
          'Remains the only robotic spacecraft on another planetary body visited and partially recovered by a crewed mission.',
      },
    ],
    components: [
      {
        id: 'soil-scoop',
        name: 'Surface Sampler Scoop',
        role: 'Trenching & soil strength testing',
        studentExplanation: 'A small extending metal claw that dug into the Moon to measure how firm the dust was.',
        scientificExplanation: 'Pantograph-arm mechanical scoop quantifying regolith bearing capacity and cohesive shear resistance.',
      },
      {
        id: 'solar-mast',
        name: 'Articulated Solar & Planar Mast',
        role: 'Daytime electrical power',
        studentExplanation: 'Tilted toward the Sun to power cameras during the two-week lunar day.',
        scientificExplanation: 'Single silicon photovoltaic panel delivering up to 85 W during lunar daylight.',
      },
    ],
    references: [
      { label: 'NASA NSSDC — Surveyor 3', url: 'https://nssdc.gsfc.nasa.gov/nmc/spacecraft/display.action?id=1967-035A' },
    ],
  },
  {
    id: 'sojourner-mars',
    name: 'Sojourner Rover (Mars Pathfinder)',
    missionName: 'Mars Pathfinder',
    missionYear: 1997,
    body: 'Mars',
    category: 'Rover',
    status: 'Mission Completed',
    statusNote: 'Completed mission after operating 12x longer than its 7-sol design life; final signal received Sept 27, 1997.',
    siteName: 'Ares Vallis',
    coordinates: {
      lat: 19.13,
      lon: -33.22,
      label: '19.13° N, 33.22° W',
    },
    launchDate: 'December 4, 1996',
    landingDate: 'July 4, 1997',
    endDate: 'September 27, 1997',
    massKg: 10.6,
    powerSource: 'GaAs solar array + non-rechargeable lithium batteries',
    distanceTraveledKm: 0.1,
    imageUrl: '/src/assets/images/mars_rover_jezero_1794656366254.jpg',
    imageAttribution: 'NASA / JPL-Caltech Mars Pathfinder Archive',
    model3DType: 'mer-rover',
    purposeStudent:
      'A microwave-oven-sized pioneer—the very first wheeled robot ever to drive on Mars, proving rovers could survive Martian cold and rocks.',
    purposeScientific:
      'Technology demonstration microrover testing autonomous hazard avoidance, rocker-bogie mobility, and Alpha Proton X-Ray Spectrometer (APXS) rock chemistry.',
    scientificContribution:
      'Analyzed 16 Martian rocks and soils ("Barnacle Bill", "Yogi") and demonstrated silica-rich volcanic compositions alongside evidence of catastrophic ancient floods in Ares Vallis.',
    whyLeftBehind:
      'Designed as a one-way technology demonstrator powered by solar panels and primary batteries; operations concluded when the Pathfinder base station battery failed in late 1997.',
    thenVsNow: {
      thenCaption: 'July 1997 — Sojourner inspecting rock "Yogi" beside the Pathfinder Carl Sagan Memorial Station.',
      nowCaption: 'Resting stationary at Ares Vallis; mission concluded September 27, 1997.',
      orbitalVerification: 'Mars Reconnaissance Orbiter HiRISE imagery identified the Carl Sagan Memorial Station in Ares Vallis.',
    },
    storyStages: [
      {
        stageNumber: 1,
        title: 'The Beginning',
        subtitle: 'Proving small, fast, low-cost rovers could drive on Mars',
        studentText:
          'Named after abolitionist Sojourner Truth, this tiny 10.6 kg robot was built to show the world that wheeled vehicles could steer themselves around boulders millions of kilometers away.',
        scientificText:
          'NASA JPL designed the Microrover Flight Experiment under the Discovery Program to validate rocker-bogie suspension and autonomous laser-striping hazard detection.',
      },
      {
        stageNumber: 2,
        title: 'The Journey',
        subtitle: 'Bouncing onto Mars inside giant airbags',
        studentText:
          'Instead of heavy rockets, Mars Pathfinder inflated giant tetrahedral airbags and bounced at least 15 times across Ares Vallis before rolling to a stop on July 4, 1997.',
        scientificText:
          'Entry, descent, and landing combined aeroshell deceleration, supersonic parachute, solid retrorockets, and 24-cell Vectran airbags.',
      },
      {
        stageNumber: 3,
        title: 'The Mission',
        subtitle: '83 Martian sols of rock-sniffing science',
        studentText:
          'Expected to last just 7 days, Sojourner rolled down a petal ramp and worked for 83 sols—measuring dust, snapping 550 photos, and nudging up against rocks named Barnacle Bill and Yogi.',
        scientificText:
          'Relayed 550 images and 16 APXS elemental spectra through the Pathfinder lander’s UHF radio link.',
      },
      {
        stageNumber: 4,
        title: 'The Discoveries',
        subtitle: 'An ancient floodplain frozen in time',
        studentText:
          'Rounded pebbles and tilted rocks stacked in one direction showed Ares Vallis was carved long ago by massive floods—proving Mars once had rushing water.',
        scientificText:
          'APXS measurements revealed high-silica andesitic rock signatures and rounded conglomerate pebbles consistent with mega-flood deposition.',
      },
      {
        stageNumber: 5,
        title: 'The Legacy',
        subtitle: 'The tiny ancestor of Spirit, Curiosity, and Perseverance',
        studentText:
          'Every NASA Mars rover driving today uses the same six-wheel rocker-bogie suspension Sojourner pioneered in 1997.',
        scientificText:
          'Validated the mobility architecture directly scaled up for MER (185 kg), MSL Curiosity (899 kg), and Mars 2020 Perseverance (1,025 kg).',
      },
    ],
    components: [
      {
        id: 'apxs',
        name: 'Alpha Proton X-Ray Spectrometer',
        role: 'Rock elemental chemistry',
        studentExplanation: 'Pressed gently against rocks to read what elements—like iron, silicon, and magnesium—they were made of.',
        scientificExplanation: 'Cm-244 alpha-source spectrometer measuring elemental abundances in Martian rocks and regolith.',
      },
      {
        id: 'rocker-bogie',
        name: '6-Wheel Rocker-Bogie Suspension',
        role: 'All-terrain obstacle climbing',
        studentExplanation: 'Clever hinged legs keep all six wheels touching uneven rocks so the little rover wouldn’t tip over.',
        scientificExplanation: 'Differential linkage allowing passive chassis pitch averaging over rocks up to 1.5x wheel diameter.',
      },
    ],
    references: [
      { label: 'NASA Science — Mars Pathfinder / Sojourner', url: 'https://science.nasa.gov/mission/mars-pathfinder/' },
    ],
  },
  {
    id: 'spirit-mer-a',
    name: 'Spirit Rover (MER-A)',
    missionName: 'Mars Exploration Rover — Spirit',
    missionYear: 2004,
    body: 'Mars',
    category: 'Rover',
    status: 'Mission Completed',
    statusNote: 'Completed mission after 2,208 sols (6+ years); final communication March 22, 2010.',
    siteName: 'Gusev Crater (Columbia Hills / Troy)',
    coordinates: {
      lat: -14.5684,
      lon: 175.4726,
      label: '14.5684° S, 175.4726° E',
    },
    launchDate: 'June 10, 2003',
    landingDate: 'January 4, 2004',
    endDate: 'March 22, 2010 (Declared May 25, 2011)',
    massKg: 185,
    powerSource: 'Triple-junction GaInP/GaAs/Ge solar arrays + Li-ion batteries',
    distanceTraveledKm: 7.73,
    imageUrl: '/src/assets/images/mars_rover_jezero_1794656366254.jpg',
    imageAttribution: 'NASA / JPL-Caltech / Cornell',
    model3DType: 'mer-rover',
    purposeStudent:
      'A golf-cart-sized geologist robot that climbed a Martian mountain and discovered buried white silica—a clue that ancient hot springs once bubbled there.',
    purposeScientific:
      'Long-range geological field explorer characterizing volcanic and hydrothermal history inside Gusev Crater.',
    scientificContribution:
      'Discovered pure silica deposits at Home Plate indicative of ancient hydrothermal vents/steam systems, plus carbonate-rich outcrops at Comanche.',
    whyLeftBehind:
      'Mission completed after Spirit’s wheels broke through a crust into soft sulfate sand at "Troy" in 2009, preventing it from tilting its dusty solar arrays toward the winter sun.',
    thenVsNow: {
      thenCaption: '2005 — Spirit ascending Husband Hill inside Gusev Crater.',
      nowCaption: 'Stationary at "Troy" west of Home Plate; mission officially concluded in May 2011.',
      orbitalVerification: 'Observed stationary at Troy in MRO HiRISE orbital surveillance.',
    },
    storyStages: [
      {
        stageNumber: 1,
        title: 'The Beginning',
        subtitle: 'Sending twin robotic field geologists to Mars',
        studentText:
          'After Sojourner proved rovers worked, NASA built twin larger rovers—Spirit and Opportunity—with stereo camera "eyes", rock-grinding tools, and solar wings.',
        scientificText:
          'JPL’s Mars Exploration Rover project packed the Athena science payload (Pancam, Mini-TES, Mössbauer, APXS, Microscopic Imager, RAT) into a 185 kg mobile chassis.',
      },
      {
        stageNumber: 2,
        title: 'The Journey',
        subtitle: 'Landing in a giant ancient lakebed',
        studentText:
          'Spirit bounced to a stop inside Gusev Crater on January 4, 2004. At first, scientists saw mostly volcanic lava rocks—until Spirit drove miles toward the Columbia Hills.',
        scientificText:
          'Launched on a Delta II 7925, MER-A survived 19-g airbag deceleration and began a 3.6 km trek from Bonneville Crater to the Columbia Hills.',
      },
      {
        stageNumber: 3,
        title: 'The Mission',
        subtitle: 'Six years on a 90-day warranty',
        studentText:
          'Even after its front right wheel jammed in 2006, Spirit simply turned around and drove backward for kilometers—dragging the broken wheel and accidentally churning up bright white treasure!',
        scientificText:
          'Operating 24 times beyond its nominal 90-sol baseline, Spirit overcame flash-memory anomalies and wheel actuator failure to traverse 7.73 km.',
      },
      {
        stageNumber: 4,
        title: 'The Discoveries',
        subtitle: 'Hot springs and steam vents on ancient Mars',
        studentText:
          'That jammed wheel scraped open bright white silica soil at "Home Plate"—evidence of ancient steam vents or hot springs where tiny microbes could once have lived.',
        scientificText:
          'Exposed >90% pure opaline silica and magnesium-iron carbonates, demonstrating past hydrothermal activity and neutral-pH water interaction.',
      },
      {
        stageNumber: 5,
        title: 'The Legacy',
        subtitle: 'Still inspiring Mars exploration from Troy',
        studentText:
          'In 2009 Spirit got stuck in soft hidden sand and went to sleep during the freezing Martian winter of 2010—leaving behind a rich map of habitable ancient environments.',
        scientificText:
          'Spirit’s Columbia Hills data makes Gusev Crater a continuing candidate site for astrobiological biosignature research.',
      },
    ],
    components: [
      {
        id: 'pancam-mast',
        name: 'Pancam & Mini-TES Mast',
        role: 'Stereo color & infrared imaging',
        studentExplanation: 'Stands at human eye height so scientists see Mars in 3D color and spot minerals from afar.',
        scientificExplanation: '14-filter panoramic stereo cameras paired with a Miniature Thermal Emission Spectrometer.',
      },
      {
        id: 'mer-solar-wings',
        name: 'Fold-Out Solar Wing Deck',
        role: 'Power generation',
        studentExplanation: 'Captured Martian sunlight; Martian dust devils occasionally blew the panels clean, extending life for years!',
        scientificExplanation: '1.3 m² triple-junction solar array generating ~140 W at Mars noon when dust-free.',
      },
      {
        id: 'rat-arm',
        name: 'Instrument Deployment Arm & RAT',
        role: 'Brushing & grinding rock surfaces',
        studentExplanation: 'A robotic wrist carrying a diamond-tipped Rock Abrasion Tool to peek underneath dusty rock skins.',
        scientificExplanation: '5-DOF arm mounting APXS, Mössbauer spectrometer, Microscopic Imager, and Rock Abrasion Tool.',
      },
    ],
    references: [
      { label: 'NASA Science — Spirit Rover', url: 'https://science.nasa.gov/mission/mer-spirit/' },
    ],
  },
  {
    id: 'opportunity-mer-b',
    name: 'Opportunity Rover (MER-B)',
    missionName: 'Mars Exploration Rover — Opportunity',
    missionYear: 2004,
    body: 'Mars',
    category: 'Rover',
    status: 'Mission Completed',
    statusNote: 'Completed mission after 14+ years and 45.16 km driven; concluded Feb 13, 2019 after 2018 global dust storm.',
    siteName: 'Meridiani Planum (Perseverance Valley)',
    coordinates: {
      lat: -1.9462,
      lon: 354.4734,
      label: '1.9462° S, 354.4734° E',
    },
    launchDate: 'July 7, 2003',
    landingDate: 'January 25, 2004',
    endDate: 'June 10, 2018 (Concluded Feb 13, 2019)',
    massKg: 185,
    powerSource: 'Triple-junction solar arrays + Li-ion batteries',
    distanceTraveledKm: 45.16,
    imageUrl: '/src/assets/images/mars_rover_jezero_1794656366254.jpg',
    imageAttribution: 'NASA / JPL-Caltech / Cornell',
    model3DType: 'mer-rover',
    purposeStudent:
      'Spirit’s twin rover, which drove a marathon distance of 45.16 kilometers across Mars—more than any other off-world vehicle—before a massive dust storm darkened the sky in 2018.',
    purposeScientific:
      'Surface mineralogy and paleoclimate rover dispatched to Meridiani Planum to investigate orbital hematite detections.',
    scientificContribution:
      'Found spherical hematite concretions ("blueberries"), sulfate-rich evaporites, and Endeavour Crater clay minerals proving long-lived liquid water existed at Meridiani.',
    whyLeftBehind:
      'Mission concluded in February 2019 after a planet-encircling dust storm in June 2018 blocked sunlight for months, draining Opportunity’s batteries beyond recovery.',
    thenVsNow: {
      thenCaption: '2004 — Rolled out inside Eagle Crater, discovering layered bedrock on day one.',
      nowCaption: 'Resting inside Perseverance Valley on the rim of Endeavour Crater.',
      orbitalVerification: 'MRO HiRISE photographed Opportunity at its final resting spot in Perseverance Valley.',
    },
    storyStages: [
      {
        stageNumber: 1,
        title: 'The Beginning',
        subtitle: 'Chasing an iron mineral spotted from orbit',
        studentText:
          'Orbiting spacecraft spotted gray hematite—a mineral that usually forms in water—at a flat plain called Meridiani Planum. Opportunity was sent to find out how it got there.',
        scientificText:
          'Selected for smooth terrain and Thermal Emission Spectrometer hematite signatures indicating possible aqueous alteration.',
      },
      {
        stageNumber: 2,
        title: 'The Journey',
        subtitle: 'A hole-in-one landing inside Eagle Crater',
        studentText:
          'Opportunity’s airbags rolled right into a small crater—giving scientists exposed bedrock layers just meters away from the lander on its very first day!',
        scientificText:
          'Achieved an unplanned "interplanetary hole-in-one" inside 22-meter Eagle Crater, immediately exposing cross-bedded sedimentary outcrops.',
      },
      {
        stageNumber: 3,
        title: 'The Mission',
        subtitle: '5,111 sols and an off-world distance record',
        studentText:
          'Built for 90 days, Opportunity kept exploring for nearly 15 years—visiting Endurance, Victoria, and giant 22-kilometer Endeavour Crater.',
        scientificText:
          'Logged 45.16 km over 5,111 operational sols, overcoming steering-actuator and flash-memory aging through software workarounds.',
      },
      {
        stageNumber: 4,
        title: 'The Discoveries',
        subtitle: 'Martian "blueberries" and drinkable ancient water',
        studentText:
          'Tiny round pebbles nicknamed "blueberries" formed inside wet rock, and clay minerals at Endeavour Crater showed Mars once had mild, near-neutral water suitable for life.',
        scientificText:
          'Jarosite, cross-bedded sulfate sandstones, and smectite clays recorded a transition from neutral groundwater to acidic evaporative playas.',
      },
      {
        stageNumber: 5,
        title: 'The Legacy',
        subtitle: 'A marathon champion resting in Perseverance Valley',
        studentText:
          'When a planet-wide dust storm blotted out the Sun in 2018, Opportunity sent its final data packet and stood silent in Perseverance Valley—leaving behind 217,000+ historic Mars images.',
        scientificText:
          'Delivered 217,594 raw images and set the extraterrestrial driving record (45.16 km), transforming Mars into a proven once-wet world.',
      },
    ],
    components: [
      {
        id: 'opp-pancam',
        name: 'Pancam Stereo Mast',
        role: 'Geological & atmospheric imaging',
        studentExplanation: 'Captured over 217,000 photos of Martian craters, dunes, and solar eclipses.',
        scientificExplanation: 'Dual-eye multispectral camera system (430–1010 nm) used for geologic mapping and optical dust opacity tracking.',
      },
      {
        id: 'opp-wheels',
        name: '25 cm Cleated Aluminum Wheels',
        role: '45.16 km marathon mobility',
        studentExplanation: 'Carried Opportunity farther than a marathon across sand ripples and rocky crater rims.',
        scientificExplanation: 'Six individually driven anodized aluminum wheels with spiral-flexure shock absorption.',
      },
    ],
    references: [
      { label: 'NASA Science — Opportunity Rover', url: 'https://science.nasa.gov/mission/mer-opportunity/' },
    ],
  },
  {
    id: 'insight-mars',
    name: 'InSight Mars Lander',
    missionName: 'InSight (Interior Exploration using Seismic Investigations)',
    missionYear: 2018,
    body: 'Mars',
    category: 'Lander',
    status: 'Mission Completed',
    statusNote: 'Completed mission in December 2022 after Martian dust covered its solar panels.',
    siteName: 'Elysium Planitia',
    coordinates: {
      lat: 4.5024,
      lon: 135.6234,
      label: '4.5024° N, 135.6234° E',
    },
    launchDate: 'May 5, 2018',
    landingDate: 'November 26, 2018',
    endDate: 'December 21, 2022',
    massKg: 358,
    powerSource: 'Two 2.15 m decagonal UltraFlex solar arrays',
    imageUrl: '/src/assets/images/mars_rover_jezero_1794656366254.jpg',
    imageAttribution: 'NASA / JPL-Caltech',
    model3DType: 'insight-lander',
    purposeStudent:
      'A stationary "planet doctor" that stayed in one spot on Mars with a super-sensitive stethoscope (seismometer) to listen to marsquakes and measure what is inside the planet.',
    purposeScientific:
      'Discovery-class geophysical lander measuring Martian seismic waves, crustal thickness, mantle structure, core radius, and planetary wobble.',
    scientificContribution:
      'Detected 1,319+ marsquakes (including meteoroid impacts exposing subsurface water-ice near the equator) and measured Mars’s liquid iron-alloy core (~1,830 km radius).',
    whyLeftBehind:
      'Stationary geophysical lander; mission ended cleanly in December 2022 when thick atmospheric dust reduced solar array power below survival thresholds.',
    thenVsNow: {
      thenCaption: 'December 2018 — Clean solar panels shortly after deploying the SEIS dome onto Martian soil.',
      nowCaption: 'Dust-coated solar panels visible from orbit; mission concluded December 2022.',
      orbitalVerification: 'MRO HiRISE tracked gradual red dust accumulation on InSight’s two circular arrays from 2018 to 2022.',
    },
    storyStages: [
      {
        stageNumber: 1,
        title: 'The Beginning',
        subtitle: 'Checking Mars’s pulse for the first time',
        studentText:
          'Rovers studied Mars’s surface, but nobody had measured its deep interior. NASA sent InSight to stay completely still and listen for underground rumbles.',
        scientificText:
          'Built on the Phoenix lander heritage by Lockheed Martin and JPL with European SEIS (CNES) and HP3 (DLR) geophysical instruments.',
      },
      {
        stageNumber: 2,
        title: 'The Journey',
        subtitle: 'Touchdown in the quiet plains of Elysium',
        studentText:
          'InSight landed on flat, quiet volcanic plains so wind noise wouldn’t drown out faint underground tremors, then used a robotic arm to place a domed seismometer gently on the dirt.',
        scientificText:
          'Precision propulsive touchdown in Elysium Planitia followed by the first robotic placement of a seismometer directly onto another planet’s surface.',
      },
      {
        stageNumber: 3,
        title: 'The Mission',
        subtitle: 'Listening to over 1,300 marsquakes',
        studentText:
          'For four years, InSight felt marsquakes—even a magnitude 4.7 rumble—and recorded the seismic shockwaves of fresh meteoroids crashing thousands of miles away.',
        scientificText:
          'Recorded 1,319 seismic events and continuous barometric/magnetic telemetry, while RISE radio tracking measured Mars’s nutation.',
      },
      {
        stageNumber: 4,
        title: 'The Discoveries',
        subtitle: 'Mapping Mars’s crust, mantle, and liquid core',
        studentText:
          'InSight revealed that Mars has a big liquid metal core and a crust roughly 24 to 72 kilometers thick—helping explain how rocky planets form and cool down.',
        scientificText:
          'Core-reflected S-waves constrained a liquid iron-alloy core (~1,830 km radius enriched in light elements) and a 39–72 km layered crust.',
      },
      {
        stageNumber: 5,
        title: 'The Legacy',
        subtitle: 'A dusty solar sentinel after a historic checkup',
        studentText:
          'Before losing power in December 2022, InSight sent one last dusty selfie. Scientists still use its Mars interior measurements every day.',
        scientificText:
          'Established the foundational interior reference model of Mars against which Earth and lunar geophysics are compared.',
      },
    ],
    components: [
      {
        id: 'seis-dome',
        name: 'SEIS Seismometer & Wind Shield',
        role: 'Sub-atomic ground motion sensing',
        studentExplanation: 'A white dome covers ultra-sensitive sensors so Martian wind gusts don’t fool the quake detector.',
        scientificExplanation: 'Three-axis Very Broad Band (VBB) vacuum-enclosed seismometer shielded by a titanium-alloy Wind and Thermal Shield.',
      },
      {
        id: 'ultraflex-arrays',
        name: 'Circular UltraFlex Solar Arrays',
        role: 'Lander power generation',
        studentExplanation: 'Two fan-like round solar wings opened like folding fans after landing.',
        scientificExplanation: 'Dual 2.15 m decagonal arrays delivering ~600–700 W-hours per sol at clean deployment.',
      },
      {
        id: 'ida-arm',
        name: 'Instrument Deployment Arm',
        role: 'Precision ground placement',
        studentExplanation: 'Lifted SEIS off the lander deck and set it carefully onto the Martian soil.',
        scientificExplanation: '2.4 m 4-DOF robotic arm with five-fingered grapple and IDC camera.',
      },
    ],
    references: [
      { label: 'NASA Science — InSight Lander', url: 'https://science.nasa.gov/mission/insight/' },
    ],
  },
  {
    id: 'curiosity-msl',
    name: 'Curiosity Rover (Mars Science Laboratory)',
    missionName: 'Mars Science Laboratory (Curiosity)',
    missionYear: 2012,
    body: 'Mars',
    category: 'Rover',
    status: 'Active Operational',
    statusNote: 'Actively operating in Gale Crater / Mount Sharp (NOT abandoned). Powered by nuclear MMRTG.',
    siteName: 'Gale Crater (Mount Sharp)',
    coordinates: {
      lat: -4.5895,
      lon: 137.4417,
      label: '4.5895° S, 137.4417° E',
    },
    launchDate: 'November 26, 2011',
    landingDate: 'August 6, 2012',
    endDate: 'Active Operational (2012–Present)',
    massKg: 899,
    powerSource: 'MMRTG (Plutonium-238 nuclear battery)',
    distanceTraveledKm: 33,
    imageUrl: '/src/assets/images/mars_rover_jezero_1794656366254.jpg',
    imageAttribution: 'NASA / JPL-Caltech / MSSS',
    model3DType: 'msl-rover',
    purposeStudent:
      'A car-sized nuclear chemistry lab currently climbing Mount Sharp inside Gale Crater—still actively working today to study whether ancient Mars could have supported microbial life.',
    purposeScientific:
      'Active Mars Science Laboratory investigating past habitability, organic carbon preservation, and climate transition across Mount Sharp stratigraphy.',
    scientificContribution:
      'Confirmed Gale Crater held persistent freshwater lakes for millions of years, detected organic carbon molecules in mudstone, and measured seasonal methane variations.',
    whyLeftBehind:
      'NOT abandoned—Curiosity is an active, functioning NASA laboratory transmitting scientific data and climbing Mount Sharp every week.',
    thenVsNow: {
      thenCaption: 'August 2012 — Sky-crane touchdown on Bradbury Landing inside Gale Crater.',
      nowCaption: 'Currently ascending sulfate-bearing strata on Mount Sharp, over 33 km driven.',
      orbitalVerification: 'Ongoing MRO HiRISE tracking confirms active traverse up Gediz Vallis and Mount Sharp.',
    },
    storyStages: [
      {
        stageNumber: 1,
        title: 'The Beginning',
        subtitle: 'Building a rolling chemistry laboratory for Mars',
        studentText:
          'Earlier rovers relied on sunshine, which dust storms could block. For Curiosity, NASA built an SUV-sized rover powered by a nuclear battery so it could explore day and night.',
        scientificText:
          'MSL integrated 10 science instruments—including SAM gas chromatograph/mass spectrometer and CheMin X-ray diffraction—into an 899 kg rover.',
      },
      {
        stageNumber: 2,
        title: 'The Journey',
        subtitle: 'The daring Sky Crane touchdown',
        studentText:
          'Because Curiosity was too heavy for airbags, a rocket-powered flying backpack hovered above Mars and lowered the rover onto its wheels on nylon tethers!',
        scientificText:
          'Guided entry and sky-crane terminal descent delivered MSL within 2.4 km of its target ellipse in Gale Crater on August 6, 2012.',
      },
      {
        stageNumber: 3,
        title: 'The Mission',
        subtitle: 'Twelve-plus years of drilling Mount Sharp',
        studentText:
          'Curiosity shoots lasers at rocks with ChemCam, drills gray powder out of ancient lakebeds, and bakes samples inside tiny ovens on its belly.',
        scientificText:
          'Continuously climbing the 5-km central peak Aeolis Mons (Mount Sharp) to read Mars’s transition from wet clays to arid sulfates.',
      },
      {
        stageNumber: 4,
        title: 'The Discoveries',
        subtitle: 'Proof of a habitable ancient lake environment',
        studentText:
          'At Yellowknife Bay, Curiosity drilled mudstone containing all the basic chemical ingredients needed for life—carbon, hydrogen, nitrogen, oxygen, phosphorus, and sulfur—plus gentle water.',
        scientificText:
          'Identified habitable fluvio-lacustrine mudstones, indigenous organic sulfur/carbon compounds, and ancient 3.5-billion-year-old clay-sulfate climate transitions.',
      },
      {
        stageNumber: 5,
        title: 'The Legacy',
        subtitle: 'An active explorer still writing new chapters',
        studentText:
          'Curiosity is not abandoned—it is actively driving, drilling, and inspiring missions today while paving the engineering road for Perseverance.',
        scientificText:
          'Remains an active flagship asset of NASA’s Mars Exploration Program with ongoing discoveries in Gediz Vallis.',
      },
    ],
    components: [
      {
        id: 'mmrtg',
        name: 'MMRTG Nuclear Power Source',
        role: 'All-weather continuous electricity',
        studentExplanation: 'Turns heat from plutonium into steady electricity so dust storms never shut Curiosity down.',
        scientificExplanation: 'Multi-Mission Radioisotope Thermoelectric Generator producing ~110 W electric at launch plus waste-heat thermal control.',
      },
      {
        id: 'chemcam',
        name: 'ChemCam Laser Mast',
        role: 'Remote elemental spectroscopy',
        studentExplanation: 'Fires an invisible laser beam up to 7 meters away to vaporize tiny specks of rock and read their colors.',
        scientificExplanation: 'Laser-Induced Breakdown Spectroscopy (LIBS) plus Remote Micro-Imager mounted atop the Mastcam head.',
      },
      {
        id: 'sample-arm',
        name: 'Rotary Percussive Drill Arm',
        role: 'Powdered rock sampling',
        studentExplanation: 'Drills into solid Martian stone and scoops rock dust into Curiosity’s internal chemistry labs.',
        scientificExplanation: '2.1 m 5-DOF turret carrying rotary drill, MAHLI hand-lens imager, APXS, and CHIMRA sample processor.',
      },
    ],
    references: [
      { label: 'NASA Science — Curiosity Rover', url: 'https://science.nasa.gov/mission/msl-curiosity/' },
    ],
  },
  {
    id: 'perseverance-mars2020',
    name: 'Perseverance Rover (Mars 2020)',
    missionName: 'Mars 2020 (Perseverance & Ingenuity)',
    missionYear: 2021,
    body: 'Mars',
    category: 'Rover',
    status: 'Active Operational',
    statusNote: 'Actively operating in Jezero Crater (NOT abandoned). Companion Ingenuity Helicopter retired Jan 2024 after 72 flights.',
    siteName: 'Jezero Crater',
    coordinates: {
      lat: 18.38,
      lon: 77.58,
      label: '18.38° N, 77.58° E',
    },
    launchDate: 'July 30, 2020',
    landingDate: 'February 18, 2021',
    endDate: 'Active Operational (2021–Present)',
    massKg: 1025,
    powerSource: 'MMRTG (Plutonium-238 nuclear battery)',
    distanceTraveledKm: 30,
    imageUrl: '/src/assets/images/mars_rover_jezero_1794656366254.jpg',
    imageAttribution: 'NASA / JPL-Caltech / ASU / MSSS',
    model3DType: 'msl-rover',
    purposeStudent:
      'NASA’s newest active Mars rover—currently exploring an ancient river delta in Jezero Crater, sealing rock cores into titanium tubes for future return to Earth, and testing oxygen production.',
    purposeScientific:
      'Active astrobiology and Mars sample-caching mission investigating Jezero Crater delta sediments, plus technology demonstrations (MOXIE & Ingenuity).',
    scientificContribution:
      'Confirmed Jezero Crater’s lake-delta history, produced breathable oxygen from Martian CO2 via MOXIE, cached sealed rock cores, and supported Ingenuity’s 72 powered flights.',
    whyLeftBehind:
      'NOT abandoned—Perseverance is actively operating on Mars today. Its partner rotorcraft Ingenuity completed 72 historic flights before retiring on the surface in January 2024 due to rotor blade damage.',
    thenVsNow: {
      thenCaption: 'February 2021 — Touchdown in Jezero Crater captured in high-definition sky-crane video.',
      nowCaption: 'Actively ascending the Jezero Crater rim while Ingenuity rests at "Valinor Hills".',
      orbitalVerification: 'Tracked continuously by MRO HiRISE and Mars Odyssey orbital relays.',
    },
    storyStages: [
      {
        stageNumber: 1,
        title: 'The Beginning',
        subtitle: 'Hunting ancient biosignatures and caching samples',
        studentText:
          'Curiosity proved Mars could once support life; Perseverance was built to take the next leap—looking for signs of ancient microbes and packing rock cores into ultra-clean tubes.',
        scientificText:
          'Mars 2020 upgraded MSL’s chassis with Terrain Relative Navigation, thicker aluminum wheels, UV/Raman spectrometers (SHERLOC, PIXL), and an adaptive caching system.',
      },
      {
        stageNumber: 2,
        title: 'The Journey',
        subtitle: 'Smart-vision landing in a boulder-strewn crater',
        studentText:
          'During descent, Perseverance’s computer photographed the ground below and steered itself away from cliffs and sand traps to land safely in Jezero Crater.',
        scientificText:
          'Terrain Relative Navigation matched real-time descent imagery against orbital hazard maps to execute precision sky-crane touchdown.',
      },
      {
        stageNumber: 3,
        title: 'The Mission',
        subtitle: 'Driving the river delta alongside the first Mars helicopter',
        studentText:
          'Perseverance carried the small solar helicopter Ingenuity—which flew 72 times instead of 5! Meanwhile, Perseverance’s MOXIE box turned thin Mars air into pure oxygen.',
        scientificText:
          'Conducted synchronized ground-aerial reconnaissance with Ingenuity (72 flights, 17.0 km) while drilling and hermetically sealing rock core tubes.',
      },
      {
        stageNumber: 4,
        title: 'The Discoveries',
        subtitle: 'Volcanic floor, ancient river delta, and organic chemistry',
        studentText:
          'Perseverance found igneous rocks transformed by water on the crater floor, explored layered river-delta mudstones, and spotted leopard-spot mineral patterns of intense scientific interest.',
        scientificText:
          'PIXL and SHERLOC identified aqueous mineral alteration, organic-bearing mudstones at Bright Angel, and oxygen electrolysis viability via MOXIE.',
      },
      {
        stageNumber: 5,
        title: 'The Legacy',
        subtitle: 'Active today—bridging Mars to future human explorers',
        studentText:
          'Perseverance is actively exploring Mars right now, building a library of sealed rock cores while Ingenuity rests as a permanent pioneer of off-world aviation.',
        scientificText:
          'Active flagship Mars explorer demonstrating ISRU oxygen production and preparing geological samples for eventual laboratory analysis.',
      },
    ],
    components: [
      {
        id: 'corer-turret',
        name: 'Coring Drill & Sample Caching System',
        role: 'Sealing Mars cores in titanium tubes',
        studentExplanation: 'Drills finger-sized rock cylinders and seals them cleanly inside numbered metal tubes.',
        scientificExplanation: 'Percussive corer paired with an internal Sample Handling Arm that hermetically seals ultra-clean titanium tubes.',
      },
      {
        id: 'moxie-unit',
        name: 'MOXIE Oxygen Experiment',
        role: 'In-Situ Resource Utilization (ISRU)',
        studentExplanation: 'Breathed in poisonous carbon dioxide Mars air and turned it into real breathable oxygen!',
        scientificExplanation: 'Solid-oxide electrolysis unit generating up to 12 g/hr of >98% pure O2 from Martian atmospheric CO2.',
      },
      {
        id: 'supercam-head',
        name: 'SuperCam & Mastcam-Z Head',
        role: 'Zoom imaging, laser & Mars microphone',
        studentExplanation: 'Zooms in on distant cliffs, zaps rocks with a laser, and even records real Martian wind audio.',
        scientificExplanation: 'Zoomable stereo camera suite, LIBS/Raman/IR spectroscopy, and acoustic microphone.',
      },
    ],
    references: [
      { label: 'NASA Science — Perseverance Rover', url: 'https://science.nasa.gov/mission/mars-2020/' },
      { label: 'NASA Science — Ingenuity Mars Helicopter', url: 'https://science.nasa.gov/mission/ingenuity/' },
    ],
  },
];

export const TIMELINE_MILESTONES: TimelineMilestone[] = [
  {
    id: 'tl-1967',
    year: 1967,
    missionName: 'Surveyor 3',
    destination: 'Moon',
    achievement: 'First robotic trenching of lunar regolith, proving safe bearing strength for Apollo landers.',
    equipment: 'Surveyor 3 Lander & Surface Scoop',
    status: 'Mission Completed',
    referenceUrl: 'https://nssdc.gsfc.nasa.gov/nmc/spacecraft/display.action?id=1967-035A',
  },
  {
    id: 'tl-1969-a11',
    year: 1969,
    missionName: 'Apollo 11',
    destination: 'Moon',
    achievement: 'First crewed lunar landing; Eagle descent stage left at Tranquility Base with EASEP sensors.',
    equipment: 'LM-5 Eagle Descent & Ascent Stages',
    status: 'Intentionally Left Behind',
    referenceUrl: 'https://science.nasa.gov/mission/apollo-11/',
  },
  {
    id: 'tl-1969-a12',
    year: 1969,
    missionName: 'Apollo 12',
    destination: 'Moon',
    achievement: 'Pinpoint landing beside Surveyor 3 and deployment of nuclear-powered ALSEP observatory.',
    equipment: 'Apollo 12 ALSEP & SNAP-27 RTG',
    status: 'Intentionally Left Behind',
    referenceUrl: 'https://science.nasa.gov/mission/apollo-12/',
  },
  {
    id: 'tl-1971',
    year: 1971,
    missionName: 'Apollo 15',
    destination: 'Moon',
    achievement: 'First Lunar Roving Vehicle traversed 27.9 km across Hadley-Apennine, collecting Genesis Rock.',
    equipment: 'Lunar Roving Vehicle (LRV-1)',
    status: 'Intentionally Left Behind',
    referenceUrl: 'https://science.nasa.gov/mission/apollo-15/',
  },
  {
    id: 'tl-1997',
    year: 1997,
    missionName: 'Mars Pathfinder',
    destination: 'Mars',
    achievement: 'First wheeled rover on Mars; analyzed flood-deposited rocks across Ares Vallis for 83 sols.',
    equipment: 'Sojourner Rover',
    status: 'Mission Completed',
    referenceUrl: 'https://science.nasa.gov/mission/mars-pathfinder/',
  },
  {
    id: 'tl-2004-spirit',
    year: 2004,
    missionName: 'Mars Exploration Rover — Spirit',
    destination: 'Mars',
    achievement: 'Climbed Columbia Hills and uncovered silica evidence of ancient hydrothermal springs.',
    equipment: 'Spirit Rover (MER-A)',
    status: 'Mission Completed',
    referenceUrl: 'https://science.nasa.gov/mission/mer-spirit/',
  },
  {
    id: 'tl-2004-opp',
    year: 2004,
    missionName: 'Mars Exploration Rover — Opportunity',
    destination: 'Mars',
    achievement: 'Set 45.16 km off-world driving record over 14+ years, confirming liquid water history.',
    equipment: 'Opportunity Rover (MER-B)',
    status: 'Mission Completed',
    referenceUrl: 'https://science.nasa.gov/mission/mer-opportunity/',
  },
  {
    id: 'tl-2012',
    year: 2012,
    missionName: 'Mars Science Laboratory',
    destination: 'Mars',
    achievement: 'Sky-crane touchdown in Gale Crater; confirmed ancient habitable lakes and organic molecules.',
    equipment: 'Curiosity Rover',
    status: 'Active Operational',
    referenceUrl: 'https://science.nasa.gov/mission/msl-curiosity/',
  },
  {
    id: 'tl-2018',
    year: 2018,
    missionName: 'InSight Lander',
    destination: 'Mars',
    achievement: 'Detected 1,319+ marsquakes and measured Mars’s crust, mantle, and liquid core for the first time.',
    equipment: 'InSight Lander & SEIS Seismometer',
    status: 'Mission Completed',
    referenceUrl: 'https://science.nasa.gov/mission/insight/',
  },
  {
    id: 'tl-2021',
    year: 2021,
    missionName: 'Mars 2020',
    destination: 'Mars',
    achievement: 'Active Jezero Crater core caching, MOXIE oxygen test, and Ingenuity’s 72 aerial flights.',
    equipment: 'Perseverance Rover & Ingenuity',
    status: 'Active Operational',
    referenceUrl: 'https://science.nasa.gov/mission/mars-2020/',
  },
];

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 'q1',
    question: 'Which mission first landed humans on the Moon in July 1969?',
    options: ['Apollo 8', 'Apollo 11', 'Apollo 12', 'Surveyor 3'],
    correctIndex: 1,
    explanation:
      'Apollo 11 landed Lunar Module Eagle on the Sea of Tranquility on July 20, 1969, with Neil Armstrong and Buzz Aldrin.',
    sourceLabel: 'NASA Apollo 11 Mission',
    sourceUrl: 'https://science.nasa.gov/mission/apollo-11/',
  },
  {
    id: 'q2',
    question: 'Why did NASA leave the Apollo Lunar Module Descent Stage on the Moon?',
    options: [
      'Its solar panels broke during landing',
      'It was too toxic to enter Earth’s atmosphere',
      'It served as the launch pad so the lighter Ascent Stage had enough fuel to return to lunar orbit',
      'Astronauts forgot to retract the landing legs',
    ],
    correctIndex: 2,
    explanation:
      'Saving mass was critical. Leaving the heavy Descent Stage, landing gear, and empty tanks behind allowed the Ascent Stage to launch back to Command Module Columbia.',
    sourceLabel: 'NASA NSSDC — Eagle',
    sourceUrl: 'https://nssdc.gsfc.nasa.gov/nmc/spacecraft/display.action?id=1969-059C',
  },
  {
    id: 'q3',
    question: 'What was the main purpose of the Apollo Lunar Roving Vehicle (LRV)?',
    options: [
      'To carry astronauts back to Earth',
      'To drill 100 meters deep for liquid water',
      'To extend astronauts’ exploration range across kilometers of rugged lunar terrain',
      'To launch satellites from the Moon',
    ],
    correctIndex: 2,
    explanation:
      'Introduced on Apollo 15, the electric LRV expanded exploration from short walking loops to 27.9–35.9 km geological traverses carrying crew, tools, and samples.',
    sourceLabel: 'NASA Apollo 15 LRV',
    sourceUrl: 'https://science.nasa.gov/mission/apollo-15/',
  },
  {
    id: 'q4',
    question: 'Which NASA Mars rovers explored Mars before Curiosity landed in 2012?',
    options: [
      'Perseverance and InSight',
      'Sojourner, Spirit, and Opportunity',
      'Surveyor 3 and Viking 1',
      'Curiosity was the very first rover on Mars',
    ],
    correctIndex: 1,
    explanation:
      'Sojourner (1997) was Mars’s first rover, followed by the twin rovers Spirit and Opportunity in January 2004—eight years before Curiosity landed in 2012.',
    sourceLabel: 'NASA Mars Exploration',
    sourceUrl: 'https://science.nasa.gov/mars/',
  },
  {
    id: 'q5',
    question: 'Which NASA Mars rovers remain active and operational on Mars today?',
    options: [
      'Spirit and Opportunity',
      'Sojourner and InSight',
      'Curiosity and Perseverance',
      'All five Mars rovers are still driving',
    ],
    correctIndex: 2,
    explanation:
      'Curiosity (landed 2012) and Perseverance (landed 2021) run on nuclear MMRTG power and remain active today, whereas Sojourner, Spirit, and Opportunity have completed their missions.',
    sourceLabel: 'NASA Mars Exploration',
    sourceUrl: 'https://science.nasa.gov/mars/',
  },
  {
    id: 'q6',
    question: 'What scientific purpose did NASA’s stationary InSight Mars lander serve?',
    options: [
      'Driving across Jezero Crater’s river delta',
      'Measuring marsquakes and Mars’s crust, mantle, and core structure',
      'Collecting lunar basalt rocks for Apollo 12',
      'Flying 72 aerial scouting missions',
    ],
    correctIndex: 1,
    explanation:
      'InSight stayed in one spot at Elysium Planitia and used its SEIS seismometer to detect 1,319+ marsquakes, revealing the size of Mars’s liquid core and crust.',
    sourceLabel: 'NASA InSight Mission',
    sourceUrl: 'https://science.nasa.gov/mission/insight/',
  },
];

export const FALLBACK_NASA_MEDIA: NasaMediaItem[] = [
  {
    nasaId: 'AS11-40-5903',
    title: 'Apollo 11 Lunar Module Eagle at Tranquility Base',
    description:
      'Historic Apollo 11 photograph showing the gold-wrapped Eagle Descent Stage and Buzz Aldrin beside the Passive Seismic Experiment Package.',
    dateCreated: '1969-07-20',
    center: 'JSC',
    imageUrl: '/src/assets/images/apollo_lunar_module_museum_1794656365730.jpg',
    nasaUrl: 'https://images.nasa.gov/details/as11-40-5903',
  },
  {
    nasaId: 'AS15-82-11122',
    title: 'Apollo 15 Lunar Roving Vehicle at Hadley-Apennine',
    description:
      'Lunar Roving Vehicle LRV-1 photographed during Apollo 15 geological traverse near Hadley Rille.',
    dateCreated: '1971-08-01',
    center: 'JSC',
    imageUrl: '/src/assets/images/lunar_roving_vehicle_1794656366444.jpg',
    nasaUrl: 'https://images.nasa.gov/details/as15-82-11122',
  },
  {
    nasaId: 'PIA24542',
    title: 'Perseverance Rover in Jezero Crater',
    description:
      'NASA Mars 2020 Perseverance rover exploring sedimentary deposits inside Jezero Crater.',
    dateCreated: '2021-03-04',
    center: 'JPL',
    imageUrl: '/src/assets/images/mars_rover_jezero_1794656366254.jpg',
    nasaUrl: 'https://images.nasa.gov/details/PIA24542',
  },
  {
    nasaId: 'ISS-HORIZON-2026',
    title: 'Orbital Sunrise Over Earth Horizon',
    description:
      'Reference orbital vista illustrating spaceflight perspective and planetary observation heritage.',
    dateCreated: '2024-02-12',
    center: 'JSC',
    imageUrl: '/src/assets/images/hero_orbital_horizon_1794655338444.jpg',
    nasaUrl: 'https://images.nasa.gov/',
  },
];
