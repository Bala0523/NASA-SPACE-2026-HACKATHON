import dotenv from 'dotenv';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';
import { createServer as createViteServer } from 'vite';
import { FALLBACK_NASA_MEDIA, SPACE_ARTIFACTS } from './src/data/spaceEquipment';
import { matchAstraKnowledge } from './src/utils/museumLogic';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;

const VERIFIED_SYSTEM_CONTEXT = SPACE_ARTIFACTS.map(
  (a) =>
    `- ${a.name} (${a.missionName}, ${a.missionYear}, ${a.body}, ${a.status}): ${a.purposeScientific} Why left/status: ${a.whyLeftBehind} Contribution: ${a.scientificContribution}`,
).join('\n');

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  app.post('/api/astra', async (req, res) => {
    const question =
      typeof req.body?.question === 'string' ? req.body.question.trim() : '';
    const learningMode =
      req.body?.learningMode === 'scientific' ? 'scientific' : 'student';

    if (!question) {
      res.status(400).json({ error: 'Please provide a question for ASTRA.' });
      return;
    }

    const apiKey = process.env.GEMINI_API_KEY?.trim();

    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      const kbMatch = matchAstraKnowledge(question);
      res.json({
        answer: kbMatch.answer,
        sources: kbMatch.sources,
        mode: 'verified-knowledge-base',
      });
      return;
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);

    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const audienceRule =
        learningMode === 'student'
          ? 'Explain concepts clearly for middle and high school students without sacrificing scientific accuracy.'
          : 'Provide rigorous aerospace engineering and planetary science detail suitable for advanced learners.';

      const systemInstruction = `You are ASTRA, the Space Exploration Guide for SpaceTime Explorer (a NASA Space Apps Challenge 2026 digital space museum).
${audienceRule}

Strict factual rules:
1. Only state verified NASA mission facts. Never invent dates, coordinates, or discoveries.
2. Always distinguish between equipment intentionally left behind (e.g., Apollo Descent Stages, ALSEP, LRV), discarded orbital stages (e.g., Apollo 11 Eagle Ascent Stage), completed missions (Sojourner, Spirit, Opportunity, InSight, Surveyor 3), and actively operating Mars rovers (Curiosity and Perseverance). Never describe Curiosity or Perseverance as abandoned.
3. Keep your answer concise (2–3 short paragraphs) and include 1–2 official NASA reference URLs (from science.nasa.gov, nssdc.gsfc.nasa.gov, or images.nasa.gov) if relevant.
4. If the user asks about something outside verified NASA Moon/Mars hardware or unknown, clearly state what is not verified.

Verified museum reference catalog:
${VERIFIED_SYSTEM_CONTEXT}`;

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: question,
        config: {
          systemInstruction,
          thinkingConfig: {
            thinkingLevel: ThinkingLevel.LOW,
          },
          abortSignal: controller.signal,
        },
      });
      clearTimeout(timeoutId);

      const text = response.text?.trim();
      if (!text) {
        const kbMatch = matchAstraKnowledge(question);
        res.json({
          answer: kbMatch.answer,
          sources: kbMatch.sources,
          mode: 'verified-knowledge-base',
        });
        return;
      }

      const kbSources = matchAstraKnowledge(question).sources;
      res.json({
        answer: text,
        sources: kbSources,
        mode: 'gemini-live',
      });
    } catch (err) {
      clearTimeout(timeoutId);
      console.error('ASTRA Gemini fallback triggered:', err);
      const kbMatch = matchAstraKnowledge(question);
      res.json({
        answer: kbMatch.answer,
        sources: kbMatch.sources,
        mode: 'verified-knowledge-base',
      });
    }
  });

  app.get('/api/nasa-media', async (req, res) => {
    const q =
      typeof req.query.q === 'string' && req.query.q.trim()
        ? req.query.q.trim()
        : 'Apollo 11 Lunar Module Mars Rover';

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);

    try {
      const url = `https://images-api.nasa.gov/search?q=${encodeURIComponent(q)}&media_type=image&page_size=6`;
      const upstream = await fetch(url, { signal: controller.signal });
      clearTimeout(timeoutId);

      if (!upstream.ok) {
        throw new Error(`NASA API responded ${upstream.status}`);
      }

      const data = (await upstream.json()) as {
        collection?: {
          items?: Array<{
            data?: Array<{
              nasa_id?: string;
              title?: string;
              description?: string;
              date_created?: string;
              center?: string;
            }>;
            links?: Array<{ href?: string; rel?: string }>;
          }>;
        };
      };

      const rawItems = data.collection?.items ?? [];
      const items = rawItems
        .slice(0, 6)
        .map((entry) => {
          const meta = entry.data?.[0];
          const link = entry.links?.find((l) => l.href)?.href ?? '';
          if (!meta?.title || !link) return null;
          return {
            nasaId: meta.nasa_id ?? 'NASA-ARCHIVE',
            title: meta.title,
            description:
              (meta.description ?? 'Verified NASA Image and Video Library archival photograph.').slice(
                0,
                220,
              ),
            dateCreated: (meta.date_created ?? '').slice(0, 10) || 'Archive',
            center: meta.center ?? 'NASA',
            imageUrl: link,
            nasaUrl: `https://images.nasa.gov/details/${encodeURIComponent(meta.nasa_id ?? '')}`,
          };
        })
        .filter((x): x is NonNullable<typeof x> => x !== null);

      if (items.length === 0) {
        res.json({
          source: 'verified-local-archive',
          items: FALLBACK_NASA_MEDIA,
        });
        return;
      }

      res.json({
        source: 'nasa-images-api',
        items,
      });
    } catch {
      clearTimeout(timeoutId);
      res.json({
        source: 'verified-local-archive',
        items: FALLBACK_NASA_MEDIA,
      });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SpaceTime Explorer server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
